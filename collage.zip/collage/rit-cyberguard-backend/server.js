
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const path = require('path');
require('dotenv').config();

const app = express();

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cors({
    origin: ['http://localhost:3000', 'http://localhost:5500', 'http://127.0.0.1:5500'],
    credentials: true
}));

// Serve static files (your HTML, CSS, JS files)
app.use(express.static('public'));

// MongoDB Connection
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/rit_cyberguard')
    .then(() => console.log('✅ Connected to MongoDB'))
    .catch(err => console.error('❌ MongoDB connection error:', err));

// User Schema
const userSchema = new mongoose.Schema({
    username: { type: String, required: true, unique: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    displayName: { type: String, required: true },
    role: { type: String, enum: ['admin', 'moderator', 'member', 'student'], default: 'student' },
    status: { type: String, enum: ['active', 'inactive', 'suspended'], default: 'active' },
    department: String,
    lastLogin: Date,
    loginCount: { type: Number, default: 0 }
}, { timestamps: true });

// Hash password before saving
userSchema.pre('save', async function(next) {
    if (!this.isModified('password')) return next();
    this.password = await bcrypt.hash(this.password, 12);
    next();
});

// Compare password method
userSchema.methods.comparePassword = async function(password) {
    return await bcrypt.compare(password, this.password);
};

const User = mongoose.model('User', userSchema);

// JWT Helper Functions
const signToken = (id, role) => {
    return jwt.sign({ id, role }, process.env.JWT_SECRET || 'fallback-secret-key', {
        expiresIn: process.env.JWT_EXPIRES_IN || '8h'
    });
};

const verifyToken = (token) => {
    return jwt.verify(token, process.env.JWT_SECRET || 'fallback-secret-key');
};

// Auth Middleware
const protect = async (req, res, next) => {
    try {
        let token;
        
        if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
            token = req.headers.authorization.split(' ')[1];
        }

        if (!token) {
            return res.status(401).json({
                success: false,
                message: 'You are not logged in'
            });
        }

        const decoded = verifyToken(token);
        const currentUser = await User.findById(decoded.id);

        if (!currentUser) {
            return res.status(401).json({
                success: false,
                message: 'User no longer exists'
            });
        }

        req.user = currentUser;
        next();
    } catch (error) {
        return res.status(401).json({
            success: false,
            message: 'Invalid token'
        });
    }
};

// Admin Only Middleware
const adminOnly = (req, res, next) => {
    if (req.user.role !== 'admin') {
        return res.status(403).json({
            success: false,
            message: 'Access denied. Admin only.'
        });
    }
    next();
};

// Routes

// Health check
app.get('/', (req, res) => {
    res.json({
        message: '🛡️ RIT CyberGuard API is running!',
        status: 'healthy',
        timestamp: new Date().toISOString()
    });
});

// Admin Login Route
app.post('/api/auth/admin-login', async (req, res) => {
    try {
        const { username, password } = req.body;

        if (!username || !password) {
            return res.status(400).json({
                success: false,
                message: 'Please provide username and password'
            });
        }

        // Find admin user
        const user = await User.findOne({
            $and: [
                { $or: [{ username }, { email: username }] },
                { role: 'admin' },
                { status: 'active' }
            ]
        });

        if (!user || !(await user.comparePassword(password))) {
            console.log(`❌ Failed admin login attempt: ${username}`);
            return res.status(401).json({
                success: false,
                message: 'Invalid admin credentials'
            });
        }

        // Update login info
        user.lastLogin = new Date();
        user.loginCount += 1;
        await user.save();

        // Generate token
        const token = signToken(user._id, user.role);

        console.log(`🔐 Admin logged in: ${user.username}`);

        res.json({
            success: true,
            message: 'Admin login successful',
            token,
            user: {
                id: user._id,
                username: user.username,
                email: user.email,
                displayName: user.displayName,
                role: user.role,
                department: user.department,
                lastLogin: user.lastLogin
            }
        });

    } catch (error) {
        console.error('Login error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error'
        });
    }
});

// Verify Admin Route
app.get('/api/auth/verify-admin', protect, adminOnly, (req, res) => {
    res.json({
        success: true,
        message: 'Admin access verified',
        user: {
            id: req.user._id,
            username: req.user.username,
            role: req.user.role,
            displayName: req.user.displayName
        }
    });
});

// Get Dashboard Stats (Admin Only)
app.get('/api/admin/dashboard', protect, adminOnly, async (req, res) => {
    try {
        const totalUsers = await User.countDocuments();
        const activeUsers = await User.countDocuments({ status: 'active' });
        const adminUsers = await User.countDocuments({ role: 'admin' });
        
        const recentUsers = await User.find()
            .select('-password')
            .sort({ createdAt: -1 })
            .limit(5);

        res.json({
            success: true,
            data: {
                stats: {
                    totalUsers,
                    activeUsers,
                    adminUsers,
                    inactiveUsers: totalUsers - activeUsers
                },
                recentUsers,
                admin: {
                    name: req.user.displayName,
                    username: req.user.username,
                    lastLogin: req.user.lastLogin
                }
            }
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error fetching dashboard data'
        });
    }
});

// Get All Users (Admin Only)
app.get('/api/admin/users', protect, adminOnly, async (req, res) => {
    try {
        const users = await User.find()
            .select('-password')
            .sort({ createdAt: -1 });

        res.json({
            success: true,
            data: users
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error fetching users'
        });
    }
});

// Delete User (Admin Only)
app.delete('/api/admin/users/:id', protect, adminOnly, async (req, res) => {
    try {
        const user = await User.findById(req.params.id);
        
        if (!user) {
            return res.status(404).json({
                success: false,
                message: 'User not found'
            });
        }

        // Prevent admin from deleting themselves
        if (user._id.toString() === req.user._id.toString()) {
            return res.status(400).json({
                success: false,
                message: 'Cannot delete your own account'
            });
        }

        await User.findByIdAndDelete(req.params.id);

        res.json({
            success: true,
            message: 'User deleted successfully'
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error deleting user'
        });
    }
});

// Logout Route
app.post('/api/auth/logout', protect, (req, res) => {
    console.log(`👋 User logged out: ${req.user.username}`);
    res.json({
        success: true,
        message: 'Logged out successfully'
    });
});

// Error handling middleware
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({
        success: false,
        message: 'Something went wrong!'
    });
});

// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
    console.log(`
🚀 RIT CyberGuard Server Running!
📍 Port: ${PORT}
🌍 Environment: ${process.env.NODE_ENV || 'development'}
🔗 Admin Login: http://localhost:${PORT}/login.html
🛡️  Admin Dashboard: http://localhost:${PORT}/admin-dashboard.html
    `);
});

// Initialize admin user if doesn't exist
const initializeAdmin = async () => {
    try {
        const adminExists = await User.findOne({ role: 'admin' });
        
        if (!adminExists) {
            const adminUser = new User({
                username: 'admin',
                email: 'admin@ritrjpm.ac.in',
                password: 'admin123',
                displayName: 'RIT CyberGuard Administrator',
                role: 'admin',
                status: 'active',
                department: 'Computer Science'
            });
            
            await adminUser.save();
            console.log('✅ Default admin user created:');
            console.log('   Username: admin');
            console.log('   Password: admin123');
            console.log('   Email: admin@ritrjpm.ac.in');
        }
    } catch (error) {
        console.error('Error initializing admin:', error);
    }
};

// Initialize after database connection
mongoose.connection.once('open', initializeAdmin);

print("✅ Created server.js")