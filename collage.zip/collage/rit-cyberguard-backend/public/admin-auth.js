/**
 * Admin Setup Script
 * Creates the initial admin user for RIT CyberGuard
 */

const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
require('dotenv').config();

// User Schema (same as in server.js)
const userSchema = new mongoose.Schema({
    username: { type: String, required: true, unique: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    displayName: { type: String, required: true },
    role: { type: String, enum: ['admin', 'moderator', 'member', 'student'], default: 'student' },
    status: { type: String, enum: ['active', 'inactive', 'suspended'], default: 'active' },
    department: String,
    lastLogin: Date,
    loginCount: { type: Number, default: 0 }
}, { timestamps: true });

userSchema.pre('save', async function(next) {
    if (!this.isModified('password')) return next();
    this.password = await bcrypt.hash(this.password, 12);
    next();
});

const User = mongoose.model('User', userSchema);

const setupAdmin = async () => {
    try {
        // Connect to MongoDB
        await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/rit_cyberguard');
        console.log('📦 Connected to MongoDB for setup...');

        // Check if admin already exists
        const existingAdmin = await User.findOne({ role: 'admin' });

        if (existingAdmin) {
            console.log('\n👑 Admin user already exists:');
            console.log(`   Username: ${existingAdmin.username}`);
            console.log(`   Email: ${existingAdmin.email}`);
            console.log(`   Display Name: ${existingAdmin.displayName}`);
            console.log('\n✅ Setup complete - Admin already configured');
            process.exit(0);
        }

        // Create admin user
        const adminUser = new User({
            username: 'admin',
            email: 'admin@ritrjpm.ac.in',
            password: 'admin123',  // Will be hashed automatically
            displayName: 'RIT CyberGuard Administrator',
            role: 'admin',
            status: 'active',
            department: 'Computer Science'
        });

        await adminUser.save();

        console.log('\n🎉 Admin user created successfully!');
        console.log('\n👑 Login Credentials:');
        console.log('─'.repeat(40));
        console.log(`📧 Email:     ${adminUser.email}`);
        console.log(`👤 Username:  ${adminUser.username}`);
        console.log(`🔑 Password:  admin123`);
        console.log(`🎭 Role:      ${adminUser.role}`);
        console.log('─'.repeat(40));

        console.log('\n🚨 SECURITY NOTICE:');
        console.log('   Change the default password after first login!');

        console.log('\n📋 Next Steps:');
        console.log('   1. Run: npm run dev');
        console.log('   2. Open: http://localhost:5000/login.html');
        console.log('   3. Login with admin credentials');
        console.log('   4. Access: http://localhost:5000/admin-dashboard.html');

        // Create some sample users for testing
        console.log('\n👥 Creating sample users...');

        const sampleUsers = [
            {
                username: 'student1',
                email: 'student1@ritrjpm.ac.in',
                password: 'student123',
                displayName: 'John Doe',
                role: 'student',
                department: 'Computer Science'
            },
            {
                username: 'member1',
                email: 'member1@ritrjpm.ac.in',
                password: 'member123',
                displayName: 'Jane Smith',  
                role: 'member',
                department: 'Information Technology'
            }
        ];

        for (const userData of sampleUsers) {
            const user = new User(userData);
            await user.save();
            console.log(`   ✅ Created ${user.role}: ${user.username}`);
        }

        console.log('\n🎯 Setup Complete!');
        console.log('   • 1 Admin user created');
        console.log('   • 2 Sample users created');
        console.log('   • Database ready for use');

        process.exit(0);

    } catch (error) {
        console.error('❌ Setup failed:', error.message);

        if (error.code === 11000) {
            console.log('\n💡 User already exists. Delete existing users or use different credentials.');
        }

        process.exit(1);
    }
};

// Run setup
console.log('🚀 Setting up RIT CyberGuard Admin...');
setupAdmin();
