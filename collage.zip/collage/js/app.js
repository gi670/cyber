
// RIT CyberGuard Website JavaScript
// Enhanced with Quill.js integration and improved functionality

class CyberGuardApp {
    constructor() {
        this.quill = null;
        this.isEditorInitialized = false;
        this.events = [];
        this.teams = [];
        this.activities = [];

        this.init();
    }

    init() {
        this.setupScrollIndicator();
        this.setupMobileMenu();
        this.setupSmoothScrolling();
        this.loadDynamicContent();
        this.setupAnimations();
        this.setupQuillEditor();
    }

    // Scroll Progress Indicator
    setupScrollIndicator() {
        window.addEventListener('scroll', () => {
            const scrollIndicator = document.getElementById('scroll-indicator');
            if (scrollIndicator) {
                const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
                const scrollHeight = document.documentElement.scrollHeight - document.documentElement.clientHeight;
                const scrollPercentage = (scrollTop / scrollHeight) * 100;
                scrollIndicator.style.width = Math.min(scrollPercentage, 100) + '%';
            }
        });
    }

    // Mobile Menu Toggle
    setupMobileMenu() {
        const mobileMenuToggle = document.getElementById('mobileMenuToggle');
        const nav = document.getElementById('nav');

        if (mobileMenuToggle && nav) {
            mobileMenuToggle.addEventListener('click', () => {
                nav.classList.toggle('mobile-active');
                mobileMenuToggle.classList.toggle('active');
            });

            // Close mobile menu when clicking nav links
            nav.addEventListener('click', (e) => {
                if (e.target.classList.contains('nav-link')) {
                    nav.classList.remove('mobile-active');
                    mobileMenuToggle.classList.remove('active');
                }
            });

            // Close mobile menu when clicking outside
            document.addEventListener('click', (e) => {
                if (!nav.contains(e.target) && !mobileMenuToggle.contains(e.target)) {
                    nav.classList.remove('mobile-active');
                    mobileMenuToggle.classList.remove('active');
                }
            });
        }
    }

    // Smooth Scrolling for Anchor Links
    setupSmoothScrolling() {
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', (e) => {
                e.preventDefault();
                const target = document.querySelector(anchor.getAttribute('href'));
                if (target) {
                    const headerHeight = document.querySelector('.header')?.offsetHeight || 0;
                    const targetPosition = target.offsetTop - headerHeight - 20;

                    window.scrollTo({
                        top: targetPosition,
                        behavior: 'smooth'
                    });
                }
            });
        });
    }

    // Setup Quill.js Editor
    setupQuillEditor() {
        // Don't initialize immediately, wait for user interaction
        window.openEditor = () => this.openEditor();
        window.saveEvent = () => this.saveEvent();
        window.closeEditor = () => this.closeEditor();
    }

    openEditor() {
        const editorContainer = document.getElementById('editor-container');
        if (!editorContainer) return;

        // Show editor container with animation
        editorContainer.style.display = 'block';
        editorContainer.classList.add('loading');

        // Initialize Quill only once
        if (!this.isEditorInitialized) {
            setTimeout(() => {
                try {
                    // Create toolbar configuration
                    const toolbarOptions = [
                        ['bold', 'italic', 'underline', 'strike'],
                        ['blockquote', 'code-block'],
                        [{ 'header': 1 }, { 'header': 2 }],
                        [{ 'list': 'ordered'}, { 'list': 'bullet' }],
                        [{ 'script': 'sub'}, { 'script': 'super' }],
                        [{ 'indent': '-1'}, { 'indent': '+1' }],
                        [{ 'direction': 'rtl' }],
                        [{ 'size': ['small', false, 'large', 'huge'] }],
                        [{ 'header': [1, 2, 3, 4, 5, 6, false] }],
                        [{ 'color': [] }, { 'background': [] }],
                        [{ 'font': [] }],
                        [{ 'align': [] }],
                        ['clean'],
                        ['link', 'image']
                    ];

                    this.quill = new Quill('#editor', {
                        theme: 'snow',
                        modules: {
                            toolbar: toolbarOptions
                        },
                        placeholder: 'Write your event details here...'
                    });

                    this.isEditorInitialized = true;
                    editorContainer.classList.remove('loading');

                    // Focus on editor
                    this.quill.focus();
                } catch (error) {
                    console.error('Error initializing Quill editor:', error);
                    editorContainer.classList.remove('loading');
                }
            }, 100);
        } else {
            editorContainer.classList.remove('loading');
            this.quill.focus();
        }
    }

    closeEditor() {
        const editorContainer = document.getElementById('editor-container');
        if (editorContainer) {
            editorContainer.style.display = 'none';
        }
    }

    saveEvent() {
        if (!this.quill) {
            console.error('Editor not initialized');
            return;
        }

        const content = this.quill.root.innerHTML.trim();

        // Check if content is not empty (excluding empty paragraphs)
        const textContent = this.quill.getText().trim();
        if (!textContent || textContent.length < 3) {
            alert('Please add some content before saving.');
            return;
        }

        const eventsGrid = document.getElementById('events-grid');
        if (!eventsGrid) return;

        // Remove placeholder if it exists
        const placeholder = eventsGrid.querySelector('.loading-placeholder');
        if (placeholder) {
            placeholder.remove();
        }

        // Create new event card with better styling
        const card = document.createElement('div');
        card.classList.add('card', 'fade-in');

        // Add timestamp
        const timestamp = new Date().toLocaleString();
        const timestampDiv = document.createElement('div');
        timestampDiv.style.cssText = `
            font-size: var(--font-size-xs);
            color: var(--color-text-secondary);
            margin-bottom: var(--space-8);
            text-align: right;
            opacity: 0.7;
        `;
        timestampDiv.textContent = `Added: ${timestamp}`;

        card.appendChild(timestampDiv);

        // Add content
        const contentDiv = document.createElement('div');
        contentDiv.innerHTML = content;
        card.appendChild(contentDiv);

        // Add delete button
        const deleteBtn = document.createElement('button');
        deleteBtn.innerHTML = '×';
        deleteBtn.style.cssText = `
            position: absolute;
            top: var(--space-8);
            right: var(--space-8);
            background: var(--color-rit-orange);
            color: white;
            border: none;
            border-radius: 50%;
            width: 24px;
            height: 24px;
            cursor: pointer;
            font-size: 16px;
            line-height: 1;
            opacity: 0;
            transition: opacity var(--duration-normal) var(--ease-standard);
        `;
        deleteBtn.addEventListener('click', () => {
            if (confirm('Are you sure you want to delete this event?')) {
                card.remove();
            }
        });

        card.style.position = 'relative';
        card.appendChild(deleteBtn);

        // Show delete button on hover
        card.addEventListener('mouseenter', () => {
            deleteBtn.style.opacity = '1';
        });
        card.addEventListener('mouseleave', () => {
            deleteBtn.style.opacity = '0';
        });

        eventsGrid.prepend(card);

        // Clear editor and hide container
        this.quill.setText('');
        this.closeEditor();

        // Show success message
        this.showNotification('Event added successfully!', 'success');
    }
    
    // Notification system
    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: ${type === 'success' ? 'var(--color-cyber-blue)' : 'var(--color-rit-orange)'};
            color: white;
            padding: var(--space-12) var(--space-20);
            border-radius: var(--radius-base);
            z-index: 10001;
            animation: slideInRight 0.3s ease-out;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
            font-weight: var(--font-weight-medium);
        `;
        notification.textContent = message;

        document.body.appendChild(notification);

        setTimeout(() => {
            notification.style.animation = 'slideOutRight 0.3s ease-out';
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 300);
        }, 3000);
    }

    // Load Dynamic Content
    loadDynamicContent() {
        this.loadTeams();
        this.loadActivities();
        this.loadEvents();
    }

    loadTeams() {
        const teamsData = [
            {
                name: "Penetration Testing",
                description: "Learn ethical hacking techniques, vulnerability assessment, and security testing methodologies.",
                meeting: "Mondays 3:00 PM"
            },
            {
                name: "Incident Response",
                description: "Develop skills in cybersecurity incident handling, forensics, and threat analysis.",
                meeting: "Wednesdays 2:00 PM"
            },
            {
                name: "Security Research",
                description: "Explore emerging threats, conduct security research, and publish findings.",
                meeting: "Fridays 4:00 PM"
            },
            {
                name: "CTF Competition",
                description: "Train for Capture The Flag competitions and develop problem-solving skills.",
                meeting: "Saturdays 10:00 AM"
            },
            {
                name: "Awareness & Outreach",
                description: "Organize cybersecurity awareness campaigns and community education programs.",
                meeting: "Thursdays 3:30 PM"
            }
        ];

        this.renderTeams(teamsData);
    }

    loadActivities() {
        const activitiesData = [
            {
                name: "Weekly Workshops",
                description: "Hands-on sessions covering various cybersecurity topics and tools.",
                meeting: "Every Wednesday"
            },
            {
                name: "CTF Practice",
                description: "Regular practice sessions for Capture The Flag competitions.",
                meeting: "Weekends"
            },
            {
                name: "Guest Lectures",
                description: "Industry experts share insights and real-world experiences.",
                meeting: "Monthly"
            },
            {
                name: "Security Audits",
                description: "Practical experience through security assessments of local systems.",
                meeting: "As needed"
            },
            {
                name: "Research Projects",
                description: "Collaborative research on emerging cybersecurity threats and solutions.",
                meeting: "Ongoing"
            },
            {
                name: "Certification Prep",
                description: "Study groups for cybersecurity certifications like CEH, CISSP.",
                meeting: "Bi-weekly"
            }
        ];

        this.renderActivities(activitiesData);
    }

    loadEvents() {
        // Clear placeholder
        const eventsGrid = document.getElementById('events-grid');
        if (eventsGrid) {
            const placeholder = eventsGrid.querySelector('.loading-placeholder');
            if (placeholder) {
                placeholder.remove();
            }
        }
    }

    renderTeams(teams) {
        const teamsGrid = document.getElementById('teams-grid');
        if (!teamsGrid) return;

        teamsGrid.innerHTML = '';

        teams.forEach((team, index) => {
            const teamCard = this.createTeamCard(team);
            teamCard.style.animationDelay = `${index * 0.1}s`;
            teamsGrid.appendChild(teamCard);
        });
    }

    renderActivities(activities) {
        const activitiesGrid = document.getElementById('activities-grid');
        if (!activitiesGrid) return;

        activitiesGrid.innerHTML = '';

        activities.forEach((activity, index) => {
            const activityCard = this.createActivityCard(activity);
            activityCard.style.animationDelay = `${index * 0.1}s`;
            activitiesGrid.appendChild(activityCard);
        });
    }

    createTeamCard(team) {
        const card = document.createElement('div');
        card.classList.add('team-card', 'fade-in');
        card.innerHTML = `
            <h3 class="team-name">${team.name}</h3>
            <p class="team-description">${team.description}</p>
            <div class="team-meeting">${team.meeting}</div>
        `;
        return card;
    }

    createActivityCard(activity) {
        const card = document.createElement('div');
        card.classList.add('group-card', 'fade-in');
        card.innerHTML = `
            <h3 class="group-name">${activity.name}</h3>
            <p class="group-description">${activity.description}</p>
            <div class="group-meeting">${activity.meeting}</div>
        `;
        return card;
    }

    // Setup scroll-triggered animations
    setupAnimations() {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('fade-in');
                    observer.unobserve(entry.target);
                }
            });
        }, {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        });

        // Observe sections for animations
        document.querySelectorAll('.about, .teams, .groups, .events, .join').forEach(section => {
            observer.observe(section);
        });
    }

    // Modal functionality
    showContactForm() {
        const modal = document.getElementById('form-modal');
        const formContainer = document.getElementById('form-container');

        if (modal && formContainer) {
            formContainer.innerHTML = `
                <h2 style="color: var(--color-rit-orange); margin-bottom: var(--space-20); text-align: center;">Contact RIT CyberGuard</h2>
                <form id="contact-form">
                    <div class="form-group">
                        <label for="name">Full Name</label>
                        <input type="text" id="name" name="name" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="email">Email Address</label>
                        <input type="email" id="email" name="email" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="department">Department</label>
                        <input type="text" id="department" name="department" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="year">Year of Study</label>
                        <select id="year" name="year" class="form-control" required>
                            <option value="">Select Year</option>
                            <option value="1">First Year</option>
                            <option value="2">Second Year</option>
                            <option value="3">Third Year</option>
                            <option value="4">Fourth Year</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="message">Message</label>
                        <textarea id="message" name="message" class="form-control" placeholder="Tell us about your interest in cybersecurity..."></textarea>
                    </div>
                    <button type="submit" class="btn btn--primary" style="width: 100%;">Send Message</button>
                </form>
            `;

            modal.style.display = 'flex';

            // Handle form submission
            const form = document.getElementById('contact-form');
            form.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleContactFormSubmission(form);
            });
        }
    }

    handleContactFormSubmission(form) {
        const formData = new FormData(form);
        const data = Object.fromEntries(formData.entries());

        // Simulate form submission
        console.log('Contact form submitted:', data);

        this.showNotification('Thank you for your interest! We will contact you soon.', 'success');
        this.closeModal();
    }

    closeModal() {
        const modal = document.getElementById('form-modal');
        if (modal) {
            modal.style.display = 'none';
        }
    }

    // Validate Quill editor content
    validateQuillContent() {
        if (!this.quill) return false;

        const text = this.quill.getText().trim();
        return text.length > 3;
    }

    // Export functionality for events
    exportEvents() {
        const events = Array.from(document.querySelectorAll('.card')).map(card => {
            return {
                content: card.innerHTML,
                timestamp: new Date().toISOString()
            };
        });

        const dataStr = JSON.stringify(events, null, 2);
        const dataBlob = new Blob([dataStr], {type:'application/json'});

        const link = document.createElement('a');
        link.href = URL.createObjectURL(dataBlob);
        link.download = 'cyberguard-events.json';
        link.click();
    }
}

// Global functions for HTML onclick handlers
let app;

function initializeApp() {
    app = new CyberGuardApp();
}

function openEditor() {
    if (app) app.openEditor();
}

function saveEvent() {
    if (app) app.saveEvent();
}

function closeEditor() {
    if (app) app.closeEditor();
}

function showContactForm() {
    if (app) app.showContactForm();
}

function closeModal() {
    if (app) app.closeModal();
}

// CSS animations keyframes (to be added via JavaScript since we can't modify CSS directly)
function addAnimationKeyframes() {
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideInRight {
            from {
                opacity: 0;
                transform: translateX(100%);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        @keyframes slideOutRight {
            from {
                opacity: 1;
                transform: translateX(0);
            }
            to {
                opacity: 0;
                transform: translateX(100%);
            }
        }
    `;
    document.head.appendChild(style);
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    addAnimationKeyframes();
    initializeApp();
});

// Handle page visibility changes
document.addEventListener('visibilitychange', () => {
    if (document.hidden && app && app.quill) {
        // Auto-save draft when page becomes hidden
        const content = app.quill.root.innerHTML;
        if (content.trim() && app.quill.getText().trim().length > 3) {
            localStorage.setItem('quill-draft', content);
        }
    }
});

// Restore draft when editor opens
function restoreDraft() {
    const draft = localStorage.getItem('quill-draft');
    if (draft && app && app.quill) {
        app.quill.root.innerHTML = draft;
        localStorage.removeItem('quill-draft');
    }
}

// Error handling for Quill
window.addEventListener('error', (e) => {
    if (e.message.includes('Quill')) {
        console.error('Quill.js error:', e);
        const editorContainer = document.getElementById('editor-container');
        if (editorContainer) {
            editorContainer.classList.remove('loading');
        }
    }
});

// Export the app class for external use
window.CyberGuardApp = CyberGuardApp;
