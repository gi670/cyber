// Dummy users (replace with real backend later)
const users = [
  { username: "admin", password: "admin123", role: "admin", verified: false },
  { username: "member", password: "member123", role: "member", verified: true }
];

document.getElementById("loginForm").addEventListener("submit", function(e) {
  e.preventDefault();

  const username = document.getElementById("username").value.trim();
  const password = document.getElementById("password").value.trim();
  const overlay = document.getElementById("loadingOverlay");

  overlay.style.display = "flex";

  setTimeout(() => {
    overlay.style.display = "none";

    const user = users.find(u => u.username === username && u.password === password);

    if (!user) {
      alert("❌ Invalid username or password!");
      return;
    }

    if (!user.verified) {
      const code = prompt("📧 Enter the verification code sent to your email (demo: 1234):");
      if (code !== "1234") {
        alert("❌ Invalid verification code. Please try again.");
        return;
      }
      user.verified = true;
    }

    localStorage.setItem("role", user.role);

    if (user.role === "admin") {
      alert("✅ Welcome Admin! Redirecting...");
      window.location.href = "admin-dashboard.html";
    } else {
      alert("✅ Welcome Member!");
      window.location.href = "index.html";
    }
  }, 1500);
});
