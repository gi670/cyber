//// Dummy users for role-based login
const users = [
  { username: "admin", password: "admin123", role: "admin" },
  { username: "member", password: "member123", role: "member" }
];

function login() {
  const username = document.getElementById("username").value;
  const password = document.getElementById("password").value;
  const error = document.getElementById("error");

  const user = users.find(u => u.username === username && u.password === password);

  if (user) {
    localStorage.setItem("role", user.role);

    // Reload index.html with correct access
    if (user.role === "admin") {
      alert("Admin login successful! You now have full control.");
    } else {
      alert("Member login successful. You have view-only access.");
    }

    // Redirect to index.html
    window.location.href = "index.html";
  } else {
    error.textContent = "Invalid username or password!";
  }
}


  if (user) {
    localStorage.setItem("role", user.role);
    showDashboard(user.role);
  } else {
    error.textContent = "Invalid username or password!";
  }

function showDashboard(role) {
  document.getElementById("login-box").classList.add("hidden");
  document.getElementById("dashboard").classList.remove("hidden");
  document.getElementById("user-role").textContent = role;

  // Reload index.html with correct access
  if (role === "admin") {
    alert("Admin login successful! You now have full control.");
  } else {
    alert("Member login successful. You have view-only access.");
  }
}


function logout() {
  localStorage.removeItem("role");
  document.getElementById("dashboard").classList.add("hidden");
  document.getElementById("login-box").classList.remove("hidden");
}

// Check if already logged in
document.addEventListener("DOMContentLoaded", () => {
  const role = localStorage.getItem("role");
  if (role) {
    showDashboard(role);
  }
});


// Store achievements
let achievements = JSON.parse(localStorage.getItem("achievements")) || [];

function renderAchievements() {
  const grid = document.getElementById("achievements-grid");
  grid.innerHTML = "";

  if (achievements.length === 0) {
    grid.innerHTML = `<div class="loading-placeholder">No achievements yet. Add one!</div>`;
    return;
  }

  achievements.forEach((ach, index) => {
    const card = document.createElement("div");
    card.classList.add("achievement-card");
    card.innerHTML = `
      <div class="achievement-icon">${ach.icon}</div>
      <h3 class="achievement-title">${ach.title}</h3>
      <p class="achievement-text">${ach.desc}</p>
      <button onclick="deleteAchievement(${index})" style="margin-top:10px;" class="btn btn--outline">Delete</button>
    `;
    grid.appendChild(card);
  });
}

// Open / Close modal
function openAchievementForm() {
  document.getElementById("achievement-modal").style.display = "flex";
}
function closeAchievementForm() {
  document.getElementById("achievement-modal").style.display = "none";
}

// Handle form submission
document.addEventListener("DOMContentLoaded", () => {
  renderAchievements();

  document.getElementById("achievement-form").addEventListener("submit", (e) => {
    e.preventDefault();

    const icon = document.getElementById("ach-icon").value;
    const title = document.getElementById("ach-title").value;
    const desc = document.getElementById("ach-desc").value;

    achievements.push({ icon, title, desc });
    localStorage.setItem("achievements", JSON.stringify(achievements));

    renderAchievements();
    closeAchievementForm();
    e.target.reset();
  });
});

// Delete achievement
function deleteAchievement(index) {
  if (confirm("Delete this achievement?")) {
    achievements.splice(index, 1);
    localStorage.setItem("achievements", JSON.stringify(achievements));
    renderAchievements();
  }
}

