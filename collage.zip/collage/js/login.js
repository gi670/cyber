
// Enhanced Login Page with Role-Based Access Control (RBAC) - RIT CyberGuard
class RBACLoginManager {
    constructor() {
        this.loginForm = document.getElementById('loginForm');
        this.usernameInput = document.getElementById('username');
        this.passwordInput = document.getElementById('password');
        this.passwordToggle = document.getElementById('passwordToggle');
        this.loginBtn = document.getElementById('loginBtn');
        this.loadingOverlay = document.getElementById('loadingOverlay');
        this.rememberMe = document.getElementById('rememberMe');
        this.supportSection = document.getElementById('supportSection');

        // Quill.js editor
        this.quillEditor = null;

        // RBAC Configuration
        this.userRoles = {
            ADMIN: 'admin',
            MODERATOR: 'moderator', 
            MEMBER: 'member',
            STUDENT: 'student',
            GUEST: 'guest'
        };

        this.permissions = {
            // Admin permissions
            [this.userRoles.ADMIN]: [
                'view_dashboard',
                'manage_users',
                'manage_events',
                'manage_teams',
                'view_analytics',
                'system_settings',
                'security_audit',
                'backup_restore',
                'manage_permissions'
            ],
            // Moderator permissions
            [this.userRoles.MODERATOR]: [
                'view_dashboard',
                'manage_events',
                'manage_teams',
                'view_analytics',
                'moderate_content'
            ],
            // Member permissions
            [this.userRoles.MEMBER]: [
                'view_dashboard',
                'join_teams',
                'participate_events',
                'view_resources',
                'submit_projects'
            ],
            // Student permissions
            [this.userRoles.STUDENT]: [
                'view_dashboard',
                'join_teams',
                'participate_events',
                'view_resources',
                'submit_assignments'
            ],
            // Guest permissions
            [this.userRoles.GUEST]: [
                'view_public_content',
                'contact_support'
            ]
        };

        this.routePermissions = {
            '/admin': [this.userRoles.ADMIN],
            '/admin/users': [this.userRoles.ADMIN],
            '/admin/settings': [this.userRoles.ADMIN],
            '/moderator': [this.userRoles.ADMIN, this.userRoles.MODERATOR],
            '/dashboard': [this.userRoles.ADMIN, this.userRoles.MODERATOR, this.userRoles.MEMBER, this.userRoles.STUDENT],
            '/teams': [this.userRoles.ADMIN, this.userRoles.MODERATOR, this.userRoles.MEMBER, this.userRoles.STUDENT],
            '/events': [this.userRoles.ADMIN, this.userRoles.MODERATOR, this.userRoles.MEMBER, this.userRoles.STUDENT],
            '/resources': [this.userRoles.ADMIN, this.userRoles.MODERATOR, this.userRoles.MEMBER, this.userRoles.STUDENT],
            '/profile': [this.userRoles.ADMIN, this.userRoles.MODERATOR, this.userRoles.MEMBER, this.userRoles.STUDENT]
        };

        // Initialize everything
        this.initializeEventListeners();
        this.initializeQuillEditor();
        this.initializeAnimations();
        this.loadRememberedCredentials();
        this.initializeRBACSystem();
    }

    initializeRBACSystem() {
        // Check if user is already logged in
        const savedSession = this.getStoredSession();
        if (savedSession && this.isValidSession(savedSession)) {
            this.redirectToUserDashboard(savedSession.user);
        }
    }

    initializeEventListeners() {
        // Form submission
        this.loginForm.addEventListener('submit', (e) => this.handleLogin(e));

        // Password toggle
        this.passwordToggle.addEventListener('click', () => this.togglePasswordVisibility());

        // Real-time validation
        this.usernameInput.addEventListener('input', () => this.validateUsername());
        this.usernameInput.addEventListener('blur', () => this.validateUsername());

        this.passwordInput.addEventListener('input', () => this.validatePassword());
        this.passwordInput.addEventListener('blur', () => this.validatePassword());

        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => this.handleKeyboardShortcuts(e));

        // Social login buttons
        document.querySelector('.google-btn')?.addEventListener('click', () => this.handleSocialLogin('google'));
        document.querySelector('.github-btn')?.addEventListener('click', () => this.handleSocialLogin('github'));

        // Forgot password
        document.querySelector('.forgot-password')?.addEventListener('click', (e) => {
            e.preventDefault();
            this.handleForgotPassword();
        });

        // Create account link
        document.querySelector('.signup-link')?.addEventListener('click', (e) => {
            e.preventDefault();
            this.handleSignupRedirect();
        });

        // Help link - now shows support form
        document.querySelector('.help-link')?.addEventListener('click', (e) => {
            e.preventDefault();
            this.showSupportForm();
        });

        // Form input focus effects
        const inputs = document.querySelectorAll('.form-input');
        inputs.forEach(input => {
            input.addEventListener('focus', (e) => this.handleInputFocus(e));
            input.addEventListener('blur', (e) => this.handleInputBlur(e));
        });
    }

    initializeQuillEditor() {
        // Custom toolbar configuration for support messages
        const toolbarOptions = [
            [{ 'header': [1, 2, 3, false] }],
            ['bold', 'italic', 'underline'],
            [{ 'list': 'ordered'}, { 'list': 'bullet' }],
            ['link'],
            [{ 'color': ['#F76902', '#00B4D8', '#e0f7ff', '#00ff88', '#ff4757'] }],
            ['clean']
        ];

        // Initialize Quill editor
        this.quillEditor = new Quill('#quill-editor', {
            theme: 'snow',
            modules: {
                toolbar: toolbarOptions
            },
            placeholder: 'Describe your login issue in detail. Include any error messages, steps you tried, and when the problem started...',
        });

        // Set initial content with helpful template
        const initialContent = `
            <h3 style="color: #F76902;">Issue Description</h3>
            <p>Please provide details about your login problem:</p>
            <ul>
                <li><strong>What happened?</strong> (e.g., error message, page not loading)</li>
                <li><strong>When did it start?</strong> (e.g., today, after password change)</li>
                <li><strong>What did you try?</strong> (e.g., cleared cache, different browser)</li>
                <li><strong>Your browser:</strong> (e.g., Chrome, Firefox, Safari)</li>
            </ul>
            <p><em style="color: #00B4D8;">The more details you provide, the faster we can help you!</em></p>
        `;

        this.quillEditor.root.innerHTML = initialContent;
    }

    initializeAnimations() {
        // Stagger form element animations
        const formElements = document.querySelectorAll('.form-group, .form-options, .login-btn, .security-notice, .alt-login, .login-footer');

        formElements.forEach((element, index) => {
            element.style.opacity = '0';
            element.style.transform = 'translateY(20px)';

            setTimeout(() => {
                element.style.transition = 'all 0.6s ease-out';
                element.style.opacity = '1';
                element.style.transform = 'translateY(0)';
            }, 200 + (index * 100));
        });

        // Typing effect for security notice
        this.typeSecurityNotice();
    }

    typeSecurityNotice() {
        const notice = document.querySelector('.security-notice span');
        if (notice) {
            const originalText = notice.textContent;
            notice.textContent = '';

            let i = 0;
            const typeInterval = setInterval(() => {
                notice.textContent += originalText.charAt(i);
                i++;

                if (i >= originalText.length) {
                    clearInterval(typeInterval);
                }
            }, 50);
        }
    }

    validateUsername() {
        const username = this.usernameInput.value.trim();
        const formGroup = this.usernameInput.closest('.form-group');

        this.clearValidationState(formGroup);

        if (!username) {
            this.setValidationState(formGroup, 'error', 'Username or email is required');
            return false;
        }

        if (username.length < 3) {
            this.setValidationState(formGroup, 'error', 'Username must be at least 3 characters');
            return false;
        }

        // Email validation if contains @
        if (username.includes('@')) {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(username)) {
                this.setValidationState(formGroup, 'error', 'Please enter a valid email address');
                return false;
            }
        }

        this.setValidationState(formGroup, 'success', 'Valid username/email');
        return true;
    }

    validatePassword() {
        const password = this.passwordInput.value;
        const formGroup = this.passwordInput.closest('.form-group');

        this.clearValidationState(formGroup);

        if (!password) {
            this.setValidationState(formGroup, 'error', 'Password is required');
            return false;
        }

        if (password.length < 6) {
            this.setValidationState(formGroup, 'error', 'Password must be at least 6 characters');
            return false;
        }

        // Strong password validation
        const hasUppercase = /[A-Z]/.test(password);
        const hasLowercase = /[a-z]/.test(password);
        const hasNumbers = /\d/.test(password);
        const hasSpecialChar = /[!@#$%^&*(),.?":{}|<>]/.test(password);

        if (password.length >= 8 && hasUppercase && hasLowercase && hasNumbers && hasSpecialChar) {
            this.setValidationState(formGroup, 'success', 'Strong password');
        } else if (password.length >= 6) {
            this.setValidationState(formGroup, 'success', 'Password acceptable');
        }

        return true;
    }

    setValidationState(formGroup, state, message) {
        formGroup.classList.remove('error', 'success');
        formGroup.classList.add(state);

        // Remove existing message
        const existingMessage = formGroup.querySelector('.error-message, .success-message');
        if (existingMessage) {
            existingMessage.remove();
        }

        // Add new message
        const messageElement = document.createElement('div');
        messageElement.className = `${state}-message`;
        messageElement.innerHTML = `<i class="fas fa-${state === 'error' ? 'exclamation-circle' : 'check-circle'}"></i> ${message}`;

        formGroup.appendChild(messageElement);

        // Auto-remove success messages after 3 seconds
        if (state === 'success') {
            setTimeout(() => {
                if (messageElement.parentNode) {
                    messageElement.remove();
                    formGroup.classList.remove('success');
                }
            }, 3000);
        }
    }

    clearValidationState(formGroup) {
        formGroup.classList.remove('error', 'success');
        const existingMessage = formGroup.querySelector('.error-message, .success-message');
        if (existingMessage) {
            existingMessage.remove();
        }
    }

    togglePasswordVisibility() {
        const type = this.passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
        this.passwordInput.setAttribute('type', type);

        const icon = this.passwordToggle.querySelector('i');
        icon.classList.toggle('fa-eye');
        icon.classList.toggle('fa-eye-slash');

        // Add visual feedback
        this.passwordToggle.style.transform = 'scale(0.9)';
        setTimeout(() => {
            this.passwordToggle.style.transform = 'scale(1)';
        }, 150);
    }

    async handleLogin(e) {
        e.preventDefault();

        // Validate form
        const usernameValid = this.validateUsername();
        const passwordValid = this.validatePassword();

        if (!usernameValid || !passwordValid) {
            this.showNotification('Please fix the errors above', 'error');
            return;
        }

        // Show loading state
        this.setLoadingState(true);

        try {
            // Authenticate user with RBAC
            const result = await this.authenticateUserWithRBAC({
                username: this.usernameInput.value.trim(),
                password: this.passwordInput.value,
                rememberMe: this.rememberMe.checked
            });

            if (result.success) {
                // Save credentials and session if remember me is checked
                if (this.rememberMe.checked) {
                    this.saveCredentials();
                }

                // Store user session with role and permissions
                this.storeUserSession(result.user);

                // Show role-specific success message
                this.showNotification(`Welcome back, ${result.user.displayName}! Logging in as ${result.user.role}...`, 'success');

                // Redirect based on user role
                setTimeout(() => {
                    this.redirectToUserDashboard(result.user);
                }, 1500);
            } else {
                throw new Error(result.message || 'Authentication failed');
            }
        } catch (error) {
            this.showNotification(error.message || 'Login failed. Please try again.', 'error');
            this.setLoadingState(false);

            // Add shake animation to login button
            this.loginBtn.style.animation = 'shake 0.5s ease-in-out';
            setTimeout(() => {
                this.loginBtn.style.animation = '';
            }, 500);
        }
    }

    async authenticateUserWithRBAC(credentials) {
        // Simulate API call delay
        await this.delay(2000);

        // Enhanced user database with RBAC
        const validCredentials = [
            { 
                username: 'admin', 
                password: 'admin123', 
                role: this.userRoles.ADMIN,
                displayName: 'System Administrator',
                email: 'admin@ritrjpm.ac.in',
                department: 'Computer Science',
                permissions: this.permissions[this.userRoles.ADMIN]
            },
            { 
                username: 'cyberguard', 
                password: 'cyber2025', 
                role: this.userRoles.MODERATOR,
                displayName: 'CyberGuard Moderator',
                email: 'cyberguard@ritrjpm.ac.in',
                department: 'Cybersecurity Club',
                permissions: this.permissions[this.userRoles.MODERATOR]
            },
            { 
                username: 'student@ritrjpm.ac.in', 
                password: 'student123', 
                role: this.userRoles.STUDENT,
                displayName: 'Student Member',
                email: 'student@ritrjpm.ac.in',
                department: 'Information Technology',
                permissions: this.permissions[this.userRoles.STUDENT]
            },
            { 
                username: 'member1', 
                password: 'member123', 
                role: this.userRoles.MEMBER,
                displayName: 'Club Member',
                email: 'member1@ritrjpm.ac.in',
                department: 'Electronics',
                permissions: this.permissions[this.userRoles.MEMBER]
            },
            { 
                username: 'demo', 
                password: 'demo', 
                role: this.userRoles.GUEST,
                displayName: 'Demo User',
                email: 'demo@ritrjpm.ac.in',
                department: 'Guest',
                permissions: this.permissions[this.userRoles.GUEST]
            }
        ];

        const user = validCredentials.find(u => 
            (u.username === credentials.username.toLowerCase() || 
             u.username === credentials.username) &&
            u.password === credentials.password
        );

        if (user) {
            // Create user session with RBAC data
            const userSession = {
                id: Math.random().toString(36).substr(2, 9),
                username: user.username,
                role: user.role,
                displayName: user.displayName,
                email: user.email,
                department: user.department,
                permissions: user.permissions,
                loginTime: new Date().toISOString(),
                sessionTimeout: new Date(Date.now() + 8 * 60 * 60 * 1000).toISOString() // 8 hours
            };

            return {
                success: true,
                user: userSession,
                message: 'Authentication successful'
            };
        } else {
            return {
                success: false,
                message: 'Invalid username or password'
            };
        }
    }

    storeUserSession(user) {
        try {
            const sessionData = {
                user: user,
                timestamp: new Date().toISOString(),
                expiresAt: user.sessionTimeout
            };

            // Store in localStorage for demo (in production, use secure HttpOnly cookies)
            localStorage.setItem('ritCyberguardSession', JSON.stringify(sessionData));
            sessionStorage.setItem('ritCyberguardActiveSession', 'true');
        } catch (error) {
            console.warn('Could not store user session:', error);
        }
    }

    getStoredSession() {
        try {
            const sessionData = localStorage.getItem('ritCyberguardSession');
            return sessionData ? JSON.parse(sessionData) : null;
        } catch (error) {
            console.warn('Could not retrieve stored session:', error);
            return null;
        }
    }

    isValidSession(sessionData) {
        if (!sessionData || !sessionData.user || !sessionData.expiresAt) {
            return false;
        }

        const now = new Date();
        const expiry = new Date(sessionData.expiresAt);

        return now < expiry;
    }

    redirectToUserDashboard(user) {
        // Role-based routing
        const routes = {
            [this.userRoles.ADMIN]: '/admin/dashboard.html',
            [this.userRoles.MODERATOR]: '/moderator/dashboard.html',
            [this.userRoles.MEMBER]: '/member/dashboard.html',
            [this.userRoles.STUDENT]: '/student/dashboard.html',
            [this.userRoles.GUEST]: '/guest/welcome.html'
        };

        const targetRoute = routes[user.role] || '/dashboard.html';

        console.log(`Redirecting ${user.displayName} (${user.role}) to: ${targetRoute}`);
        console.log('User permissions:', user.permissions);

        // In a real application, redirect to the appropriate dashboard
        // window.location.href = targetRoute;

        // For demo, show the redirect information
        this.showRoleBasedWelcome(user);
    }

    showRoleBasedWelcome(user) {
        // Create a role-specific welcome modal
        const modal = document.createElement('div');
        modal.className = 'rbac-welcome-modal';
        modal.innerHTML = `
            <div class="rbac-modal-content">
                <div class="rbac-header">
                    <i class="fas fa-user-shield rbac-icon"></i>
                    <h2>Welcome, ${user.displayName}!</h2>
                    <p class="rbac-role">Role: <span class="role-badge role-${user.role}">${user.role.toUpperCase()}</span></p>
                </div>

                <div class="rbac-info">
                    <div class="rbac-details">
                        <h3><i class="fas fa-info-circle"></i> Your Account Details</h3>
                        <ul>
                            <li><strong>Username:</strong> ${user.username}</li>
                            <li><strong>Email:</strong> ${user.email}</li>
                            <li><strong>Department:</strong> ${user.department}</li>
                            <li><strong>Session Expires:</strong> ${new Date(user.sessionTimeout).toLocaleString()}</li>
                        </ul>
                    </div>

                    <div class="rbac-permissions">
                        <h3><i class="fas fa-key"></i> Your Permissions</h3>
                        <div class="permissions-list">
                            ${user.permissions.map(permission => 
                                `<span class="permission-badge">${permission.replace('_', ' ')}</span>`
                            ).join('')}
                        </div>
                    </div>
                </div>

                <div class="rbac-actions">
                    <button class="btn btn--primary" onclick="closeRBACModal()">
                        <i class="fas fa-tachometer-alt"></i>
                        Go to Dashboard
                    </button>
                    <button class="btn btn--outline" onclick="logoutUser()">
                        <i class="fas fa-sign-out-alt"></i>
                        Logout
                    </button>
                </div>
            </div>
        `;

        document.body.appendChild(modal);
        this.addRBACModalStyles();

        // Show modal with animation
        setTimeout(() => modal.classList.add('show'), 100);
    }

    addRBACModalStyles() {
        if (document.getElementById('rbac-modal-styles')) return;

        const styles = document.createElement('style');
        styles.id = 'rbac-modal-styles';
        styles.textContent = `
            .rbac-welcome-modal {
                position: fixed;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background: rgba(26, 26, 26, 0.95);
                display: flex;
                align-items: center;
                justify-content: center;
                z-index: 10000;
                opacity: 0;
                transition: opacity 0.3s ease;
            }

            .rbac-welcome-modal.show {
                opacity: 1;
            }

            .rbac-modal-content {
                background: var(--color-card-dark);
                border: 2px solid var(--color-rit-orange);
                border-radius: 12px;
                padding: 32px;
                max-width: 600px;
                width: 90%;
                max-height: 80vh;
                overflow-y: auto;
                color: var(--color-text-cyber);
                animation: modalSlideIn 0.4s ease-out;
            }

            @keyframes modalSlideIn {
                from {
                    transform: translateY(-50px) scale(0.9);
                    opacity: 0;
                }
                to {
                    transform: translateY(0) scale(1);
                    opacity: 1;
                }
            }

            .rbac-header {
                text-align: center;
                margin-bottom: 24px;
                border-bottom: 1px solid var(--color-border-cyber);
                padding-bottom: 20px;
            }

            .rbac-icon {
                font-size: 48px;
                color: var(--color-rit-orange);
                margin-bottom: 12px;
            }

            .rbac-header h2 {
                color: var(--color-text-cyber);
                margin: 8px 0;
            }

            .role-badge {
                background: linear-gradient(135deg, var(--color-rit-orange), var(--color-cyber-blue));
                color: white;
                padding: 4px 12px;
                border-radius: 16px;
                font-size: 12px;
                font-weight: bold;
                text-transform: uppercase;
                letter-spacing: 1px;
            }

            .rbac-info {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 24px;
                margin-bottom: 24px;
            }

            .rbac-details h3,
            .rbac-permissions h3 {
                color: var(--color-cyber-blue);
                margin-bottom: 12px;
                font-size: 16px;
            }

            .rbac-details ul {
                list-style: none;
                padding: 0;
            }

            .rbac-details li {
                padding: 6px 0;
                border-bottom: 1px solid rgba(0, 180, 216, 0.1);
            }

            .permissions-list {
                display: flex;
                flex-wrap: wrap;
                gap: 8px;
            }

            .permission-badge {
                background: rgba(0, 180, 216, 0.2);
                color: var(--color-cyber-blue);
                padding: 4px 8px;
                border-radius: 12px;
                font-size: 11px;
                font-weight: 500;
                text-transform: capitalize;
                border: 1px solid var(--color-cyber-blue);
            }

            .rbac-actions {
                display: flex;
                gap: 16px;
                justify-content: center;
                flex-wrap: wrap;
            }

            @media (max-width: 768px) {
                .rbac-info {
                    grid-template-columns: 1fr;
                    gap: 16px;
                }

                .rbac-modal-content {
                    padding: 20px;
                }

                .rbac-actions {
                    flex-direction: column;
                }
            }
        `;
        document.head.appendChild(styles);
    }

    // RBAC Helper Methods
    hasPermission(user, permission) {
        return user && user.permissions && user.permissions.includes(permission);
    }

    canAccessRoute(user, route) {
        const allowedRoles = this.routePermissions[route];
        return allowedRoles && allowedRoles.includes(user.role);
    }

    checkRouteAccess(route) {
        const session = this.getStoredSession();
        if (!session || !this.isValidSession(session)) {
            return false;
        }

        return this.canAccessRoute(session.user, route);
    }

    logout() {
        try {
            localStorage.removeItem('ritCyberguardSession');
            localStorage.removeItem('ritCyberguardRemembered');
            sessionStorage.clear();

            this.showNotification('Logged out successfully', 'success');

            setTimeout(() => {
                window.location.reload();
            }, 1000);
        } catch (error) {
            console.warn('Logout error:', error);
        }
    }

    setLoadingState(loading) {
        this.loginBtn.classList.toggle('loading', loading);
        this.loginBtn.disabled = loading;
        this.loadingOverlay.classList.toggle('active', loading);

        // Disable form inputs during loading
        const inputs = this.loginForm.querySelectorAll('input, button');
        inputs.forEach(input => {
            input.disabled = loading;
        });
    }

    handleSocialLogin(provider) {
        this.showNotification(`${provider.charAt(0).toUpperCase() + provider.slice(1)} login is coming soon!`, 'info');

        // In a real application, redirect to OAuth provider
        console.log(`Initiating ${provider} OAuth flow`);
    }

    handleForgotPassword() {
        // Simple prompt for demo
        const email = prompt('Enter your email address to reset password:');

        if (email) {
            if (this.isValidEmail(email)) {
                this.showNotification('Password reset link sent to your email!', 'success');
            } else {
                this.showNotification('Please enter a valid email address', 'error');
            }
        }
    }

    handleSignupRedirect() {
        this.showNotification('Redirecting to registration page...', 'info');
        // In a real application, redirect to signup page
        setTimeout(() => {
            // window.location.href = 'signup.html';
            console.log('Would redirect to signup page');
        }, 1000);
    }

    // Support Form Functions
    showSupportForm() {
        this.supportSection.style.display = 'block';
        this.supportSection.scrollIntoView({ behavior: 'smooth' });

        // Animate the support section
        this.supportSection.style.opacity = '0';
        this.supportSection.style.transform = 'translateY(20px)';

        setTimeout(() => {
            this.supportSection.style.transition = 'all 0.6s ease-out';
            this.supportSection.style.opacity = '1';
            this.supportSection.style.transform = 'translateY(0)';
        }, 100);
    }

    closeSupportForm() {
        this.supportSection.style.opacity = '0';
        this.supportSection.style.transform = 'translateY(-20px)';

        setTimeout(() => {
            this.supportSection.style.display = 'none';
        }, 300);
    }

    submitSupportForm() {
        const email = document.getElementById('supportEmail').value;
        const subject = document.getElementById('supportSubject').value;
        const message = this.quillEditor.root.innerHTML;
        const textMessage = this.quillEditor.getText().trim();

        // Validate support form
        if (!email || !this.isValidEmail(email)) {
            this.showNotification('Please enter a valid email address', 'error');
            return;
        }

        if (!subject) {
            this.showNotification('Please select an issue type', 'error');
            return;
        }

        if (textMessage.length < 10) {
            this.showNotification('Please provide more details about your issue', 'error');
            return;
        }

        // Prepare support ticket data
        const supportTicket = {
            email: email,
            subject: subject,
            message: message,
            textMessage: textMessage,
            timestamp: new Date().toISOString(),
            userAgent: navigator.userAgent,
            url: window.location.href
        };

        // Show loading state
        const submitBtn = event.target;
        const originalText = submitBtn.innerHTML;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Sending...';
        submitBtn.disabled = true;

        // Simulate sending support request
        setTimeout(() => {
            console.log('Support ticket:', supportTicket);

            // Reset button
            submitBtn.innerHTML = originalText;
            submitBtn.disabled = false;

            // Show success message
            this.showNotification('Support request sent successfully! We\'ll get back to you soon.', 'success');

            // Clear form
            document.getElementById('supportEmail').value = '';
            document.getElementById('supportSubject').value = '';
            this.quillEditor.root.innerHTML = '';

            // Close support form
            setTimeout(() => {
                this.closeSupportForm();
            }, 2000);

        }, 2000);
    }

    handleKeyboardShortcuts(e) {
        // Enter key submits form
        if (e.key === 'Enter' && (e.target === this.usernameInput || e.target === this.passwordInput)) {
            this.handleLogin(e);
        }

        // Escape key clears form or closes support form
        if (e.key === 'Escape') {
            if (this.supportSection.style.display === 'block') {
                this.closeSupportForm();
            } else {
                this.clearForm();
            }
        }

        // Ctrl/Cmd + K focuses username field
        if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
            e.preventDefault();
            this.usernameInput.focus();
        }

        // Ctrl/Cmd + H shows support form
        if ((e.ctrlKey || e.metaKey) && e.key === 'h') {
            e.preventDefault();
            this.showSupportForm();
        }
    }

    handleInputFocus(e) {
        const formGroup = e.target.closest('.form-group');
        formGroup.style.transform = 'translateY(-2px)';
        formGroup.style.transition = 'transform 0.2s ease';
    }

    handleInputBlur(e) {
        const formGroup = e.target.closest('.form-group');
        formGroup.style.transform = 'translateY(0)';
    }

    saveCredentials() {
        try {
            const credentials = {
                username: this.usernameInput.value.trim(),
                rememberMe: true,
                timestamp: new Date().toISOString()
            };

            localStorage.setItem('ritCyberguardRemembered', JSON.stringify(credentials));
        } catch (error) {
            console.warn('Could not save credentials:', error);
        }
    }

    loadRememberedCredentials() {
        try {
            const saved = localStorage.getItem('ritCyberguardRemembered');
            if (saved) {
                const credentials = JSON.parse(saved);
                this.usernameInput.value = credentials.username;
                this.rememberMe.checked = credentials.rememberMe;
            }
        } catch (error) {
            console.warn('Could not load remembered credentials:', error);
        }
    }

    clearForm() {
        this.usernameInput.value = '';
        this.passwordInput.value = '';
        this.rememberMe.checked = false;

        // Clear all validation states
        const formGroups = document.querySelectorAll('.form-group');
        formGroups.forEach(group => this.clearValidationState(group));
    }

    showNotification(message, type = 'info') {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `notification notification--${type}`;
        notification.innerHTML = `
            <i class="fas fa-${this.getNotificationIcon(type)}"></i>
            <span>${message}</span>
            <button class="notification-close"><i class="fas fa-times"></i></button>
        `;

        // Add to page
        document.body.appendChild(notification);

        // Add styles if not exist
        this.ensureNotificationStyles();

        // Show notification
        setTimeout(() => notification.classList.add('show'), 100);

        // Auto-hide after 5 seconds
        setTimeout(() => this.hideNotification(notification), 5000);

        // Close button functionality
        notification.querySelector('.notification-close').addEventListener('click', () => {
            this.hideNotification(notification);
        });
    }

    getNotificationIcon(type) {
        const icons = {
            success: 'check-circle',
            error: 'exclamation-circle',
            warning: 'exclamation-triangle',
            info: 'info-circle'
        };
        return icons[type] || 'info-circle';
    }

    hideNotification(notification) {
        notification.classList.remove('show');
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 300);
    }

    ensureNotificationStyles() {
        if (document.getElementById('notification-styles')) return;

        const styles = document.createElement('style');
        styles.id = 'notification-styles';
        styles.textContent = `
            .notification {
                position: fixed;
                top: 20px;
                right: 20px;
                max-width: 400px;
                padding: 16px 20px;
                border-radius: 8px;
                color: white;
                display: flex;
                align-items: center;
                gap: 12px;
                z-index: 10000;
                transform: translateX(100%);
                opacity: 0;
                transition: all 0.3s ease;
                box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
            }

            .notification.show {
                transform: translateX(0);
                opacity: 1;
            }

            .notification--success {
                background: linear-gradient(135deg, #00ff88, #00cc70);
            }

            .notification--error {
                background: linear-gradient(135deg, #ff4757, #ff3838);
            }

            .notification--warning {
                background: linear-gradient(135deg, #ffad00, #ff8c00);
            }

            .notification--info {
                background: linear-gradient(135deg, #00B4D8, #0077B6);
            }

            .notification-close {
                background: none;
                border: none;
                color: white;
                cursor: pointer;
                padding: 4px;
                margin-left: auto;
            }

            .notification-close:hover {
                opacity: 0.8;
            }
        `;
        document.head.appendChild(styles);
    }

    isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
}

// Global functions for HTML onclick events
function showSupportForm() {
    if (window.rbacLoginManager) {
        window.rbacLoginManager.showSupportForm();
    }
}

function closeSupportForm() {
    if (window.rbacLoginManager) {
        window.rbacLoginManager.closeSupportForm();
    }
}

function submitSupportForm() {
    if (window.rbacLoginManager) {
        window.rbacLoginManager.submitSupportForm();
    }
}

function closeRBACModal() {
    const modal = document.querySelector('.rbac-welcome-modal');
    if (modal) {
        modal.classList.remove('show');
        setTimeout(() => {
            if (modal.parentNode) {
                modal.parentNode.removeChild(modal);
            }
        }, 300);
    }
}

function logoutUser() {
    if (window.rbacLoginManager) {
        window.rbacLoginManager.logout();
    }
}

// Initialize RBAC login manager when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.rbacLoginManager = new RBACLoginManager();

    // Add demo hints for testing
    console.log(`
🔐 RIT CyberGuard RBAC Login System

Test Credentials & Roles:
• admin / admin123 (ADMIN) - Full system access
• cyberguard / cyber2025 (MODERATOR) - Event & team management
• student@ritrjpm.ac.in / student123 (STUDENT) - Basic access
• member1 / member123 (MEMBER) - Club activities
• demo / demo (GUEST) - Limited access

RBAC Features:
• Role-based authentication
• Permission-based access control
• Route protection
• Session management
• Rich text support form with Quill.js
• Keyboard shortcuts:
  - Enter: Submit form
  - Esc: Clear form/Close support
  - Ctrl+K: Focus username
  - Ctrl+H: Open support form

Each role has different permissions and dashboard access!
Try logging in with different roles to see the RBAC system in action.
    `);
});

// Export for potential module usage
if (typeof module !== 'undefined' && module.exports) {
    module.exports = RBACLoginManager;
}
