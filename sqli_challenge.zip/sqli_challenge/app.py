from flask import Flask, request, redirect, session
import sqlite3

app = Flask(__name__)
app.secret_key = "supersecretkey"  # required for sessions

# ----------------------
# Database Initialization
# ----------------------
def init_db():
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()
    
    cursor.execute("DROP TABLE IF EXISTS users")
    cursor.execute("""
        CREATE TABLE users (
            username TEXT,
            password TEXT,
            role TEXT
        )
    """)

    cursor.execute("INSERT INTO users VALUES ('admin', 'supersecret', 'admin')")
    cursor.execute("INSERT INTO users VALUES ('john', 'john123', 'user')")
    conn.commit()
    conn.close()

# Initialize DB
init_db()

# ----------------------
# Routes
# ----------------------
@app.route('/')
def home():
    return '''
        <h2>Login Page</h2>
        <form method="POST" action="/login">
            Username: <input name="username"><br>
            Password: <input name="password"><br>
            <input type="submit">
        </form>
    '''

@app.route('/login', methods=['POST'])
def login():
    username = request.form['username']
    password = request.form['password']

    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()

    # ⚠️ Vulnerable SQL (for CTF / SQLi practice)
    query = f"SELECT username, role FROM users WHERE username='{username}' AND password='{password}'"
    result = cursor.execute(query).fetchone()
    conn.close()

    if result:
        session['username'] = result[0]
        session['role'] = result[1]
        return redirect('/dashboard')
    else:
        return "Invalid credentials"

@app.route('/dashboard')
def dashboard():
    if 'username' in session:
        return f"""
            <h2>Welcome {session['username']}</h2>
            <p>Your role is: {session['role']}</p>
            <a href="/admin">Go to Admin Page</a><br>
            <a href="/logout">Logout</a>
        """
    else:
        return redirect('/')

@app.route('/admin')
def admin():
    if 'role' in session and session['role'] == 'admin':
        return "FLAG{sqli_admin_master}"
    else:
        return "Access Denied"

@app.route('/logout')
def logout():
    session.clear()
    return redirect('/')

# ----------------------
# Run Server
# ----------------------
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=3000)