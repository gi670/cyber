# Update the main app.py file
updated_app_py_content = '''"""
RIT CyberGuard - Flask Backend Application
=========================================
Main Flask application for RIT CyberGuard cybersecurity club website.
"""

from flask import Flask, render_template, request, jsonify, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
from flask_mail import Mail, Message
from datetime import datetime
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Initialize Flask app
app = Flask(__name__)

# Configuration
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY') or 'rit-cyberguard-secret-key-2025'
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL') or 'sqlite:///rit_cyberguard.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Mail Configuration
app.config['MAIL_SERVER'] = os.environ.get('MAIL_SERVER') or 'smtp.gmail.com'
app.config['MAIL_PORT'] = int(os.environ.get('MAIL_PORT') or 587)
app.config['MAIL_USE_TLS'] = os.environ.get('MAIL_USE_TLS', 'true').lower() in ['true', 'on', '1']
app.config['MAIL_USERNAME'] = os.environ.get('MAIL_USERNAME') or 'cyberguard@ritrjpm.ac.in'
app.config['MAIL_PASSWORD'] = os.environ.get('MAIL_PASSWORD')
app.config['MAIL_DEFAULT_SENDER'] = os.environ.get('MAIL_DEFAULT_SENDER') or 'RIT CyberGuard <cyberguard@ritrjpm.ac.in>'

# Club Configuration
app.config['CLUB_NAME'] = 'RIT CyberGuard'
app.config['CLUB_EMAIL'] = 'cyberguard@ritrjpm.ac.in'
app.config['CLUB_PHONE'] = '9489634752'
app.config['CLUB_ADDRESS'] = 'North Venganallur Village, Rajapalayam, Tamil Nadu - 626117'
app.config['MEETING_DAY'] = 'Wednesday'
app.config['MEETING_TIME'] = '4:00 PM'
app.config['MEETING_LOCATION'] = 'Computer Science Lab'

# Initialize extensions
db = SQLAlchemy(app)
cors = CORS(app)
mail = Mail(app)

# Import models after db initialization
with app.app_context():
    from models import User, Team, TeamMember, Event, EventRegistration, Activity, ContactForm, NewsUpdate
    
    # Import and register routes
    from routes import register_routes
    register_routes(app, db, mail)

@app.before_first_request
def create_tables():
    """Create database tables if they don't exist"""
    db.create_all()
    
    # Create default admin user if none exists
    if not User.query.filter_by(role='admin').first():
        admin = User(
            name='Admin User',
            email='admin@ritrjpm.ac.in',
            department='Computer Science',
            year='Faculty',
            role='admin'
        )
        db.session.add(admin)
        
        # Create default teams
        teams_data = [
            {
                'name': 'Core Team',
                'description': 'Founding members leading club activities and strategic direction',
                'meeting_day': 'Monday',
                'meeting_time': '5:00 PM',
                'meeting_location': 'Computer Science Lab'
            },
            {
                'name': 'Technical Team',
                'description': 'Hands-on cybersecurity learning through labs and practical exercises',
                'meeting_day': 'Wednesday',
                'meeting_time': '4:00 PM',
                'meeting_location': 'Computer Science Lab'
            },
            {
                'name': 'Awareness Team',
                'description': 'Promoting cybersecurity awareness across RIT campus and community',
                'meeting_day': 'Friday',
                'meeting_time': '4:00 PM',
                'meeting_location': 'Computer Science Lab'
            }
        ]
        
        for team_data in teams_data:
            team = Team(
                name=team_data['name'],
                description=team_data['description'],
                meeting_day=team_data['meeting_day'],
                meeting_time=team_data['meeting_time'],
                meeting_location=team_data['meeting_location'],
                team_lead_id=admin.id
            )
            db.session.add(team)
        
        # Create default activities
        activities_data = [
            {
                'name': 'Ethical Hacking Lab',
                'description': 'Learn penetration testing basics and ethical hacking techniques in a safe environment',
                'category': 'lab',
                'difficulty_level': 'beginner'
            },
            {
                'name': 'Capture The Flag',
                'description': 'Practice cybersecurity skills through CTF challenges and competitions',
                'category': 'competition',
                'difficulty_level': 'intermediate'
            },
            {
                'name': 'Cyber Awareness',
                'description': 'Digital literacy workshops for students and faculty across all departments',
                'category': 'awareness',
                'difficulty_level': 'beginner'
            },
            {
                'name': 'Web Security',
                'description': 'Secure coding practices and web application security fundamentals',
                'category': 'workshop',
                'difficulty_level': 'intermediate'
            },
            {
                'name': 'Network Security',
                'description': 'Infrastructure protection, network monitoring, and security protocols',
                'category': 'lab',
                'difficulty_level': 'advanced'
            },
            {
                'name': 'Digital Forensics',
                'description': 'Incident response basics and digital investigation techniques',
                'category': 'lab',
                'difficulty_level': 'advanced'
            }
        ]
        
        for activity_data in activities_data:
            activity = Activity(
                name=activity_data['name'],
                description=activity_data['description'],
                category=activity_data['category'],
                difficulty_level=activity_data['difficulty_level']
            )
            db.session.add(activity)
        
        # Create sample events
        sample_events = [
            {
                'title': 'Cybersecurity Workshop',
                'description': 'Intensive workshop covering cybersecurity fundamentals for beginners',
                'event_type': 'workshop',
                'start_date': datetime(2025, 3, 15, 14, 0),
                'end_date': datetime(2025, 3, 15, 17, 0),
                'location': 'Main Auditorium',
                'max_participants': 50,
                'registration_required': True,
                'registration_deadline': datetime(2025, 3, 10, 23, 59)
            },
            {
                'title': 'Weekly Meetup',
                'description': 'Regular meeting for learning, discussion, and hands-on activities',
                'event_type': 'meetup',
                'start_date': datetime(2025, 2, 19, 16, 0),
                'end_date': datetime(2025, 2, 19, 18, 0),
                'location': 'Computer Science Lab',
                'registration_required': False
            }
        ]
        
        for event_data in sample_events:
            event = Event(
                title=event_data['title'],
                description=event_data['description'],
                event_type=event_data['event_type'],
                start_date=event_data['start_date'],
                end_date=event_data['end_date'],
                location=event_data['location'],
                max_participants=event_data.get('max_participants'),
                registration_required=event_data['registration_required'],
                registration_deadline=event_data.get('registration_deadline'),
                created_by=admin.id
            )
            db.session.add(event)
        
        db.session.commit()
        print("Default data created successfully")

@app.errorhandler(404)
def not_found_error(error):
    return jsonify({'error': 'Not found'}), 404

@app.errorhandler(500)
def internal_error(error):
    db.session.rollback()
    return jsonify({'error': 'Internal server error'}), 500

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    debug = os.environ.get('DEBUG', 'True').lower() == 'true'
    
    with app.app_context():
        db.create_all()
    
    app.run(host='0.0.0.0', port=port, debug=debug)
'''

# Write the updated app file
with open('rit_cyberguard_backend/app.py', 'w') as f:
    f.write(updated_app_py_content)

print("Updated app.py - Main Flask application with initialization")