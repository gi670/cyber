# Create the routes file
routes_py_content = '''"""
Routes for RIT CyberGuard Flask application
"""

from flask import render_template, request, jsonify, redirect, url_for, flash, current_app
from flask_mail import Message
from datetime import datetime
import json
from models import db, User, Team, TeamMember, Event, EventRegistration, Activity, ContactForm, NewsUpdate

def init_routes(app, mail):
    """Initialize all routes for the application"""
    
    # Main website routes
    @app.route('/')
    def index():
        """Main homepage"""
        # Get latest events and news
        upcoming_events = Event.query.filter(
            Event.start_date > datetime.utcnow(),
            Event.is_active == True
        ).order_by(Event.start_date.asc()).limit(3).all()
        
        recent_news = NewsUpdate.query.filter(
            NewsUpdate.is_published == True
        ).order_by(NewsUpdate.published_at.desc()).limit(3).all()
        
        # Get statistics
        stats = {
            'total_members': User.query.filter_by(is_active=True).count(),
            'active_teams': Team.query.filter_by(is_active=True).count(),
            'upcoming_events': len(upcoming_events),
            'founded_year': '2025'
        }
        
        return render_template('index.html', 
                             events=upcoming_events, 
                             news=recent_news, 
                             stats=stats)
    
    # API Routes
    
    @app.route('/api/stats')
    def get_stats():
        """Get club statistics"""
        stats = {
            'total_members': User.query.filter_by(is_active=True).count(),
            'active_teams': Team.query.filter_by(is_active=True).count(),
            'departments_represented': db.session.query(User.department).distinct().count(),
            'upcoming_events': Event.query.filter(
                Event.start_date > datetime.utcnow(),
                Event.is_active == True
            ).count(),
            'founded_year': '2025'
        }
        return jsonify(stats)
    
    @app.route('/api/teams')
    def get_teams():
        """Get all active teams"""
        teams = Team.query.filter_by(is_active=True).all()
        return jsonify([team.to_dict() for team in teams])
    
    @app.route('/api/events')
    def get_events():
        """Get upcoming events"""
        events = Event.query.filter(
            Event.start_date > datetime.utcnow(),
            Event.is_active == True
        ).order_by(Event.start_date.asc()).all()
        return jsonify([event.to_dict() for event in events])
    
    @app.route('/api/activities')
    def get_activities():
        """Get all activities"""
        activities = Activity.query.filter_by(is_active=True).all()
        return jsonify([activity.to_dict() for activity in activities])
    
    @app.route('/api/news')
    def get_news():
        """Get published news updates"""
        news = NewsUpdate.query.filter_by(is_published=True).order_by(
            NewsUpdate.published_at.desc()
        ).limit(10).all()
        return jsonify([item.to_dict() for item in news])
    
    # Contact and Registration Routes
    
    @app.route('/api/contact', methods=['POST'])
    def submit_contact_form():
        """Submit contact form"""
        try:
            data = request.get_json()
            
            # Validate required fields
            required_fields = ['name', 'email', 'message']
            if not all(field in data for field in required_fields):
                return jsonify({'error': 'Missing required fields'}), 400
            
            # Create contact form entry
            contact = ContactForm(
                name=data['name'],
                email=data['email'],
                phone=data.get('phone'),
                department=data.get('department'),
                year=data.get('year'),
                message=data['message'],
                interest_areas=json.dumps(data.get('interest_areas', []))
            )
            
            db.session.add(contact)
            db.session.commit()
            
            # Send notification email
            try:
                msg = Message(
                    subject='New Contact Form Submission - RIT CyberGuard',
                    recipients=[current_app.config['CLUB_EMAIL']],
                    html=f'''
                    <h3>New Contact Form Submission</h3>
                    <p><strong>Name:</strong> {data['name']}</p>
                    <p><strong>Email:</strong> {data['email']}</p>
                    <p><strong>Phone:</strong> {data.get('phone', 'Not provided')}</p>
                    <p><strong>Department:</strong> {data.get('department', 'Not provided')}</p>
                    <p><strong>Year:</strong> {data.get('year', 'Not provided')}</p>
                    <p><strong>Message:</strong></p>
                    <p>{data['message']}</p>
                    <p><strong>Interest Areas:</strong> {', '.join(data.get('interest_areas', []))}</p>
                    '''
                )
                mail.send(msg)
            except Exception as e:
                print(f"Failed to send email: {e}")
            
            return jsonify({'message': 'Contact form submitted successfully'}), 200
            
        except Exception as e:
            db.session.rollback()
            return jsonify({'error': str(e)}), 500
    
    @app.route('/api/join', methods=['POST'])
    def join_club():
        """Join the club"""
        try:
            data = request.get_json()
            
            # Validate required fields
            required_fields = ['name', 'email', 'department', 'year']
            if not all(field in data for field in required_fields):
                return jsonify({'error': 'Missing required fields'}), 400
            
            # Check if user already exists
            existing_user = User.query.filter_by(email=data['email']).first()
            if existing_user:
                return jsonify({'error': 'Email already registered'}), 400
            
            # Create new user
            user = User(
                name=data['name'],
                email=data['email'],
                phone=data.get('phone'),
                department=data['department'],
                year=data['year'],
                roll_number=data.get('roll_number'),
                role='member'
            )
            
            db.session.add(user)
            db.session.commit()
            
            # Send welcome email
            try:
                msg = Message(
                    subject='Welcome to RIT CyberGuard!',
                    recipients=[data['email']],
                    html=f'''
                    <h2>Welcome to RIT CyberGuard, {data['name']}!</h2>
                    <p>Thank you for joining our cybersecurity community at Ramco Institute of Technology.</p>
                    
                    <h3>Next Steps:</h3>
                    <ul>
                        <li>Join our weekly meetups every {current_app.config['MEETING_DAY']} at {current_app.config['MEETING_TIME']}</li>
                        <li>Location: {current_app.config['MEETING_LOCATION']}</li>
                        <li>Follow us on social media for updates</li>
                        <li>Choose a team that matches your interests</li>
                    </ul>
                    
                    <p>Our mission is <strong>Security Through Innovation</strong>, and we're excited to have you on this journey!</p>
                    
                    <p>Best regards,<br>
                    RIT CyberGuard Team<br>
                    {current_app.config['CLUB_EMAIL']}</p>
                    '''
                )
                mail.send(msg)
            except Exception as e:
                print(f"Failed to send welcome email: {e}")
            
            return jsonify({
                'message': 'Successfully joined RIT CyberGuard!',
                'user_id': user.uuid
            }), 200
            
        except Exception as e:
            db.session.rollback()
            return jsonify({'error': str(e)}), 500
    
    @app.route('/api/events/<int:event_id>/register', methods=['POST'])
    def register_for_event(event_id):
        """Register for an event"""
        try:
            data = request.get_json()
            email = data.get('email')
            
            if not email:
                return jsonify({'error': 'Email is required'}), 400
            
            # Check if event exists
            event = Event.query.get_or_404(event_id)
            
            # Check if event is full
            if event.is_full:
                return jsonify({'error': 'Event is full'}), 400
            
            # Check if registration deadline has passed
            if event.registration_deadline and datetime.utcnow() > event.registration_deadline:
                return jsonify({'error': 'Registration deadline has passed'}), 400
            
            # Find or create user
            user = User.query.filter_by(email=email).first()
            if not user:
                # Create temporary user for event registration
                user = User(
                    name=data.get('name', ''),
                    email=email,
                    phone=data.get('phone'),
                    department=data.get('department', ''),
                    year=data.get('year', ''),
                    role='guest'
                )
                db.session.add(user)
                db.session.flush()
            
            # Check if already registered
            existing_registration = EventRegistration.query.filter_by(
                user_id=user.id, 
                event_id=event_id, 
                is_active=True
            ).first()
            
            if existing_registration:
                return jsonify({'error': 'Already registered for this event'}), 400
            
            # Create registration
            registration = EventRegistration(
                user_id=user.id,
                event_id=event_id
            )
            
            db.session.add(registration)
            db.session.commit()
            
            return jsonify({'message': 'Successfully registered for event'}), 200
            
        except Exception as e:
            db.session.rollback()
            return jsonify({'error': str(e)}), 500
    
    # Admin routes (would normally require authentication)
    
    @app.route('/api/admin/members')
    def get_members():
        """Get all club members (admin only)"""
        members = User.query.filter(User.role != 'guest').all()
        return jsonify([member.to_dict() for member in members])
    
    @app.route('/api/admin/contact-forms')
    def get_contact_forms():
        """Get all contact form submissions (admin only)"""
        forms = ContactForm.query.order_by(ContactForm.submitted_at.desc()).all()
        return jsonify([form.to_dict() for form in forms])
    
    # Error handlers
    @app.route('/api/health')
    def health_check():
        """Health check endpoint"""
        return jsonify({
            'status': 'healthy',
            'timestamp': datetime.utcnow().isoformat(),
            'version': '1.0.0'
        })

# Import this function in app.py
def register_routes(app, mail):
    """Register all routes with the Flask app"""
    init_routes(app, mail)
'''

# Write the routes file
with open('rit_cyberguard_backend/routes.py', 'w') as f:
    f.write(routes_py_content)

print("Created routes.py - API routes and endpoints")