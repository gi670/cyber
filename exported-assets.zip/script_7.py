# Create requirements.txt
requirements_content = '''# Flask and core dependencies
Flask==2.3.3
Flask-SQLAlchemy==3.0.5
Flask-CORS==4.0.0
Flask-Mail==0.9.1
Werkzeug==2.3.7

# Database
SQLAlchemy==2.0.21

# Environment variables
python-dotenv==1.0.0

# Security
bcrypt==4.0.1

# Date and time utilities
python-dateutil==2.8.2

# JSON handling
jsonschema==4.19.1

# Email validation
email-validator==2.0.0

# Production server
gunicorn==21.2.0

# Development tools
pytest==7.4.2
pytest-flask==1.2.0
'''

# Write requirements.txt
with open('rit_cyberguard_backend/requirements.txt', 'w') as f:
    f.write(requirements_content)

print("Created requirements.txt - Python dependencies")