import os

# Create the project structure
project_structure = {
    'app.py': '',
    'config.py': '',
    'requirements.txt': '',
    'models.py': '',
    'routes.py': '',
    'database.py': '',
    'static/css/style.css': '',
    'static/js/app.js': '',
    'templates/index.html': '',
    'migrations/': '',
    '.env.example': '',
    'README.md': ''
}

# Create directories
os.makedirs('rit_cyberguard_backend/static/css', exist_ok=True)
os.makedirs('rit_cyberguard_backend/static/js', exist_ok=True)
os.makedirs('rit_cyberguard_backend/templates', exist_ok=True)
os.makedirs('rit_cyberguard_backend/migrations', exist_ok=True)

print("Created project directory structure for RIT CyberGuard Flask Backend")