# Create a comprehensive README file
readme_content = '''# RIT CyberGuard - Flask Backend

A comprehensive Flask backend application for the RIT CyberGuard cybersecurity club website at Ramco Institute of Technology, Rajapalayam, Tamil Nadu.

## Features

- **Complete Web Application**: Responsive cybersecurity club website
- **RESTful API**: Full API for managing club data
- **Database Management**: SQLAlchemy models for users, teams, events, activities
- **Email Integration**: Automated welcome emails and contact form notifications
- **Dynamic Content**: Real-time loading of teams, events, and activities
- **Contact Forms**: Member registration and contact management
- **Event Registration**: System for managing event attendees
- **Admin Dashboard**: Basic admin endpoints for club management

## Project Structure

```
rit_cyberguard_backend/
├── app.py                 # Main Flask application
├── config.py             # Configuration settings
├── models.py             # Database models
├── routes.py             # API routes and endpoints
├── database.py           # Database initialization utilities
├── requirements.txt      # Python dependencies
├── .env.example         # Environment variables template
├── static/
│   ├── css/
│   │   └── style.css    # Frontend styling
│   └── js/
│       └── app.js       # Frontend JavaScript
├── templates/
│   └── index.html       # Main HTML template
└── README.md            # This file
```

## Installation and Setup

### 1. Prerequisites

- Python 3.8 or higher
- pip (Python package installer)
- Git

### 2. Clone or Create Project

```bash
# If you have the project files, organize them in the directory structure above
# If starting fresh, create the directory
mkdir rit_cyberguard_backend
cd rit_cyberguard_backend
```

### 3. Create Virtual Environment

```bash
# Create virtual environment
python -m venv venv

# Activate virtual environment
# On Windows:
venv\\Scripts\\activate
# On macOS/Linux:
source venv/bin/activate
```

### 4. Install Dependencies

```bash
pip install -r requirements.txt
```

### 5. Environment Configuration

```bash
# Copy the environment template
cp .env.example .env

# Edit .env file with your actual values
# nano .env  # or use your preferred editor
```

Key environment variables to configure:
- `SECRET_KEY`: Your Flask secret key
- `MAIL_USERNAME`: Email for sending notifications
- `MAIL_PASSWORD`: Email password or app password
- `DATABASE_URL`: Database connection string (optional, defaults to SQLite)

### 6. Initialize Database

```bash
# Initialize the database with default data
python database.py

# Or run the app which will auto-create tables
python app.py
```

### 7. Run the Application

```bash
# Development mode
python app.py

# Or with Flask command
export FLASK_APP=app.py
export FLASK_ENV=development
flask run
```

The application will be available at `http://localhost:5000`

## API Endpoints

### Public Endpoints

- `GET /` - Main website homepage
- `GET /api/health` - Health check endpoint
- `GET /api/stats` - Club statistics
- `GET /api/teams` - List all active teams
- `GET /api/events` - List upcoming events
- `GET /api/activities` - List all activities
- `GET /api/news` - Published news updates
- `POST /api/contact` - Submit contact form
- `POST /api/join` - Join the club
- `POST /api/events/<id>/register` - Register for an event

### Admin Endpoints

- `GET /api/admin/members` - List all club members
- `GET /api/admin/contact-forms` - List contact form submissions

## Database Models

### User Model
- Personal information (name, email, phone, department, year)
- Role-based access (member, team_lead, admin)
- Team memberships and event registrations

### Team Model
- Team details (name, description, meeting schedule)
- Team leadership and member management

### Event Model
- Event information with registration capabilities
- Capacity management and deadline tracking

### Activity Model
- Different cybersecurity activities and interest groups
- Categorized by type and difficulty level

### Contact Form Model
- Contact form submissions with response tracking

## Usage Examples

### Running the Development Server

```bash
# Standard development run
python app.py

# With debug mode explicitly enabled
DEBUG=True python app.py

# Custom port
PORT=8000 python app.py
```

### Database Operations

```bash
# Initialize fresh database
python database.py

# Reset database (drops all data)
python -c "from database import reset_db; reset_db()"
```

### API Usage Examples

```bash
# Get club statistics
curl http://localhost:5000/api/stats

# Join the club
curl -X POST http://localhost:5000/api/join \\
  -H "Content-Type: application/json" \\
  -d '{
    "name": "John Doe",
    "email": "john.doe@ritrjpm.ac.in",
    "department": "Computer Science",
    "year": "2nd Year",
    "phone": "9876543210"
  }'

# Submit contact form
curl -X POST http://localhost:5000/api/contact \\
  -H "Content-Type: application/json" \\
  -d '{
    "name": "Jane Smith",
    "email": "jane.smith@ritrjpm.ac.in",
    "message": "I am interested in joining the cybersecurity club"
  }'
```

## Configuration

### Email Configuration

For email functionality to work, configure these environment variables:

```bash
MAIL_SERVER=smtp.gmail.com
MAIL_PORT=587
MAIL_USE_TLS=True
MAIL_USERNAME=your-email@gmail.com
MAIL_PASSWORD=your-app-password  # Use app password for Gmail
```

### Database Configuration

By default, the application uses SQLite. For production, use PostgreSQL:

```bash
DATABASE_URL=postgresql://username:password@localhost/rit_cyberguard
```

## Deployment

### Production Deployment with Gunicorn

```bash
# Install gunicorn (included in requirements.txt)
pip install gunicorn

# Run with gunicorn
gunicorn -w 4 -b 0.0.0.0:5000 app:app
```

### Docker Deployment

Create a `Dockerfile`:

```dockerfile
FROM python:3.9-slim

WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt

COPY . .

EXPOSE 5000
CMD ["gunicorn", "-w", "4", "-b", "0.0.0.0:5000", "app:app"]
```

### Environment Variables for Production

```bash
SECRET_KEY=your-production-secret-key
DEBUG=False
DATABASE_URL=your-production-database-url
MAIL_USERNAME=cyberguard@ritrjpm.ac.in
MAIL_PASSWORD=your-production-email-password
```

## Default Login Credentials

After running `database.py`, you can access admin functions with:
- **Email**: admin@ritrjpm.ac.in
- **Password**: admin123 (change this immediately in production)

## Club Information

- **College**: Ramco Institute of Technology
- **Location**: North Venganallur Village, Rajapalayam, Tamil Nadu - 626117
- **Affiliation**: Anna University, Chennai
- **Approval**: AICTE Approved
- **Meeting Schedule**: Every Wednesday at 4:00 PM in Computer Science Lab

## Support and Contribution

This backend is designed specifically for RIT CyberGuard at Ramco Institute of Technology. 

### Key Features Implemented:
- ✅ Complete club website with responsive design
- ✅ Member registration and management
- ✅ Event creation and registration system
- ✅ Team management with leadership roles
- ✅ Contact form with email notifications
- ✅ Activity and interest group management
- ✅ News and updates system
- ✅ Email integration for welcome messages
- ✅ RESTful API for all operations
- ✅ Mobile-responsive frontend
- ✅ Database initialization with sample data

### Future Enhancements:
- [ ] Authentication and session management
- [ ] File upload for event materials
- [ ] Advanced admin dashboard
- [ ] Social media integration
- [ ] SMS notifications
- [ ] Competition management system
- [ ] Certificate generation
- [ ] Member portfolio system

## Troubleshooting

### Common Issues

1. **Database Connection Error**
   ```bash
   # Make sure database is initialized
   python database.py
   ```

2. **Email Not Sending**
   ```bash
   # Check your email configuration in .env
   # For Gmail, use app passwords instead of regular password
   ```

3. **Static Files Not Loading**
   ```bash
   # Make sure static files are in the correct directories:
   # static/css/style.css
   # static/js/app.js
   ```

4. **Port Already in Use**
   ```bash
   # Use a different port
   PORT=8000 python app.py
   ```

## License

This project is developed for educational purposes for RIT CyberGuard at Ramco Institute of Technology.

---

**Contact Information:**
- Email: cyberguard@ritrjpm.ac.in
- Phone: +91 9489634752
- Address: North Venganallur Village, Rajapalayam, Tamil Nadu - 626117

**Mission**: Security Through Innovation
'''

# Write the README file
with open('rit_cyberguard_backend/README.md', 'w') as f:
    f.write(readme_content)

print("Created README.md - Complete setup and usage instructions")