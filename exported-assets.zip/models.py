"""
Database models for RIT CyberGuard application
"""

from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash
import uuid

db = SQLAlchemy()

class User(db.Model):
    """User model for club members and admins"""
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key=True)
    uuid = db.Column(db.String(36), unique=True, default=lambda: str(uuid.uuid4()))
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    phone = db.Column(db.String(15))
    department = db.Column(db.String(100), nullable=False)
    year = db.Column(db.String(20), nullable=False)
    roll_number = db.Column(db.String(50))
    role = db.Column(db.String(20), default='member')  # member, team_lead, admin
    is_active = db.Column(db.Boolean, default=True)
    join_date = db.Column(db.DateTime, default=datetime.utcnow)
    password_hash = db.Column(db.String(128))

    # Relationships
    team_memberships = db.relationship('TeamMember', backref='user', lazy='dynamic')
    event_registrations = db.relationship('EventRegistration', backref='user', lazy='dynamic')

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    def to_dict(self):
        return {
            'id': self.id,
            'uuid': self.uuid,
            'name': self.name,
            'email': self.email,
            'department': self.department,
            'year': self.year,
            'role': self.role,
            'is_active': self.is_active,
            'join_date': self.join_date.isoformat() if self.join_date else None
        }

    def __repr__(self):
        return f'<User {self.name}>'

class Team(db.Model):
    """Team model for different cybersecurity teams"""
    __tablename__ = 'teams'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    meeting_day = db.Column(db.String(20))
    meeting_time = db.Column(db.String(20))
    meeting_location = db.Column(db.String(100))
    team_lead_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # Relationships
    team_lead = db.relationship('User', backref='led_teams')
    members = db.relationship('TeamMember', backref='team', lazy='dynamic')

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'meeting_day': self.meeting_day,
            'meeting_time': self.meeting_time,
            'meeting_location': self.meeting_location,
            'team_lead': self.team_lead.name if self.team_lead else None,
            'member_count': self.members.count(),
            'is_active': self.is_active
        }

    def __repr__(self):
        return f'<Team {self.name}>'

class TeamMember(db.Model):
    """Association table for team memberships"""
    __tablename__ = 'team_members'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    team_id = db.Column(db.Integer, db.ForeignKey('teams.id'), nullable=False)
    role = db.Column(db.String(50), default='member')  # member, co-lead
    joined_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)

    def __repr__(self):
        return f'<TeamMember {self.user.name} in {self.team.name}>'

class Event(db.Model):
    """Event model for club events and activities"""
    __tablename__ = 'events'

    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    event_type = db.Column(db.String(50))  # workshop, meetup, competition, lecture
    start_date = db.Column(db.DateTime, nullable=False)
    end_date = db.Column(db.DateTime)
    location = db.Column(db.String(200))
    max_participants = db.Column(db.Integer)
    registration_required = db.Column(db.Boolean, default=False)
    registration_deadline = db.Column(db.DateTime)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'))

    # Relationships
    creator = db.relationship('User', backref='created_events')
    registrations = db.relationship('EventRegistration', backref='event', lazy='dynamic')

    @property
    def registration_count(self):
        return self.registrations.filter_by(is_active=True).count()

    @property
    def is_full(self):
        if self.max_participants:
            return self.registration_count >= self.max_participants
        return False

    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'description': self.description,
            'event_type': self.event_type,
            'start_date': self.start_date.isoformat() if self.start_date else None,
            'end_date': self.end_date.isoformat() if self.end_date else None,
            'location': self.location,
            'max_participants': self.max_participants,
            'registration_count': self.registration_count,
            'is_full': self.is_full,
            'registration_required': self.registration_required,
            'is_active': self.is_active
        }

    def __repr__(self):
        return f'<Event {self.title}>'

class EventRegistration(db.Model):
    """Event registration model"""
    __tablename__ = 'event_registrations'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    event_id = db.Column(db.Integer, db.ForeignKey('events.id'), nullable=False)
    registered_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)
    attended = db.Column(db.Boolean, default=False)

    def __repr__(self):
        return f'<EventRegistration {self.user.name} for {self.event.title}>'

class Activity(db.Model):
    """Activity model for different cybersecurity activities"""
    __tablename__ = 'activities'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    category = db.Column(db.String(50))  # lab, workshop, competition, awareness
    difficulty_level = db.Column(db.String(20))  # beginner, intermediate, advanced
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'category': self.category,
            'difficulty_level': self.difficulty_level,
            'is_active': self.is_active
        }

    def __repr__(self):
        return f'<Activity {self.name}>'

class ContactForm(db.Model):
    """Contact form submissions"""
    __tablename__ = 'contact_forms'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), nullable=False)
    phone = db.Column(db.String(15))
    department = db.Column(db.String(100))
    year = db.Column(db.String(20))
    message = db.Column(db.Text, nullable=False)
    interest_areas = db.Column(db.String(500))  # JSON string of selected interests
    submitted_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_responded = db.Column(db.Boolean, default=False)

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'email': self.email,
            'phone': self.phone,
            'department': self.department,
            'year': self.year,
            'message': self.message,
            'interest_areas': self.interest_areas,
            'submitted_at': self.submitted_at.isoformat() if self.submitted_at else None,
            'is_responded': self.is_responded
        }

    def __repr__(self):
        return f'<ContactForm {self.name}>'

class NewsUpdate(db.Model):
    """News and updates model"""
    __tablename__ = 'news_updates'

    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    content = db.Column(db.Text, nullable=False)
    category = db.Column(db.String(50))  # news, announcement, achievement
    is_published = db.Column(db.Boolean, default=False)
    published_at = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'))

    # Relationships
    author = db.relationship('User', backref='news_updates')

    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'content': self.content,
            'category': self.category,
            'is_published': self.is_published,
            'published_at': self.published_at.isoformat() if self.published_at else None,
            'author': self.author.name if self.author else None
        }

    def __repr__(self):
        return f'<NewsUpdate {self.title}>'
