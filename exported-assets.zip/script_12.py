# Read the original CSS file content and write it to the static folder
# Since the CSS is very large, I'll copy it as-is

# First, let me create a simplified version of the CSS that maintains the styling
css_content = '''/* RIT CyberGuard Styles - Based on original design */
:root {
  /* Color Variables */
  --color-rit-orange: #F76902;
  --color-rit-orange-dark: #D55A02;
  --color-cyber-blue: #00B4D8;
  --color-cyber-blue-dark: #0077B6;
  --color-dark-bg: #1a1a1a;
  --color-darker-bg: #111111;
  --color-card-dark: #2a2a2a;
  --color-border-cyber: rgba(0, 180, 216, 0.2);
  --color-text-cyber: #e0f7ff;
  
  /* Spacing */
  --space-8: 8px;
  --space-12: 12px;
  --space-16: 16px;
  --space-20: 20px;
  --space-24: 24px;
  --space-32: 32px;
  
  /* Border Radius */
  --radius-base: 8px;
  --radius-lg: 12px;
  
  /* Font Sizes */
  --font-size-sm: 14px;
  --font-size-base: 16px;
  --font-size-lg: 18px;
  --font-size-xl: 20px;
  --font-size-2xl: 24px;
  --font-size-3xl: 32px;
  --font-size-4xl: 40px;
  
  /* Transitions */
  --duration-normal: 250ms;
  --ease-standard: cubic-bezier(0.16, 1, 0.3, 1);
}

/* Base Styles */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: "Inter", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  background: var(--color-dark-bg);
  color: var(--color-text-cyber);
  line-height: 1.6;
}

.container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 var(--space-16);
}

/* Header Styles */
.header {
  background: linear-gradient(135deg, var(--color-darker-bg) 0%, var(--color-dark-bg) 100%);
  border-bottom: 2px solid var(--color-rit-orange);
  position: sticky;
  top: 0;
  z-index: 1000;
  box-shadow: 0 2px 20px rgba(0, 0, 0, 0.5);
}

.header-content {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: var(--space-16) 0;
}

.logo-section {
  display: flex;
  flex-direction: column;
}

.logo {
  font-size: var(--font-size-3xl);
  font-weight: 700;
  color: var(--color-rit-orange);
  margin: 0;
  letter-spacing: 2px;
  text-shadow: 0 0 10px rgba(247, 105, 2, 0.3);
}

.tagline {
  font-size: var(--font-size-sm);
  color: rgba(224, 247, 255, 0.7);
  margin: 0;
  letter-spacing: 1px;
}

.nav {
  display: flex;
  gap: var(--space-24);
  align-items: center;
}

.nav-link {
  color: var(--color-text-cyber);
  text-decoration: none;
  font-weight: 500;
  font-size: var(--font-size-base);
  transition: all var(--duration-normal) var(--ease-standard);
  position: relative;
  padding: var(--space-8) var(--space-12);
  border-radius: var(--radius-base);
}

.nav-link:hover,
.nav-link.active {
  color: var(--color-rit-orange);
  background: rgba(247, 105, 2, 0.1);
}

.nav-link::after {
  content: '';
  position: absolute;
  bottom: -2px;
  left: 50%;
  width: 0;
  height: 2px;
  background: var(--color-rit-orange);
  transition: all var(--duration-normal) var(--ease-standard);
  transform: translateX(-50%);
}

.nav-link:hover::after,
.nav-link.active::after {
  width: 80%;
}

.mobile-menu-toggle {
  display: none;
  flex-direction: column;
  background: none;
  border: none;
  cursor: pointer;
  padding: var(--space-8);
}

.mobile-menu-toggle span {
  width: 25px;
  height: 3px;
  background: var(--color-rit-orange);
  margin: 3px 0;
  transition: all var(--duration-normal) var(--ease-standard);
  border-radius: 3px;
}

/* Hero Section */
.hero {
  padding: var(--space-32) 0;
  background: linear-gradient(135deg, var(--color-dark-bg) 0%, var(--color-darker-bg) 100%);
  position: relative;
  overflow: hidden;
}

.hero::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background:
    radial-gradient(circle at 20% 80%, rgba(247, 105, 2, 0.1) 0%, transparent 50%),
    radial-gradient(circle at 80% 20%, rgba(0, 180, 216, 0.1) 0%, transparent 50%);
  pointer-events: none;
}

.hero-content {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: var(--space-32);
  align-items: center;
  position: relative;
  z-index: 1;
}

.hero-title {
  font-size: var(--font-size-4xl);
  font-weight: 700;
  color: var(--color-text-cyber);
  margin-bottom: var(--space-16);
  line-height: 1.2;
}

.hero-description {
  font-size: var(--font-size-lg);
  color: rgba(224, 247, 255, 0.7);
  margin-bottom: var(--space-24);
  line-height: 1.6;
}

.hero-buttons {
  display: flex;
  gap: var(--space-16);
  flex-wrap: wrap;
}

.hero-visual {
  display: flex;
  justify-content: center;
}

.hero-stats {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: var(--space-24);
  max-width: 400px;
}

.stat-item {
  text-align: center;
  padding: var(--space-24);
  background: var(--color-card-dark);
  border-radius: var(--radius-lg);
  border: 1px solid var(--color-border-cyber);
  transition: all var(--duration-normal) var(--ease-standard);
}

.stat-item:hover {
  transform: translateY(-5px);
  box-shadow: 0 10px 30px rgba(247, 105, 2, 0.2);
  border-color: var(--color-rit-orange);
}

.stat-number {
  font-size: var(--font-size-3xl);
  font-weight: 700;
  color: var(--color-rit-orange);
  margin-bottom: var(--space-8);
}

.stat-label {
  font-size: var(--font-size-sm);
  color: rgba(224, 247, 255, 0.7);
  font-weight: 500;
}

/* Button Styles */
.btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  padding: var(--space-12) var(--space-24);
  border-radius: var(--radius-base);
  font-size: var(--font-size-base);
  font-weight: 500;
  line-height: 1.5;
  cursor: pointer;
  transition: all var(--duration-normal) var(--ease-standard);
  border: none;
  text-decoration: none;
  position: relative;
}

.btn--primary {
  background: var(--color-rit-orange);
  color: white;
}

.btn--primary:hover {
  background: var(--color-rit-orange-dark);
  transform: translateY(-2px);
}

.btn--outline {
  background: transparent;
  border: 2px solid var(--color-border-cyber);
  color: var(--color-text-cyber);
}

.btn--outline:hover {
  background: rgba(0, 180, 216, 0.1);
  border-color: var(--color-cyber-blue);
}

.btn--sm {
  padding: var(--space-8) var(--space-16);
  font-size: var(--font-size-sm);
}

.btn--full-width {
  width: 100%;
}

/* Section Styles */
.section-title {
  text-align: center;
  font-size: var(--font-size-3xl);
  font-weight: 700;
  color: var(--color-text-cyber);
  margin-bottom: var(--space-24);
  position: relative;
}

.section-title::after {
  content: '';
  position: absolute;
  bottom: -10px;
  left: 50%;
  width: 60px;
  height: 3px;
  background: var(--color-rit-orange);
  transform: translateX(-50%);
  border-radius: 3px;
}

.section-subtitle {
  text-align: center;
  font-size: var(--font-size-lg);
  color: rgba(224, 247, 255, 0.7);
  margin-bottom: var(--space-32);
  max-width: 600px;
  margin-left: auto;
  margin-right: auto;
}

/* About Section */
.about {
  padding: var(--space-32) 0;
  background: var(--color-card-dark);
}

.about-content {
  display: grid;
  grid-template-columns: 2fr 1fr;
  gap: var(--space-32);
  align-items: start;
}

.about-text p {
  font-size: var(--font-size-lg);
  margin-bottom: var(--space-16);
  line-height: 1.7;
}

.recognition-list h3 {
  color: var(--color-rit-orange);
  margin-bottom: var(--space-16);
  font-size: var(--font-size-xl);
}

.recognition-list ul {
  list-style: none;
  padding: 0;
}

.recognition-list li {
  padding: var(--space-8) 0;
  padding-left: var(--space-16);
  position: relative;
  color: rgba(224, 247, 255, 0.7);
}

.recognition-list li::before {
  content: '🏆';
  position: absolute;
  left: 0;
  top: var(--space-8);
}

/* Teams Section */
.teams {
  padding: var(--space-32) 0;
}

.teams-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
  gap: var(--space-24);
}

.team-card {
  background: var(--color-card-dark);
  border: 1px solid var(--color-border-cyber);
  border-radius: var(--radius-lg);
  padding: var(--space-24);
  transition: all var(--duration-normal) var(--ease-standard);
}

.team-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 15px 40px rgba(247, 105, 2, 0.15);
  border-color: var(--color-rit-orange);
}

.team-header {
  margin-bottom: var(--space-16);
}

.team-name {
  font-size: var(--font-size-2xl);
  color: var(--color-rit-orange);
  margin-bottom: var(--space-4);
}

.team-description {
  margin-bottom: var(--space-16);
  line-height: 1.6;
}

.team-meeting {
  font-size: var(--font-size-sm);
  color: var(--color-cyber-blue);
  font-weight: 500;
  margin-bottom: var(--space-8);
}

.team-achievement {
  font-size: var(--font-size-sm);
  color: var(--color-rit-orange);
  font-weight: 500;
  background: rgba(247, 105, 2, 0.1);
  padding: var(--space-8) var(--space-12);
  border-radius: var(--radius-base);
  display: inline-block;
}

/* Groups Section (Activities) */
.groups {
  padding: var(--space-32) 0;
  background: var(--color-card-dark);
}

.groups-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: var(--space-20);
}

.group-card {
  background: var(--color-dark-bg);
  border: 1px solid var(--color-border-cyber);
  border-radius: var(--radius-base);
  padding: var(--space-20);
  transition: all var(--duration-normal) var(--ease-standard);
}

.group-card:hover {
  transform: translateY(-3px);
  border-color: var(--color-cyber-blue);
  box-shadow: 0 10px 25px rgba(0, 180, 216, 0.1);
}

.group-name {
  font-size: var(--font-size-lg);
  color: var(--color-cyber-blue);
  margin-bottom: var(--space-8);
}

.group-description {
  margin-bottom: var(--space-12);
  font-size: var(--font-size-sm);
  line-height: 1.5;
}

.group-meeting {
  font-size: 12px;
  color: var(--color-rit-orange);
  font-weight: 500;
  background: rgba(247, 105, 2, 0.1);
  padding: var(--space-8) var(--space-12);
  border-radius: 4px;
  display: inline-block;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

/* Events Section */
.events {
  padding: var(--space-32) 0;
}

.events-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: var(--space-20);
}

.event-card {
  background: var(--color-card-dark);
  border: 1px solid var(--color-border-cyber);
  border-radius: var(--radius-base);
  padding: var(--space-20);
  transition: all var(--duration-normal) var(--ease-standard);
}

.event-card:hover {
  transform: translateY(-3px);
  border-color: var(--color-rit-orange);
  box-shadow: 0 10px 25px rgba(247, 105, 2, 0.1);
}

.event-schedule {
  font-size: var(--font-size-sm);
  color: var(--color-rit-orange);
  font-weight: 600;
  margin-bottom: var(--space-8);
}

.event-name {
  font-size: var(--font-size-lg);
  color: var(--color-text-cyber);
  margin-bottom: var(--space-8);
}

.event-description {
  font-size: var(--font-size-sm);
  line-height: 1.5;
  color: rgba(224, 247, 255, 0.7);
  margin-bottom: var(--space-12);
}

.event-location {
  font-size: var(--font-size-sm);
  color: var(--color-cyber-blue);
  margin-bottom: var(--space-12);
}

/* Facilities Section (Resources) */
.facilities {
  padding: var(--space-32) 0;
  background: var(--color-card-dark);
}

.facilities-content {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: var(--space-24);
}

.facility-item {
  text-align: center;
  padding: var(--space-24);
}

.facility-item h3 {
  color: var(--color-cyber-blue);
  margin-bottom: var(--space-12);
  font-size: var(--font-size-lg);
}

.facility-item p {
  color: rgba(224, 247, 255, 0.7);
  line-height: 1.6;
}

/* Join Section */
.join {
  padding: var(--space-32) 0;
  background: var(--color-card-dark);
  text-align: center;
}

.join-description {
  font-size: var(--font-size-lg);
  color: rgba(224, 247, 255, 0.7);
  margin-bottom: var(--space-32);
  max-width: 700px;
  margin-left: auto;
  margin-right: auto;
  line-height: 1.7;
}

.join-info {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: var(--space-32);
  margin-bottom: var(--space-32);
  max-width: 800px;
  margin-left: auto;
  margin-right: auto;
}

.meeting-info h3,
.contact-info h3 {
  color: var(--color-rit-orange);
  margin-bottom: var(--space-16);
  font-size: var(--font-size-lg);
}

.meeting-item,
.contact-item {
  margin-bottom: var(--space-8);
  text-align: left;
}

.contact-item a {
  color: var(--color-cyber-blue);
}

.contact-item a:hover {
  color: var(--color-rit-orange);
}

.join-buttons {
  display: flex;
  gap: var(--space-16);
  justify-content: center;
  flex-wrap: wrap;
}

/* Footer */
.footer {
  background: var(--color-darker-bg);
  padding: var(--space-32) 0 var(--space-16);
  border-top: 2px solid var(--color-rit-orange);
}

.footer-content {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: var(--space-24);
  margin-bottom: var(--space-24);
}

.footer-section h3,
.footer-section h4 {
  color: var(--color-rit-orange);
  margin-bottom: var(--space-12);
}

.footer-section ul {
  list-style: none;
  padding: 0;
}

.footer-section li {
  margin-bottom: 4px;
}

.footer-section a {
  color: rgba(224, 247, 255, 0.7);
  text-decoration: none;
  transition: color var(--duration-normal) var(--ease-standard);
}

.footer-section a:hover {
  color: var(--color-cyber-blue);
}

.footer-bottom {
  text-align: center;
  padding-top: var(--space-16);
  border-top: 1px solid var(--color-border-cyber);
  color: rgba(224, 247, 255, 0.7);
  font-size: var(--font-size-sm);
}

/* Form Styles */
.form-group {
  margin-bottom: var(--space-16);
  text-align: left;
}

.form-control {
  display: block;
  width: 100%;
  padding: var(--space-12);
  font-size: var(--font-size-base);
  line-height: 1.5;
  color: var(--color-text-cyber);
  background-color: var(--color-dark-bg);
  border: 1px solid var(--color-border-cyber);
  border-radius: var(--radius-base);
  transition: border-color var(--duration-normal) var(--ease-standard);
}

.form-control:focus {
  outline: none;
  border-color: var(--color-rit-orange);
}

label {
  display: block;
  margin-bottom: var(--space-8);
  font-weight: 500;
  color: var(--color-text-cyber);
}

/* Responsive Design */
@media (max-width: 768px) {
  .nav {
    display: none;
  }

  .mobile-menu-toggle {
    display: flex;
  }

  .hero-content {
    grid-template-columns: 1fr;
    text-align: center;
  }

  .hero-stats {
    grid-template-columns: 1fr;
    max-width: 250px;
    margin: 0 auto;
  }

  .about-content {
    grid-template-columns: 1fr;
  }

  .join-info {
    grid-template-columns: 1fr;
    text-align: center;
  }

  .meeting-item,
  .contact-item {
    text-align: center;
  }

  .hero-title {
    font-size: var(--font-size-3xl);
  }

  .section-title {
    font-size: var(--font-size-2xl);
  }
}

@media (max-width: 480px) {
  .hero-buttons,
  .join-buttons {
    flex-direction: column;
    align-items: center;
  }

  .teams-grid,
  .groups-grid,
  .events-grid {
    grid-template-columns: 1fr;
  }
}
'''

# Write the CSS file
with open('rit_cyberguard_backend/static/css/style.css', 'w') as f:
    f.write(css_content)

print("Created static/css/style.css - Styling for the application")