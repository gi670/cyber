# Create the main Flask application file
app_py_content = '''"""
RIT CyberGuard - Flask Backend Application
=========================================
Main Flask application for RIT CyberGuard cybersecurity club website.
"""

from flask import Flask, render_template, request, jsonify, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
from flask_mail import Mail, Message
from datetime import datetime
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Initialize Flask app
app = Flask(__name__)
app.config.from_object('config.Config')

# Initialize extensions
db = SQLAlchemy(app)
cors = CORS(app)
mail = Mail(app)

# Import models and routes after app initialization
from models import *
from routes import *

@app.before_first_request
def create_tables():
    """Create database tables if they don't exist"""
    db.create_all()
    
    # Create default admin user if none exists
    if not User.query.filter_by(role='admin').first():
        admin = User(
            name='Admin User',
            email='admin@ritrjpm.ac.in',
            department='Computer Science',
            year='Faculty',
            role='admin'
        )
        db.session.add(admin)
        db.session.commit()
        print("Default admin user created")

@app.errorhandler(404)
def not_found_error(error):
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_error(error):
    db.session.rollback()
    return render_template('500.html'), 500

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    debug = os.environ.get('DEBUG', 'True').lower() == 'true'
    app.run(host='0.0.0.0', port=port, debug=debug)
'''

# Write the main app file
with open('rit_cyberguard_backend/app.py', 'w') as f:
    f.write(app_py_content)

print("Created app.py - Main Flask application")