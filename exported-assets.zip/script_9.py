# Create database initialization script
database_py_content = '''"""
Database initialization and management utilities
"""

from app import app, db
from models import User, Team, TeamMember, Event, Activity, ContactForm, NewsUpdate
from datetime import datetime

def init_db():
    """Initialize the database with default data"""
    with app.app_context():
        # Drop all tables and recreate
        db.drop_all()
        db.create_all()
        
        print("Database tables created successfully")
        
        # Create default admin user
        admin = User(
            name='Admin User',
            email='admin@ritrjpm.ac.in',
            department='Computer Science',
            year='Faculty',
            role='admin'
        )
        admin.set_password('admin123')  # Change this in production
        db.session.add(admin)
        
        # Create sample member
        member = User(
            name='John Doe',
            email='john.doe@ritrjpm.ac.in',
            phone='9876543210',
            department='Computer Science',
            year='2nd Year',
            roll_number='21CS001',
            role='member'
        )
        db.session.add(member)
        
        db.session.commit()
        
        # Create default teams
        teams_data = [
            {
                'name': 'Core Team',
                'description': 'Founding members leading club activities and strategic direction',
                'meeting_day': 'Monday',
                'meeting_time': '5:00 PM',
                'meeting_location': 'Computer Science Lab',
                'team_lead_id': admin.id
            },
            {
                'name': 'Technical Team',
                'description': 'Hands-on cybersecurity learning through labs and practical exercises',
                'meeting_day': 'Wednesday',
                'meeting_time': '4:00 PM',
                'meeting_location': 'Computer Science Lab',
                'team_lead_id': admin.id
            },
            {
                'name': 'Awareness Team',
                'description': 'Promoting cybersecurity awareness across RIT campus and community',
                'meeting_day': 'Friday',
                'meeting_time': '4:00 PM',
                'meeting_location': 'Computer Science Lab',
                'team_lead_id': admin.id
            }
        ]
        
        for team_data in teams_data:
            team = Team(**team_data)
            db.session.add(team)
        
        db.session.commit()
        
        # Add member to technical team
        tech_team = Team.query.filter_by(name='Technical Team').first()
        if tech_team:
            team_membership = TeamMember(
                user_id=member.id,
                team_id=tech_team.id,
                role='member'
            )
            db.session.add(team_membership)
        
        # Create default activities
        activities_data = [
            {
                'name': 'Ethical Hacking Lab',
                'description': 'Learn penetration testing basics and ethical hacking techniques in a safe environment',
                'category': 'lab',
                'difficulty_level': 'beginner'
            },
            {
                'name': 'Capture The Flag',
                'description': 'Practice cybersecurity skills through CTF challenges and competitions',
                'category': 'competition',
                'difficulty_level': 'intermediate'
            },
            {
                'name': 'Cyber Awareness',
                'description': 'Digital literacy workshops for students and faculty across all departments',
                'category': 'awareness',
                'difficulty_level': 'beginner'
            },
            {
                'name': 'Web Security',
                'description': 'Secure coding practices and web application security fundamentals',
                'category': 'workshop',
                'difficulty_level': 'intermediate'
            },
            {
                'name': 'Network Security',
                'description': 'Infrastructure protection, network monitoring, and security protocols',
                'category': 'lab',
                'difficulty_level': 'advanced'
            },
            {
                'name': 'Digital Forensics',
                'description': 'Incident response basics and digital investigation techniques',
                'category': 'lab',
                'difficulty_level': 'advanced'
            }
        ]
        
        for activity_data in activities_data:
            activity = Activity(**activity_data)
            db.session.add(activity)
        
        # Create sample events
        sample_events = [
            {
                'title': 'Cybersecurity Workshop',
                'description': 'Intensive workshop covering cybersecurity fundamentals for beginners',
                'event_type': 'workshop',
                'start_date': datetime(2025, 3, 15, 14, 0),
                'end_date': datetime(2025, 3, 15, 17, 0),
                'location': 'Main Auditorium',
                'max_participants': 50,
                'registration_required': True,
                'registration_deadline': datetime(2025, 3, 10, 23, 59),
                'created_by': admin.id
            },
            {
                'title': 'Weekly Meetup',
                'description': 'Regular meeting for learning, discussion, and hands-on activities',
                'event_type': 'meetup',
                'start_date': datetime(2025, 2, 19, 16, 0),
                'end_date': datetime(2025, 2, 19, 18, 0),
                'location': 'Computer Science Lab',
                'registration_required': False,
                'created_by': admin.id
            },
            {
                'title': 'Industry Guest Lecture',
                'description': 'Learn from cybersecurity professionals and industry experts',
                'event_type': 'lecture',
                'start_date': datetime(2025, 4, 10, 15, 0),
                'end_date': datetime(2025, 4, 10, 17, 0),
                'location': 'Main Auditorium',
                'max_participants': 100,
                'registration_required': True,
                'registration_deadline': datetime(2025, 4, 5, 23, 59),
                'created_by': admin.id
            }
        ]
        
        for event_data in sample_events:
            event = Event(**event_data)
            db.session.add(event)
        
        # Create sample news
        news_data = [
            {
                'title': 'Welcome to RIT CyberGuard!',
                'content': 'We are excited to announce the launch of RIT CyberGuard, our new cybersecurity club at Ramco Institute of Technology. Join us on our mission of Security Through Innovation!',
                'category': 'announcement',
                'is_published': True,
                'published_at': datetime.utcnow(),
                'created_by': admin.id
            },
            {
                'title': 'First Club Meeting Scheduled',
                'content': 'Our first official club meeting is scheduled for Wednesday, February 19th at 4:00 PM in the Computer Science Lab. All students are welcome to attend and learn about our upcoming activities.',
                'category': 'news',
                'is_published': True,
                'published_at': datetime.utcnow(),
                'created_by': admin.id
            }
        ]
        
        for news_item in news_data:
            news = NewsUpdate(**news_item)
            db.session.add(news)
        
        db.session.commit()
        print("Default data created successfully")
        print("\\nDefault login credentials:")
        print("Email: admin@ritrjpm.ac.in")
        print("Password: admin123")

def reset_db():
    """Reset the database (drop and recreate all tables)"""
    with app.app_context():
        db.drop_all()
        print("All tables dropped")
        init_db()

if __name__ == '__main__':
    init_db()
'''

# Write database.py
with open('rit_cyberguard_backend/database.py', 'w') as f:
    f.write(database_py_content)

print("Created database.py - Database initialization script")