// RIT CyberGuard Backend Integration JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Initialize the application
    initializeApp();
});

function initializeApp() {
    setupNavigation();
    loadDynamicContent();
    setupEventListeners();
    setupScrollEffects();
}

// Navigation and UI
function setupNavigation() {
    const hamburger = document.querySelector('.mobile-menu-toggle');
    const nav = document.querySelector('.nav');

    if (hamburger) {
        hamburger.addEventListener('click', function() {
            hamburger.classList.toggle('active');
            nav.classList.toggle('active');
        });
    }

    // Smooth scrolling for navigation links
    const navLinks = document.querySelectorAll('.nav-link, .btn[href^="#"]');
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            const targetSection = document.querySelector(targetId);

            if (targetSection) {
                const headerHeight = document.querySelector('.header').offsetHeight;
                const targetPosition = targetSection.offsetTop - headerHeight;

                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
            }

            // Close mobile menu if open
            hamburger?.classList.remove('active');
            nav?.classList.remove('active');
        });
    });
}

function setupScrollEffects() {
    // Active navigation highlighting
    function updateActiveNavLink() {
        const sections = document.querySelectorAll('section[id]');
        const navLinks = document.querySelectorAll('.nav-link');
        const scrollPos = window.scrollY + 100;

        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            const sectionHeight = section.offsetHeight;
            const sectionId = section.getAttribute('id');

            if (scrollPos >= sectionTop && scrollPos < sectionTop + sectionHeight) {
                navLinks.forEach(link => link.classList.remove('active'));
                const activeLink = document.querySelector(`a[href="#${sectionId}"]`);
                if (activeLink) {
                    activeLink.classList.add('active');
                }
            }
        });
    }

    window.addEventListener('scroll', updateActiveNavLink);
    updateActiveNavLink(); // Initial call
}

function setupEventListeners() {
    // Form submission buttons
    const joinButtons = document.querySelectorAll('[onclick="showJoinForm()"]');
    joinButtons.forEach(button => {
        button.removeAttribute('onclick');
        button.addEventListener('click', showJoinForm);
    });

    const contactButtons = document.querySelectorAll('[onclick="showContactForm()"]');
    contactButtons.forEach(button => {
        button.removeAttribute('onclick');
        button.addEventListener('click', showContactForm);
    });
}

// Dynamic Content Loading
async function loadDynamicContent() {
    try {
        await Promise.all([
            loadTeams(),
            loadActivities(),
            loadEvents(),
            loadStats()
        ]);
    } catch (error) {
        console.error('Error loading dynamic content:', error);
    }
}

async function loadTeams() {
    try {
        const response = await fetch('/api/teams');
        const teams = await response.json();
        const teamsGrid = document.getElementById('teams-grid');

        if (teamsGrid && teams.length > 0) {
            teamsGrid.innerHTML = teams.map(team => `
                <div class="team-card">
                    <div class="team-header">
                        <h3 class="team-name">${team.name}</h3>
                    </div>
                    <p class="team-description">${team.description}</p>
                    <div class="team-meeting">
                        📅 ${team.meeting_day} at ${team.meeting_time}
                    </div>
                    <div class="team-meeting">
                        📍 ${team.meeting_location}
                    </div>
                    <div class="team-achievement">
                        👥 ${team.member_count} members
                    </div>
                </div>
            `).join('');
        } else if (teamsGrid) {
            // Fallback content
            teamsGrid.innerHTML = getDefaultTeamsHTML();
        }
    } catch (error) {
        console.error('Error loading teams:', error);
        const teamsGrid = document.getElementById('teams-grid');
        if (teamsGrid) {
            teamsGrid.innerHTML = getDefaultTeamsHTML();
        }
    }
}

async function loadActivities() {
    try {
        const response = await fetch('/api/activities');
        const activities = await response.json();
        const activitiesGrid = document.getElementById('activities-grid');

        if (activitiesGrid && activities.length > 0) {
            activitiesGrid.innerHTML = activities.map(activity => `
                <div class="group-card">
                    <h3 class="group-name">${activity.name}</h3>
                    <p class="group-description">${activity.description}</p>
                    <div class="group-meeting">
                        ${activity.category} • ${activity.difficulty_level}
                    </div>
                </div>
            `).join('');
        } else if (activitiesGrid) {
            // Fallback content
            activitiesGrid.innerHTML = getDefaultActivitiesHTML();
        }
    } catch (error) {
        console.error('Error loading activities:', error);
        const activitiesGrid = document.getElementById('activities-grid');
        if (activitiesGrid) {
            activitiesGrid.innerHTML = getDefaultActivitiesHTML();
        }
    }
}

async function loadEvents() {
    try {
        const response = await fetch('/api/events');
        const events = await response.json();
        const eventsGrid = document.getElementById('events-grid');

        if (eventsGrid && events.length > 0) {
            eventsGrid.innerHTML = events.map(event => `
                <div class="event-card">
                    <div class="event-schedule">
                        ${formatEventDate(event.start_date)}
                    </div>
                    <h3 class="event-name">${event.title}</h3>
                    <p class="event-description">${event.description}</p>
                    <div class="event-location">📍 ${event.location}</div>
                    ${event.registration_required ? `
                        <button class="btn btn--primary btn--sm" onclick="registerForEvent(${event.id})">
                            ${event.is_full ? 'Full' : 'Register'}
                        </button>
                    ` : ''}
                </div>
            `).join('');
        } else if (eventsGrid) {
            // Fallback content
            eventsGrid.innerHTML = getDefaultEventsHTML();
        }
    } catch (error) {
        console.error('Error loading events:', error);
        const eventsGrid = document.getElementById('events-grid');
        if (eventsGrid) {
            eventsGrid.innerHTML = getDefaultEventsHTML();
        }
    }
}

async function loadStats() {
    try {
        const response = await fetch('/api/stats');
        const stats = await response.json();

        // Update statistics if elements exist
        const statMembers = document.getElementById('stat-members');
        const statTeams = document.getElementById('stat-teams');
        const statYear = document.getElementById('stat-year');

        if (statMembers) statMembers.textContent = stats.total_members + '+';
        if (statTeams) statTeams.textContent = stats.active_teams;
        if (statYear) statYear.textContent = stats.founded_year;
    } catch (error) {
        console.error('Error loading stats:', error);
    }
}

// Form Handling
function showJoinForm() {
    const formHTML = `
        <h2>Join RIT CyberGuard</h2>
        <form id="join-form" onsubmit="submitJoinForm(event)">
            <div class="form-group">
                <label for="name">Full Name *</label>
                <input type="text" id="name" name="name" required class="form-control">
            </div>

            <div class="form-group">
                <label for="email">Email Address *</label>
                <input type="email" id="email" name="email" required class="form-control">
            </div>

            <div class="form-group">
                <label for="phone">Phone Number</label>
                <input type="tel" id="phone" name="phone" class="form-control">
            </div>

            <div class="form-group">
                <label for="department">Department *</label>
                <select id="department" name="department" required class="form-control">
                    <option value="">Select Department</option>
                    <option value="Computer Science">Computer Science & Engineering</option>
                    <option value="Information Technology">Information Technology</option>
                    <option value="Electronics">Electronics & Communication</option>
                    <option value="Electrical">Electrical & Electronics</option>
                    <option value="Mechanical">Mechanical Engineering</option>
                    <option value="Civil">Civil Engineering</option>
                    <option value="Other">Other</option>
                </select>
            </div>

            <div class="form-group">
                <label for="year">Year of Study *</label>
                <select id="year" name="year" required class="form-control">
                    <option value="">Select Year</option>
                    <option value="1st Year">1st Year</option>
                    <option value="2nd Year">2nd Year</option>
                    <option value="3rd Year">3rd Year</option>
                    <option value="4th Year">4th Year</option>
                    <option value="PG">Post Graduate</option>
                </select>
            </div>

            <div class="form-group">
                <label for="roll_number">Roll Number</label>
                <input type="text" id="roll_number" name="roll_number" class="form-control">
            </div>

            <button type="submit" class="btn btn--primary btn--full-width">Join Club</button>
        </form>
    `;

    showModal(formHTML);
}

function showContactForm() {
    const formHTML = `
        <h2>Contact RIT CyberGuard</h2>
        <form id="contact-form" onsubmit="submitContactForm(event)">
            <div class="form-group">
                <label for="contact-name">Full Name *</label>
                <input type="text" id="contact-name" name="name" required class="form-control">
            </div>

            <div class="form-group">
                <label for="contact-email">Email Address *</label>
                <input type="email" id="contact-email" name="email" required class="form-control">
            </div>

            <div class="form-group">
                <label for="contact-phone">Phone Number</label>
                <input type="tel" id="contact-phone" name="phone" class="form-control">
            </div>

            <div class="form-group">
                <label for="contact-department">Department</label>
                <input type="text" id="contact-department" name="department" class="form-control">
            </div>

            <div class="form-group">
                <label for="contact-year">Year of Study</label>
                <input type="text" id="contact-year" name="year" class="form-control">
            </div>

            <div class="form-group">
                <label for="message">Message *</label>
                <textarea id="message" name="message" required class="form-control" rows="4"></textarea>
            </div>

            <button type="submit" class="btn btn--primary btn--full-width">Send Message</button>
        </form>
    `;

    showModal(formHTML);
}

async function submitJoinForm(event) {
    event.preventDefault();

    const form = event.target;
    const formData = new FormData(form);
    const data = Object.fromEntries(formData);

    try {
        const response = await fetch('/api/join', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data)
        });

        const result = await response.json();

        if (response.ok) {
            showNotification(result.message, 'success');
            closeModal();
        } else {
            showNotification(result.error || 'Failed to join club', 'error');
        }
    } catch (error) {
        console.error('Error submitting join form:', error);
        showNotification('Network error. Please try again.', 'error');
    }
}

async function submitContactForm(event) {
    event.preventDefault();

    const form = event.target;
    const formData = new FormData(form);
    const data = Object.fromEntries(formData);

    try {
        const response = await fetch('/api/contact', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data)
        });

        const result = await response.json();

        if (response.ok) {
            showNotification(result.message, 'success');
            closeModal();
        } else {
            showNotification(result.error || 'Failed to send message', 'error');
        }
    } catch (error) {
        console.error('Error submitting contact form:', error);
        showNotification('Network error. Please try again.', 'error');
    }
}

async function registerForEvent(eventId) {
    // Simple registration - in a real app, you'd want a proper form
    const email = prompt('Enter your email to register:');
    if (!email) return;

    try {
        const response = await fetch(`/api/events/${eventId}/register`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ email: email })
        });

        const result = await response.json();

        if (response.ok) {
            showNotification(result.message, 'success');
            loadEvents(); // Reload events to update registration status
        } else {
            showNotification(result.error || 'Registration failed', 'error');
        }
    } catch (error) {
        console.error('Error registering for event:', error);
        showNotification('Network error. Please try again.', 'error');
    }
}

// Modal Functions
function showModal(content) {
    const modal = document.getElementById('form-modal');
    const container = document.getElementById('form-container');

    if (modal && container) {
        container.innerHTML = content;
        modal.style.display = 'flex';
        document.body.style.overflow = 'hidden';
    }
}

function closeModal() {
    const modal = document.getElementById('form-modal');
    if (modal) {
        modal.style.display = 'none';
        document.body.style.overflow = '';
    }
}

// Click outside modal to close
document.addEventListener('click', function(event) {
    const modal = document.getElementById('form-modal');
    if (event.target === modal) {
        closeModal();
    }
});

// Notification Function
function showNotification(message, type = 'info') {
    // Remove existing notifications
    const existing = document.querySelector('.notification');
    if (existing) {
        existing.remove();
    }

    const notification = document.createElement('div');
    notification.className = `notification notification--${type}`;
    notification.textContent = message;

    // Add styles if not already added
    if (!document.querySelector('style[data-notification]')) {
        const style = document.createElement('style');
        style.setAttribute('data-notification', 'true');
        style.textContent = `
            .notification {
                position: fixed;
                top: 20px;
                right: 20px;
                padding: 12px 20px;
                border-radius: 8px;
                font-weight: 500;
                z-index: 10000;
                max-width: 300px;
                box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
                animation: slideIn 0.3s ease;
            }
            .notification--success {
                background: #00B4D8;
                color: white;
            }
            .notification--error {
                background: #F76902;
                color: white;
            }
            .notification--info {
                background: #333;
                color: white;
            }
            @keyframes slideIn {
                from { transform: translateX(100%); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
            }
            .modal {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0, 0, 0, 0.8);
                display: flex;
                align-items: center;
                justify-content: center;
                z-index: 9999;
            }
            .modal-content {
                background: #2a2a2a;
                padding: 2rem;
                border-radius: 12px;
                max-width: 500px;
                width: 90%;
                max-height: 90vh;
                overflow-y: auto;
                position: relative;
            }
            .close {
                position: absolute;
                top: 10px;
                right: 15px;
                font-size: 24px;
                cursor: pointer;
                color: #999;
            }
            .close:hover {
                color: #F76902;
            }
        `;
        document.head.appendChild(style);
    }

    document.body.appendChild(notification);

    // Auto remove after 5 seconds
    setTimeout(() => {
        notification.remove();
    }, 5000);
}

// Utility Functions
function formatEventDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-IN', {
        weekday: 'short',
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

// Fallback content functions
function getDefaultTeamsHTML() {
    return `
        <div class="team-card">
            <div class="team-header">
                <h3 class="team-name">Core Team</h3>
            </div>
            <p class="team-description">Founding members leading club activities and strategic direction</p>
            <div class="team-meeting">📅 Monday at 5:00 PM</div>
            <div class="team-meeting">📍 Computer Science Lab</div>
            <div class="team-achievement">👥 Leadership & coordination</div>
        </div>
        <div class="team-card">
            <div class="team-header">
                <h3 class="team-name">Technical Team</h3>
            </div>
            <p class="team-description">Hands-on cybersecurity learning through labs and practical exercises</p>
            <div class="team-meeting">📅 Wednesday at 4:00 PM</div>
            <div class="team-meeting">📍 Computer Science Lab</div>
            <div class="team-achievement">👥 Technical skill development</div>
        </div>
        <div class="team-card">
            <div class="team-header">
                <h3 class="team-name">Awareness Team</h3>
            </div>
            <p class="team-description">Promoting cybersecurity awareness across RIT campus and community</p>
            <div class="team-meeting">📅 Friday at 4:00 PM</div>
            <div class="team-meeting">📍 Computer Science Lab</div>
            <div class="team-achievement">👥 Education and outreach</div>
        </div>
    `;
}

function getDefaultActivitiesHTML() {
    return `
        <div class="group-card">
            <h3 class="group-name">Ethical Hacking Lab</h3>
            <p class="group-description">Learn penetration testing basics and ethical hacking techniques in a safe environment</p>
            <div class="group-meeting">lab • beginner</div>
        </div>
        <div class="group-card">
            <h3 class="group-name">Capture The Flag</h3>
            <p class="group-description">Practice cybersecurity skills through CTF challenges and competitions</p>
            <div class="group-meeting">competition • intermediate</div>
        </div>
        <div class="group-card">
            <h3 class="group-name">Cyber Awareness</h3>
            <p class="group-description">Digital literacy workshops for students and faculty across all departments</p>
            <div class="group-meeting">awareness • beginner</div>
        </div>
        <div class="group-card">
            <h3 class="group-name">Web Security</h3>
            <p class="group-description">Secure coding practices and web application security fundamentals</p>
            <div class="group-meeting">workshop • intermediate</div>
        </div>
        <div class="group-card">
            <h3 class="group-name">Network Security</h3>
            <p class="group-description">Infrastructure protection, network monitoring, and security protocols</p>
            <div class="group-meeting">lab • advanced</div>
        </div>
        <div class="group-card">
            <h3 class="group-name">Digital Forensics</h3>
            <p class="group-description">Incident response basics and digital investigation techniques</p>
            <div class="group-meeting">lab • advanced</div>
        </div>
    `;
}

function getDefaultEventsHTML() {
    return `
        <div class="event-card">
            <div class="event-schedule">Wed, Mar 15, 2025 2:00 PM</div>
            <h3 class="event-name">Cybersecurity Workshop</h3>
            <p class="event-description">Intensive workshop covering cybersecurity fundamentals for beginners</p>
            <div class="event-location">📍 Main Auditorium</div>
        </div>
        <div class="event-card">
            <div class="event-schedule">Wed, Feb 19, 2025 4:00 PM</div>
            <h3 class="event-name">Weekly Meetup</h3>
            <p class="event-description">Regular meeting for learning, discussion, and hands-on activities</p>
            <div class="event-location">📍 Computer Science Lab</div>
        </div>
        <div class="event-card">
            <div class="event-schedule">Thu, Apr 10, 2025 3:00 PM</div>
            <h3 class="event-name">Industry Guest Lecture</h3>
            <p class="event-description">Learn from cybersecurity professionals and industry experts</p>
            <div class="event-location">📍 Main Auditorium</div>
        </div>
    `;
}
