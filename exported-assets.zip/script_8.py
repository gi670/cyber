# Create .env.example file
env_example_content = '''# RIT CyberGuard Backend Environment Variables
# Copy this file to .env and fill in your actual values

# Flask Configuration
SECRET_KEY=your-secret-key-here
DEBUG=True
FLASK_ENV=development

# Database Configuration
DATABASE_URL=sqlite:///rit_cyberguard.db

# Mail Configuration
MAIL_SERVER=smtp.gmail.com
MAIL_PORT=587
MAIL_USE_TLS=True
MAIL_USERNAME=cyberguard@ritrjpm.ac.in
MAIL_PASSWORD=your-email-password
MAIL_DEFAULT_SENDER=RIT CyberGuard <cyberguard@ritrjpm.ac.in>

# Club Configuration
CLUB_NAME=RIT CyberGuard
CLUB_EMAIL=cyberguard@ritrjpm.ac.in
CLUB_PHONE=9489634752
CLUB_ADDRESS=North Venganallur Village, Rajapalayam, Tamil Nadu - 626117

# Meeting Configuration
MEETING_DAY=Wednesday
MEETING_TIME=4:00 PM
MEETING_LOCATION=Computer Science Lab

# Server Configuration
PORT=5000
HOST=0.0.0.0
'''

# Write .env.example
with open('rit_cyberguard_backend/.env.example', 'w') as f:
    f.write(env_example_content)

print("Created .env.example - Environment variables template")