from flask import Flask, render_template, request, redirect, session
import sqlite3

app = Flask(__name__)
app.secret_key = "supersecretkey"


# -------------------------
# DATABASE INITIALIZATION
# -------------------------

def init_db():
    conn = sqlite3.connect("users.db")
    cursor = conn.cursor()

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS users(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT,
        email TEXT,
        password TEXT,
        role TEXT
    )
    """)

    conn.commit()
    conn.close()

init_db()


# -------------------------
# HOME
# -------------------------

@app.route("/")
def home():
    return redirect("/login")


# -------------------------
# REGISTER
# -------------------------

@app.route("/register", methods=["GET","POST"])
def register():

    if request.method == "POST":

        username = request.form["username"]
        email = request.form["email"]
        password = request.form["password"]

        conn = sqlite3.connect("users.db")
        cursor = conn.cursor()

        cursor.execute(
            "INSERT INTO users(username,email,password,role) VALUES(?,?,?,?)",
            (username,email,password,"user")
        )

        conn.commit()
        conn.close()

        return redirect("/login")

    return render_template("register.html")


# -------------------------
# LOGIN
# -------------------------

@app.route("/login", methods=["GET","POST"])
def login():

    if request.method == "POST":

        username = request.form["username"]
        password = request.form["password"]

        conn = sqlite3.connect("users.db")
        cursor = conn.cursor()

        cursor.execute(
            "SELECT * FROM users WHERE username=? AND password=?",
            (username,password)
        )

        user = cursor.fetchone()

        conn.close()

        if user:
            session["user"] = user[1]
            session["role"] = user[4]

            return redirect("/dashboard")

        return "Invalid login"

    return render_template("login.html")


# -------------------------
# DASHBOARD
# -------------------------

@app.route("/dashboard")
def dashboard():

    if "user" not in session:
        return redirect("/login")

    return render_template("dashboard.html", user=session["user"])


# -------------------------
# ADMIN PANEL
# -------------------------
@app.route("/admin")
def admin():

    if "user" not in session:
        return redirect("/login")

    if session.get("role") != "admin":
        return redirect("/dashboard")

    flag = "ctf{admin_access_granted}"

    return render_template("admin.html", flag=flag)
# -------------------------
# LOGOUT
# -------------------------

@app.route("/logout")
def logout():

    session.pop("user", None)
    session.pop("role", None)

    return redirect("/login")


# -------------------------
# RUN SERVER
# -------------------------

if __name__ == "__main__":
    app.run(debug=True)