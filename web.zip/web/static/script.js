/* MATRIX BACKGROUND */

const canvas = document.getElementById("matrix");
const ctx = canvas.getContext("2d");

canvas.height = window.innerHeight;
canvas.width = window.innerWidth;

const letters = "01HACKEDJERRY";
const matrix = letters.split("");

const fontSize = 14;
const columns = canvas.width / fontSize;

const drops = [];

for(let x = 0; x < columns; x++)
drops[x] = 1;

function draw(){

ctx.fillStyle = "rgba(0,0,0,0.05)";
ctx.fillRect(0,0,canvas.width,canvas.height);

ctx.fillStyle = "#0F0";
ctx.font = fontSize + "px monospace";

for(let i=0;i<drops.length;i++){

const text = matrix[Math.floor(Math.random()*matrix.length)];

ctx.fillText(text,i*fontSize,drops[i]*fontSize);

if(drops[i]*fontSize > canvas.height && Math.random()>0.975)
drops[i]=0;

drops[i]++;

}

}

setInterval(draw,33);


/* TERMINAL TYPING */

const terminal = document.getElementById("terminal");

const lines = [

"Connecting to main server...",
"Bypassing firewall...",
"Access granted...",
"Downloading database...",
"Decrypting passwords...",
"Uploading stolen files...",
"Mission Complete."

];

let lineIndex = 0;
let charIndex = 0;

function type(){

if(lineIndex < lines.length){

if(charIndex < lines[lineIndex].length){

terminal.innerHTML += lines[lineIndex].charAt(charIndex);
charIndex++;

setTimeout(type,40);

}

else{

terminal.innerHTML += "<br>";
lineIndex++;
charIndex = 0;

setTimeout(type,500);

}

}

}

type();