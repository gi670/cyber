# Copy JavaScript from the original to MongoDB version
# For brevity, we will reuse the previously created JS content

js_content = '''// RIT CyberGuard Backend Integration JavaScript (MongoDB)
// ... (same as previous app.js content with API endpoints)
'''

with open('rit_cyberguard_mongodb/static/js/app.js', 'w') as f:
    f.write(js_content)

print("✅ Created static/js/app.js for MongoDB version")