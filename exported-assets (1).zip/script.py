# Create updated requirements.txt for MongoDB
requirements_mongodb = '''# Flask and core dependencies
Flask==2.3.3
Flask-CORS==4.0.0
Flask-Mail==0.9.1
Werkzeug==2.3.7

# MongoDB dependencies
Flask-PyMongo==2.3.0
pymongo==4.5.0
bson==0.5.10

# Date and time utilities
python-dateutil==2.8.2

# JSON handling
jsonschema==4.19.1

# Environment variables
python-dotenv==1.0.0

# Security
bcrypt==4.0.1

# Email validation
email-validator==2.0.0

# Production server
gunicorn==21.2.0

# Development tools
pytest==7.4.2
pytest-flask==1.2.0

# ObjectId handling
bson==0.5.10
'''

# Write updated requirements.txt
with open('rit_cyberguard_backend/requirements_mongodb.txt', 'w') as f:
    f.write(requirements_mongodb)

print("✅ Created requirements_mongodb.txt - MongoDB dependencies")