# Create MongoDB models file
models_mongodb = '''"""
MongoDB document schemas for RIT CyberGuard application
"""

from datetime import datetime
from bson import ObjectId
from werkzeug.security import generate_password_hash, check_password_hash
import uuid

class BaseDocument:
    """Base document class with common methods"""
    
    def __init__(self, **kwargs):
        for key, value in kwargs.items():
            setattr(self, key, value)
    
    def to_dict(self):
        """Convert document to dictionary"""
        result = {}
        for key, value in self.__dict__.items():
            if isinstance(value, ObjectId):
                result[key] = str(value)
            elif isinstance(value, datetime):
                result[key] = value.isoformat()
            else:
                result[key] = value
        return result

class UserDocument(BaseDocument):
    """User document for club members and admins"""
    
    def __init__(self, **kwargs):
        super().__init__()
        self._id = kwargs.get('_id', ObjectId())
        self.uuid = kwargs.get('uuid', str(uuid.uuid4()))
        self.name = kwargs.get('name', '')
        self.email = kwargs.get('email', '')
        self.phone = kwargs.get('phone', '')
        self.department = kwargs.get('department', '')
        self.year = kwargs.get('year', '')
        self.roll_number = kwargs.get('roll_number', '')
        self.role = kwargs.get('role', 'member')  # member, team_lead, admin
        self.is_active = kwargs.get('is_active', True)
        self.join_date = kwargs.get('join_date', datetime.utcnow())
        self.password_hash = kwargs.get('password_hash', '')
        
        # References to other collections
        self.team_memberships = kwargs.get('team_memberships', [])  # List of team_member_ids
        self.event_registrations = kwargs.get('event_registrations', [])  # List of event_registration_ids
    
    def set_password(self, password):
        """Hash and set password"""
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        """Check if password is correct"""
        return check_password_hash(self.password_hash, password)
    
    @classmethod
    def create_indexes(cls, mongo):
        """Create database indexes for user collection"""
        mongo.db.users.create_index("email", unique=True)
        mongo.db.users.create_index("uuid", unique=True)
        mongo.db.users.create_index("role")
        mongo.db.users.create_index("is_active")

class TeamDocument(BaseDocument):
    """Team document for different cybersecurity teams"""
    
    def __init__(self, **kwargs):
        super().__init__()
        self._id = kwargs.get('_id', ObjectId())
        self.name = kwargs.get('name', '')
        self.description = kwargs.get('description', '')
        self.meeting_day = kwargs.get('meeting_day', '')
        self.meeting_time = kwargs.get('meeting_time', '')
        self.meeting_location = kwargs.get('meeting_location', '')
        self.team_lead_id = kwargs.get('team_lead_id')  # ObjectId reference to user
        self.is_active = kwargs.get('is_active', True)
        self.created_at = kwargs.get('created_at', datetime.utcnow())
        
        # Array of member references
        self.members = kwargs.get('members', [])  # List of member objects with user_id, role, joined_at
    
    @classmethod
    def create_indexes(cls, mongo):
        """Create database indexes for team collection"""
        mongo.db.teams.create_index("name", unique=True)
        mongo.db.teams.create_index("is_active")
        mongo.db.teams.create_index("team_lead_id")

class TeamMemberDocument(BaseDocument):
    """Team membership document"""
    
    def __init__(self, **kwargs):
        super().__init__()
        self._id = kwargs.get('_id', ObjectId())
        self.user_id = kwargs.get('user_id')  # ObjectId reference
        self.team_id = kwargs.get('team_id')  # ObjectId reference
        self.role = kwargs.get('role', 'member')  # member, co-lead
        self.joined_at = kwargs.get('joined_at', datetime.utcnow())
        self.is_active = kwargs.get('is_active', True)
    
    @classmethod
    def create_indexes(cls, mongo):
        """Create database indexes for team_members collection"""
        mongo.db.team_members.create_index([("user_id", 1), ("team_id", 1)], unique=True)
        mongo.db.team_members.create_index("is_active")

class EventDocument(BaseDocument):
    """Event document for club events and activities"""
    
    def __init__(self, **kwargs):
        super().__init__()
        self._id = kwargs.get('_id', ObjectId())
        self.title = kwargs.get('title', '')
        self.description = kwargs.get('description', '')
        self.event_type = kwargs.get('event_type', '')  # workshop, meetup, competition, lecture
        self.start_date = kwargs.get('start_date')
        self.end_date = kwargs.get('end_date')
        self.location = kwargs.get('location', '')
        self.max_participants = kwargs.get('max_participants')
        self.registration_required = kwargs.get('registration_required', False)
        self.registration_deadline = kwargs.get('registration_deadline')
        self.is_active = kwargs.get('is_active', True)
        self.created_at = kwargs.get('created_at', datetime.utcnow())
        self.created_by = kwargs.get('created_by')  # ObjectId reference to user
        
        # Array of registrations
        self.registrations = kwargs.get('registrations', [])  # List of registration objects
    
    @property
    def registration_count(self):
        """Get count of active registrations"""
        return len([r for r in self.registrations if r.get('is_active', True)])
    
    @property
    def is_full(self):
        """Check if event is at capacity"""
        if self.max_participants:
            return self.registration_count >= self.max_participants
        return False
    
    @classmethod
    def create_indexes(cls, mongo):
        """Create database indexes for events collection"""
        mongo.db.events.create_index("start_date")
        mongo.db.events.create_index("event_type")
        mongo.db.events.create_index("is_active")
        mongo.db.events.create_index("created_by")

class EventRegistrationDocument(BaseDocument):
    """Event registration document"""
    
    def __init__(self, **kwargs):
        super().__init__()
        self._id = kwargs.get('_id', ObjectId())
        self.user_id = kwargs.get('user_id')  # ObjectId reference
        self.event_id = kwargs.get('event_id')  # ObjectId reference
        self.registered_at = kwargs.get('registered_at', datetime.utcnow())
        self.is_active = kwargs.get('is_active', True)
        self.attended = kwargs.get('attended', False)
    
    @classmethod
    def create_indexes(cls, mongo):
        """Create database indexes for event_registrations collection"""
        mongo.db.event_registrations.create_index([("user_id", 1), ("event_id", 1)], unique=True)
        mongo.db.event_registrations.create_index("is_active")

class ActivityDocument(BaseDocument):
    """Activity document for different cybersecurity activities"""
    
    def __init__(self, **kwargs):
        super().__init__()
        self._id = kwargs.get('_id', ObjectId())
        self.name = kwargs.get('name', '')
        self.description = kwargs.get('description', '')
        self.category = kwargs.get('category', '')  # lab, workshop, competition, awareness
        self.difficulty_level = kwargs.get('difficulty_level', '')  # beginner, intermediate, advanced
        self.is_active = kwargs.get('is_active', True)
        self.created_at = kwargs.get('created_at', datetime.utcnow())
    
    @classmethod
    def create_indexes(cls, mongo):
        """Create database indexes for activities collection"""
        mongo.db.activities.create_index("category")
        mongo.db.activities.create_index("difficulty_level")
        mongo.db.activities.create_index("is_active")

class ContactFormDocument(BaseDocument):
    """Contact form submissions document"""
    
    def __init__(self, **kwargs):
        super().__init__()
        self._id = kwargs.get('_id', ObjectId())
        self.name = kwargs.get('name', '')
        self.email = kwargs.get('email', '')
        self.phone = kwargs.get('phone', '')
        self.department = kwargs.get('department', '')
        self.year = kwargs.get('year', '')
        self.message = kwargs.get('message', '')
        self.interest_areas = kwargs.get('interest_areas', [])  # Array of interests
        self.submitted_at = kwargs.get('submitted_at', datetime.utcnow())
        self.is_responded = kwargs.get('is_responded', False)
    
    @classmethod
    def create_indexes(cls, mongo):
        """Create database indexes for contact_forms collection"""
        mongo.db.contact_forms.create_index("submitted_at")
        mongo.db.contact_forms.create_index("is_responded")
        mongo.db.contact_forms.create_index("email")

class NewsUpdateDocument(BaseDocument):
    """News and updates document"""
    
    def __init__(self, **kwargs):
        super().__init__()
        self._id = kwargs.get('_id', ObjectId())
        self.title = kwargs.get('title', '')
        self.content = kwargs.get('content', '')
        self.category = kwargs.get('category', '')  # news, announcement, achievement
        self.is_published = kwargs.get('is_published', False)
        self.published_at = kwargs.get('published_at')
        self.created_at = kwargs.get('created_at', datetime.utcnow())
        self.created_by = kwargs.get('created_by')  # ObjectId reference to user
    
    @classmethod
    def create_indexes(cls, mongo):
        """Create database indexes for news_updates collection"""
        mongo.db.news_updates.create_index("published_at")
        mongo.db.news_updates.create_index("is_published")
        mongo.db.news_updates.create_index("category")
        mongo.db.news_updates.create_index("created_by")

# Collection names
COLLECTIONS = {
    'users': UserDocument,
    'teams': TeamDocument,
    'team_members': TeamMemberDocument,
    'events': EventDocument,
    'event_registrations': EventRegistrationDocument,
    'activities': ActivityDocument,
    'contact_forms': ContactFormDocument,
    'news_updates': NewsUpdateDocument
}

def create_all_indexes(mongo):
    """Create all database indexes"""
    for collection_name, document_class in COLLECTIONS.items():
        if hasattr(document_class, 'create_indexes'):
            document_class.create_indexes(mongo)
    print("All database indexes created successfully")
'''

# Write MongoDB models file
with open('rit_cyberguard_mongodb/models.py', 'w') as f:
    f.write(models_mongodb)

print("✅ Created models.py for MongoDB documents")