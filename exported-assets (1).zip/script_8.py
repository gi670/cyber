# Create directory structure for MongoDB version
import os

# Create all necessary directories
directories = [
    'rit_cyberguard_mongodb/static/css',
    'rit_cyberguard_mongodb/static/js',
    'rit_cyberguard_mongodb/static/images',
    'rit_cyberguard_mongodb/templates/admin',
    'rit_cyberguard_mongodb/templates/partials',
    'rit_cyberguard_mongodb/uploads',
    'rit_cyberguard_mongodb/logs'
]

for directory in directories:
    os.makedirs(directory, exist_ok=True)

print("📁 Created all directory structures for MongoDB version")

# Create a simple HTML template for MongoDB version
html_template = '''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RIT CyberGuard - Security Through Innovation</title>
    <link rel="stylesheet" href="{{ url_for('static', filename='css/style.css') }}">
    <link rel="icon" href="{{ url_for('static', filename='favicon.ico') }}">
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="container">
            <div class="header-content">
                <div class="logo-section">
                    <h1 class="logo">RIT CyberGuard</h1>
                    <p class="tagline">Security Through Innovation</p>
                </div>
                <nav class="nav">
                    <a href="#home" class="nav-link">Home</a>
                    <a href="#about" class="nav-link">About</a>
                    <a href="#teams" class="nav-link">Teams</a>
                    <a href="#activities" class="nav-link">Activities</a>
                    <a href="#events" class="nav-link">Events</a>
                    <a href="#resources" class="nav-link">Resources</a>
                    <a href="#join" class="nav-link">Join</a>
                </nav>
                <div class="mobile-menu-toggle" id="mobileMenuToggle">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </div>
        </div>
    </header>

    <!-- Hero Section -->
    <section id="home" class="hero">
        <div class="container">
            <div class="hero-content">
                <div class="hero-text">
                    <h1 class="hero-title">Welcome to RIT CyberGuard</h1>
                    <p class="hero-description">
                        Join our cybersecurity community at Ramco Institute of Technology. 
                        We're building the next generation of cybersecurity professionals through 
                        hands-on learning, innovative projects, and industry connections.
                    </p>
                    <div class="hero-buttons">
                        <a href="#join" class="btn btn--primary">Join the Club</a>
                        <a href="#about" class="btn btn--outline">Learn More</a>
                    </div>
                </div>
                <div class="hero-visual">
                    <div class="hero-stats">
                        <div class="stat-item">
                            <div class="stat-number">{{ stats.total_members if stats else '25' }}+</div>
                            <div class="stat-label">Members</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-number">{{ stats.active_teams if stats else '3' }}</div>
                            <div class="stat-label">Teams</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-number">{{ stats.founded_year if stats else '2025' }}</div>
                            <div class="stat-label">Founded</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- About Section -->
    <section id="about" class="about">
        <div class="container">
            <h2 class="section-title">About RIT CyberGuard</h2>
            <div class="about-content">
                <div class="about-text">
                    <p>
                        RIT CyberGuard is the premier cybersecurity student organization at 
                        Ramco Institute of Technology, Rajapalayam. Our mission is 
                        <strong>Security Through Innovation</strong> - fostering a culture of 
                        learning, collaboration, and ethical practice in cybersecurity.
                    </p>
                    <p>
                        We welcome students from all engineering disciplines to explore the 
                        exciting world of cybersecurity through practical workshops, competitions, 
                        and industry connections.
                    </p>
                </div>
                <div class="recognition-list">
                    <h3>Our Foundation</h3>
                    <ul>
                        <li>Affiliated with Anna University, Chennai</li>
                        <li>AICTE Approved Institution</li>
                        <li>Located in Rajapalayam, Tamil Nadu</li>
                        <li>Part of the renowned Ramco Group</li>
                        <li>Established in 2013</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <!-- Teams Section -->
    <section id="teams" class="teams">
        <div class="container">
            <h2 class="section-title">Our Teams</h2>
            <p class="section-subtitle">
                Join one of our specialized teams and build your cybersecurity expertise
            </p>
            <div class="teams-grid" id="teams-grid">
                <!-- Teams loaded dynamically via JavaScript -->
            </div>
        </div>
    </section>

    <!-- Activities Section -->
    <section id="activities" class="groups">
        <div class="container">
            <h2 class="section-title">Activities & Programs</h2>
            <p class="section-subtitle">
                Explore different areas of cybersecurity and find your passion
            </p>
            <div class="groups-grid" id="activities-grid">
                <!-- Activities loaded dynamically via JavaScript -->
            </div>
        </div>
    </section>

    <!-- Events Section -->
    <section id="events" class="events">
        <div class="container">
            <h2 class="section-title">Upcoming Events</h2>
            <p class="section-subtitle">
                Stay updated with our latest workshops, competitions, and meetings
            </p>
            <div class="events-grid" id="events-grid">
                <!-- Events loaded dynamically via JavaScript -->
            </div>
        </div>
    </section>

    <!-- Resources Section -->
    <section id="resources" class="facilities">
        <div class="container">
            <h2 class="section-title">Resources & Partnerships</h2>
            <div class="facilities-content">
                <div class="facility-item">
                    <h3>Academic Partnership</h3>
                    <p>Connected with Anna University's Centre for Cyber Security for research and academic excellence</p>
                </div>
                <div class="facility-item">
                    <h3>Learning Platforms</h3>
                    <p>Access to online cybersecurity courses, certifications, and training materials</p>
                </div>
                <div class="facility-item">
                    <h3>Lab Facilities</h3>
                    <p>Computer labs with networking equipment for hands-on cybersecurity practice</p>
                </div>
                <div class="facility-item">
                    <h3>Industry Network</h3>
                    <p>Building connections with cybersecurity professionals and companies in Tamil Nadu</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Join Section -->
    <section id="join" class="join">
        <div class="container">
            <h2 class="section-title">Join RIT CyberGuard</h2>
            <p class="join-description">
                Ready to start your cybersecurity journey? We welcome students of all skill levels 
                and backgrounds. Whether you're a complete beginner or have some experience, 
                there's a place for you in our community.
            </p>
            
            <div class="join-info">
                <div class="meeting-info">
                    <h3>Meeting Details</h3>
                    <div class="meeting-item">
                        <strong>When:</strong> Every Wednesday at 4:00 PM
                    </div>
                    <div class="meeting-item">
                        <strong>Where:</strong> Computer Science Lab
                    </div>
                    <div class="meeting-item">
                        <strong>Who:</strong> All engineering students welcome
                    </div>
                </div>
                
                <div class="contact-info">
                    <h3>Contact Us</h3>
                    <div class="contact-item">
                        <strong>Email:</strong> <a href="mailto:cyberguard@ritrjpm.ac.in">cyberguard@ritrjpm.ac.in</a>
                    </div>
                    <div class="contact-item">
                        <strong>Phone:</strong> <a href="tel:+919489634752">+91 9489634752</a>
                    </div>
                    <div class="contact-item">
                        <strong>Address:</strong> North Venganallur Village, Rajapalayam, Tamil Nadu - 626117
                    </div>
                </div>
            </div>
            
            <div class="join-buttons">
                <button class="btn btn--primary" onclick="showJoinForm()">Join Now</button>
                <button class="btn btn--outline" onclick="showContactForm()">Contact Us</button>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>RIT CyberGuard</h3>
                    <p>Security Through Innovation</p>
                    <p>Building cybersecurity excellence at Ramco Institute of Technology</p>
                </div>
                
                <div class="footer-section">
                    <h4>Quick Links</h4>
                    <ul>
                        <li><a href="#about">About</a></li>
                        <li><a href="#teams">Teams</a></li>
                        <li><a href="#events">Events</a></li>
                        <li><a href="#join">Join</a></li>
                    </ul>
                </div>
                
                <div class="footer-section">
                    <h4>Contact</h4>
                    <ul>
                        <li>cyberguard@ritrjpm.ac.in</li>
                        <li>+91 9489634752</li>
                        <li>Rajapalayam, Tamil Nadu</li>
                    </ul>
                </div>
            </div>
            
            <div class="footer-bottom">
                <p>&copy; 2025 RIT CyberGuard. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <!-- Modal for forms -->
    <div id="form-modal" class="modal" style="display: none;">
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            <div id="form-container"></div>
        </div>
    </div>

    <script src="{{ url_for('static', filename='js/app.js') }}"></script>
</body>
</html>'''

# Write HTML template
with open('rit_cyberguard_mongodb/templates/index.html', 'w') as f:
    f.write(html_template)

print("✅ Created templates/index.html for MongoDB version")