# Create main Flask application with MongoDB
app_mongodb = '''"""
RIT CyberGuard - Flask Backend Application with MongoDB
=====================================================
Main Flask application for RIT CyberGuard cybersecurity club website using MongoDB.
"""

from flask import Flask, render_template, request, jsonify
from flask_pymongo import PyMongo
from flask_cors import CORS
from flask_mail import Mail
from datetime import datetime
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Initialize Flask app
app = Flask(__name__)

# Configuration
config_name = os.environ.get('FLASK_CONFIG') or 'default'
from config import config
app.config.from_object(config[config_name])
config[config_name].init_app(app)

# Initialize extensions
mongo = PyMongo(app)
cors = CORS(app)
mail = Mail(app)

# Import models after mongo initialization
from models import create_all_indexes, COLLECTIONS
from models import (UserDocument, TeamDocument, EventDocument, 
                   ActivityDocument, ContactFormDocument, NewsUpdateDocument)

def create_app(config_name='default'):
    """Application factory function"""
    app = Flask(__name__)
    app.config.from_object(config[config_name])
    config[config_name].init_app(app)
    
    # Initialize extensions with app
    mongo.init_app(app)
    cors.init_app(app)
    mail.init_app(app)
    
    # Create indexes
    with app.app_context():
        create_all_indexes(mongo)
    
    return app

# Import and register routes
from routes import register_routes
register_routes(app, mongo, mail)

@app.before_first_request
def initialize_database():
    """Initialize database with default data"""
    try:
        # Create indexes
        create_all_indexes(mongo)
        
        # Check if admin user exists
        admin_user = mongo.db.users.find_one({'role': 'admin'})
        if not admin_user:
            # Create default admin user
            admin = UserDocument(
                name='Admin User',
                email='admin@ritrjpm.ac.in',
                department='Computer Science',
                year='Faculty',
                role='admin'
            )
            admin.set_password('admin123')  # Change this in production
            mongo.db.users.insert_one(admin.__dict__)
            print("Default admin user created")
            
            # Get the admin user ID for team creation
            admin_user = mongo.db.users.find_one({'email': 'admin@ritrjpm.ac.in'})
            admin_id = admin_user['_id']
            
            # Create default teams
            teams_data = [
                {
                    'name': 'Core Team',
                    'description': 'Founding members leading club activities and strategic direction',
                    'meeting_day': 'Monday',
                    'meeting_time': '5:00 PM',
                    'meeting_location': 'Computer Science Lab',
                    'team_lead_id': admin_id
                },
                {
                    'name': 'Technical Team',
                    'description': 'Hands-on cybersecurity learning through labs and practical exercises',
                    'meeting_day': 'Wednesday',
                    'meeting_time': '4:00 PM',
                    'meeting_location': 'Computer Science Lab',
                    'team_lead_id': admin_id
                },
                {
                    'name': 'Awareness Team',
                    'description': 'Promoting cybersecurity awareness across RIT campus and community',
                    'meeting_day': 'Friday',
                    'meeting_time': '4:00 PM',
                    'meeting_location': 'Computer Science Lab',
                    'team_lead_id': admin_id
                }
            ]
            
            for team_data in teams_data:
                team = TeamDocument(**team_data)
                mongo.db.teams.insert_one(team.__dict__)
            
            # Create default activities
            activities_data = [
                {
                    'name': 'Ethical Hacking Lab',
                    'description': 'Learn penetration testing basics and ethical hacking techniques in a safe environment',
                    'category': 'lab',
                    'difficulty_level': 'beginner'
                },
                {
                    'name': 'Capture The Flag',
                    'description': 'Practice cybersecurity skills through CTF challenges and competitions',
                    'category': 'competition',
                    'difficulty_level': 'intermediate'
                },
                {
                    'name': 'Cyber Awareness',
                    'description': 'Digital literacy workshops for students and faculty across all departments',
                    'category': 'awareness',
                    'difficulty_level': 'beginner'
                },
                {
                    'name': 'Web Security',
                    'description': 'Secure coding practices and web application security fundamentals',
                    'category': 'workshop',
                    'difficulty_level': 'intermediate'
                },
                {
                    'name': 'Network Security',
                    'description': 'Infrastructure protection, network monitoring, and security protocols',
                    'category': 'lab',
                    'difficulty_level': 'advanced'
                },
                {
                    'name': 'Digital Forensics',
                    'description': 'Incident response basics and digital investigation techniques',
                    'category': 'lab',
                    'difficulty_level': 'advanced'
                }
            ]
            
            for activity_data in activities_data:
                activity = ActivityDocument(**activity_data)
                mongo.db.activities.insert_one(activity.__dict__)
            
            # Create sample events
            sample_events = [
                {
                    'title': 'Cybersecurity Workshop',
                    'description': 'Intensive workshop covering cybersecurity fundamentals for beginners',
                    'event_type': 'workshop',
                    'start_date': datetime(2025, 3, 15, 14, 0),
                    'end_date': datetime(2025, 3, 15, 17, 0),
                    'location': 'Main Auditorium',
                    'max_participants': 50,
                    'registration_required': True,
                    'registration_deadline': datetime(2025, 3, 10, 23, 59),
                    'created_by': admin_id
                },
                {
                    'title': 'Weekly Meetup',
                    'description': 'Regular meeting for learning, discussion, and hands-on activities',
                    'event_type': 'meetup',
                    'start_date': datetime(2025, 2, 19, 16, 0),
                    'end_date': datetime(2025, 2, 19, 18, 0),
                    'location': 'Computer Science Lab',
                    'registration_required': False,
                    'created_by': admin_id
                },
                {
                    'title': 'Industry Guest Lecture',
                    'description': 'Learn from cybersecurity professionals and industry experts',
                    'event_type': 'lecture',
                    'start_date': datetime(2025, 4, 10, 15, 0),
                    'end_date': datetime(2025, 4, 10, 17, 0),
                    'location': 'Main Auditorium',
                    'max_participants': 100,
                    'registration_required': True,
                    'registration_deadline': datetime(2025, 4, 5, 23, 59),
                    'created_by': admin_id
                }
            ]
            
            for event_data in sample_events:
                event = EventDocument(**event_data)
                mongo.db.events.insert_one(event.__dict__)
            
            # Create sample news
            news_data = [
                {
                    'title': 'Welcome to RIT CyberGuard!',
                    'content': 'We are excited to announce the launch of RIT CyberGuard, our new cybersecurity club at Ramco Institute of Technology. Join us on our mission of Security Through Innovation!',
                    'category': 'announcement',
                    'is_published': True,
                    'published_at': datetime.utcnow(),
                    'created_by': admin_id
                },
                {
                    'title': 'First Club Meeting Scheduled',
                    'content': 'Our first official club meeting is scheduled for Wednesday, February 19th at 4:00 PM in the Computer Science Lab. All students are welcome to attend and learn about our upcoming activities.',
                    'category': 'news',
                    'is_published': True,
                    'published_at': datetime.utcnow(),
                    'created_by': admin_id
                }
            ]
            
            for news_item in news_data:
                news = NewsUpdateDocument(**news_item)
                mongo.db.news_updates.insert_one(news.__dict__)
            
            print("Default data created successfully")
            print("\\nDefault login credentials:")
            print("Email: admin@ritrjpm.ac.in")
            print("Password: admin123")
            
    except Exception as e:
        print(f"Error initializing database: {e}")

@app.errorhandler(404)
def not_found_error(error):
    return jsonify({'error': 'Not found'}), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({'error': 'Internal server error'}), 500

@app.route('/health')
def health_check():
    """Health check endpoint"""
    try:
        # Test MongoDB connection
        mongo.db.command('ping')
        return jsonify({
            'status': 'healthy',
            'database': 'connected',
            'timestamp': datetime.utcnow().isoformat(),
            'version': '1.0.0'
        }), 200
    except Exception as e:
        return jsonify({
            'status': 'unhealthy',
            'database': 'disconnected',
            'error': str(e),
            'timestamp': datetime.utcnow().isoformat()
        }), 500

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    debug = os.environ.get('DEBUG', 'True').lower() == 'true'
    
    # Initialize database
    with app.app_context():
        initialize_database()
    
    app.run(host='0.0.0.0', port=port, debug=debug)
'''

# Write MongoDB app file
with open('rit_cyberguard_mongodb/app.py', 'w') as f:
    f.write(app_mongodb)

print("✅ Created app.py for MongoDB Flask application")