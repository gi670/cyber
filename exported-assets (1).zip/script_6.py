# Create database initialization script for MongoDB
database_mongodb = '''"""
Database initialization and management utilities for MongoDB
"""

from pymongo import MongoClient
from datetime import datetime
from bson import ObjectId
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# MongoDB connection
MONGO_URI = os.environ.get('MONGO_URI') or 'mongodb://localhost:27017'
DB_NAME = os.environ.get('MONGO_DBNAME') or 'rit_cyberguard'

# Import document classes
from models import (UserDocument, TeamDocument, EventDocument, ActivityDocument, 
                   ContactFormDocument, NewsUpdateDocument, create_all_indexes)

def get_mongo_client():
    """Get MongoDB client"""
    client = MongoClient(MONGO_URI)
    return client[DB_NAME]

def init_db():
    """Initialize the database with default data"""
    print("Initializing MongoDB database...")
    
    db = get_mongo_client()
    
    # Drop existing collections (be careful in production!)
    collections_to_drop = ['users', 'teams', 'team_members', 'events', 
                          'event_registrations', 'activities', 'contact_forms', 'news_updates']
    
    for collection in collections_to_drop:
        db[collection].drop()
        print(f"Dropped collection: {collection}")
    
    print("Database collections dropped successfully")
    
    # Create indexes
    print("Creating database indexes...")
    
    # User indexes
    db.users.create_index("email", unique=True)
    db.users.create_index("uuid", unique=True)
    db.users.create_index("role")
    db.users.create_index("is_active")
    
    # Team indexes
    db.teams.create_index("name", unique=True)
    db.teams.create_index("is_active")
    db.teams.create_index("team_lead_id")
    
    # Team member indexes
    db.team_members.create_index([("user_id", 1), ("team_id", 1)], unique=True)
    db.team_members.create_index("is_active")
    
    # Event indexes
    db.events.create_index("start_date")
    db.events.create_index("event_type")
    db.events.create_index("is_active")
    db.events.create_index("created_by")
    
    # Event registration indexes
    db.event_registrations.create_index([("user_id", 1), ("event_id", 1)], unique=True)
    db.event_registrations.create_index("is_active")
    
    # Activity indexes
    db.activities.create_index("category")
    db.activities.create_index("difficulty_level")
    db.activities.create_index("is_active")
    
    # Contact form indexes
    db.contact_forms.create_index("submitted_at")
    db.contact_forms.create_index("is_responded")
    db.contact_forms.create_index("email")
    
    # News update indexes
    db.news_updates.create_index("published_at")
    db.news_updates.create_index("is_published")
    db.news_updates.create_index("category")
    db.news_updates.create_index("created_by")
    
    print("Database indexes created successfully")
    
    # Create default admin user
    admin = UserDocument(
        name='Admin User',
        email='admin@ritrjpm.ac.in',
        department='Computer Science',
        year='Faculty',
        role='admin'
    )
    admin.set_password('admin123')  # Change this in production
    admin_result = db.users.insert_one(admin.__dict__)
    admin_id = admin_result.inserted_id
    print("Default admin user created")
    
    # Create sample member
    member = UserDocument(
        name='John Doe',
        email='john.doe@ritrjpm.ac.in',
        phone='9876543210',
        department='Computer Science',
        year='2nd Year',
        roll_number='21CS001',
        role='member'
    )
    member_result = db.users.insert_one(member.__dict__)
    member_id = member_result.inserted_id
    print("Sample member user created")
    
    # Create default teams
    teams_data = [
        {
            'name': 'Core Team',
            'description': 'Founding members leading club activities and strategic direction',
            'meeting_day': 'Monday',
            'meeting_time': '5:00 PM',
            'meeting_location': 'Computer Science Lab',
            'team_lead_id': admin_id
        },
        {
            'name': 'Technical Team',
            'description': 'Hands-on cybersecurity learning through labs and practical exercises',
            'meeting_day': 'Wednesday',
            'meeting_time': '4:00 PM',
            'meeting_location': 'Computer Science Lab',
            'team_lead_id': admin_id
        },
        {
            'name': 'Awareness Team',
            'description': 'Promoting cybersecurity awareness across RIT campus and community',
            'meeting_day': 'Friday',
            'meeting_time': '4:00 PM',
            'meeting_location': 'Computer Science Lab',
            'team_lead_id': admin_id
        }
    ]
    
    team_ids = []
    for team_data in teams_data:
        team = TeamDocument(**team_data)
        team_result = db.teams.insert_one(team.__dict__)
        team_ids.append(team_result.inserted_id)
        print(f"Created team: {team_data['name']}")
    
    # Add member to technical team
    from models import TeamMemberDocument
    tech_team_id = team_ids[1]  # Technical Team
    team_membership = TeamMemberDocument(
        user_id=member_id,
        team_id=tech_team_id,
        role='member'
    )
    db.team_members.insert_one(team_membership.__dict__)
    print("Added member to Technical Team")
    
    # Create default activities
    activities_data = [
        {
            'name': 'Ethical Hacking Lab',
            'description': 'Learn penetration testing basics and ethical hacking techniques in a safe environment',
            'category': 'lab',
            'difficulty_level': 'beginner'
        },
        {
            'name': 'Capture The Flag',
            'description': 'Practice cybersecurity skills through CTF challenges and competitions',
            'category': 'competition',
            'difficulty_level': 'intermediate'
        },
        {
            'name': 'Cyber Awareness',
            'description': 'Digital literacy workshops for students and faculty across all departments',
            'category': 'awareness',
            'difficulty_level': 'beginner'
        },
        {
            'name': 'Web Security',
            'description': 'Secure coding practices and web application security fundamentals',
            'category': 'workshop',
            'difficulty_level': 'intermediate'
        },
        {
            'name': 'Network Security',
            'description': 'Infrastructure protection, network monitoring, and security protocols',
            'category': 'lab',
            'difficulty_level': 'advanced'
        },
        {
            'name': 'Digital Forensics',
            'description': 'Incident response basics and digital investigation techniques',
            'category': 'lab',
            'difficulty_level': 'advanced'
        }
    ]
    
    for activity_data in activities_data:
        activity = ActivityDocument(**activity_data)
        db.activities.insert_one(activity.__dict__)
        print(f"Created activity: {activity_data['name']}")
    
    # Create sample events
    sample_events = [
        {
            'title': 'Cybersecurity Workshop',
            'description': 'Intensive workshop covering cybersecurity fundamentals for beginners',
            'event_type': 'workshop',
            'start_date': datetime(2025, 3, 15, 14, 0),
            'end_date': datetime(2025, 3, 15, 17, 0),
            'location': 'Main Auditorium',
            'max_participants': 50,
            'registration_required': True,
            'registration_deadline': datetime(2025, 3, 10, 23, 59),
            'created_by': admin_id
        },
        {
            'title': 'Weekly Meetup',
            'description': 'Regular meeting for learning, discussion, and hands-on activities',
            'event_type': 'meetup',
            'start_date': datetime(2025, 2, 19, 16, 0),
            'end_date': datetime(2025, 2, 19, 18, 0),
            'location': 'Computer Science Lab',
            'registration_required': False,
            'created_by': admin_id
        },
        {
            'title': 'Industry Guest Lecture',
            'description': 'Learn from cybersecurity professionals and industry experts',
            'event_type': 'lecture',
            'start_date': datetime(2025, 4, 10, 15, 0),
            'end_date': datetime(2025, 4, 10, 17, 0),
            'location': 'Main Auditorium',
            'max_participants': 100,
            'registration_required': True,
            'registration_deadline': datetime(2025, 4, 5, 23, 59),
            'created_by': admin_id
        }
    ]
    
    for event_data in sample_events:
        event = EventDocument(**event_data)
        db.events.insert_one(event.__dict__)
        print(f"Created event: {event_data['title']}")
    
    # Create sample news
    news_data = [
        {
            'title': 'Welcome to RIT CyberGuard!',
            'content': 'We are excited to announce the launch of RIT CyberGuard, our new cybersecurity club at Ramco Institute of Technology. Join us on our mission of Security Through Innovation!',
            'category': 'announcement',
            'is_published': True,
            'published_at': datetime.utcnow(),
            'created_by': admin_id
        },
        {
            'title': 'First Club Meeting Scheduled',
            'content': 'Our first official club meeting is scheduled for Wednesday, February 19th at 4:00 PM in the Computer Science Lab. All students are welcome to attend and learn about our upcoming activities.',
            'category': 'news',
            'is_published': True,
            'published_at': datetime.utcnow(),
            'created_by': admin_id
        }
    ]
    
    for news_item in news_data:
        news = NewsUpdateDocument(**news_item)
        db.news_updates.insert_one(news.__dict__)
        print(f"Created news: {news_item['title']}")
    
    print("\\n✅ Database initialization completed successfully!")
    print("\\n🔑 Default login credentials:")
    print("Email: admin@ritrjpm.ac.in")
    print("Password: admin123")
    print("\\n📊 Database Statistics:")
    print(f"Users: {db.users.count_documents({})}")
    print(f"Teams: {db.teams.count_documents({})}")
    print(f"Activities: {db.activities.count_documents({})}")
    print(f"Events: {db.events.count_documents({})}")
    print(f"News Updates: {db.news_updates.count_documents({})}")

def reset_db():
    """Reset the database (drop all collections and recreate)"""
    print("⚠️  WARNING: This will delete ALL data in the database!")
    confirm = input("Type 'RESET' to confirm: ")
    
    if confirm == 'RESET':
        init_db()
    else:
        print("Database reset cancelled")

def show_stats():
    """Show database statistics"""
    db = get_mongo_client()
    
    print("\\n📊 RIT CyberGuard Database Statistics")
    print("=" * 40)
    print(f"Users: {db.users.count_documents({})}")
    print(f"  - Members: {db.users.count_documents({'role': 'member'})}")
    print(f"  - Admins: {db.users.count_documents({'role': 'admin'})}")
    print(f"  - Active: {db.users.count_documents({'is_active': True})}")
    print(f"Teams: {db.teams.count_documents({})}")
    print(f"  - Active: {db.teams.count_documents({'is_active': True})}")
    print(f"Team Members: {db.team_members.count_documents({})}")
    print(f"Activities: {db.activities.count_documents({})}")
    print(f"Events: {db.events.count_documents({})}")
    print(f"  - Upcoming: {db.events.count_documents({'start_date': {'$gt': datetime.utcnow()}})}")
    print(f"Event Registrations: {db.event_registrations.count_documents({})}")
    print(f"Contact Forms: {db.contact_forms.count_documents({})}")
    print(f"News Updates: {db.news_updates.count_documents({})}")
    print(f"  - Published: {db.news_updates.count_documents({'is_published': True})}")

def test_connection():
    """Test MongoDB connection"""
    try:
        db = get_mongo_client()
        # Ping the database
        result = db.command('ping')
        print("✅ MongoDB connection successful!")
        print(f"Database: {DB_NAME}")
        print(f"Connection: {MONGO_URI}")
        return True
    except Exception as e:
        print(f"❌ MongoDB connection failed: {e}")
        return False

if __name__ == '__main__':
    import sys
    
    if len(sys.argv) > 1:
        command = sys.argv[1]
        if command == 'init':
            init_db()
        elif command == 'reset':
            reset_db()
        elif command == 'stats':
            show_stats()
        elif command == 'test':
            test_connection()
        else:
            print("Available commands: init, reset, stats, test")
    else:
        # Default action
        if test_connection():
            init_db()
'''

# Write MongoDB database file
with open('rit_cyberguard_mongodb/database.py', 'w') as f:
    f.write(database_mongodb)

print("✅ Created database.py for MongoDB initialization")