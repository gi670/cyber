"""
Routes for RIT CyberGuard Flask application with MongoDB
"""

from flask import render_template, request, jsonify, redirect, url_for, flash, current_app
from flask_mail import Message
from datetime import datetime
from bson import ObjectId
from bson.errors import InvalidId
import json
import uuid

# Import document classes
from models import (UserDocument, TeamDocument, EventDocument, ActivityDocument, 
                   ContactFormDocument, NewsUpdateDocument, TeamMemberDocument, EventRegistrationDocument)

def register_routes(app, mongo, mail):
    """Register all routes with the Flask app"""

    # Main website routes
    @app.route('/')
    def index():
        """Main homepage"""
        # Get latest events and news from MongoDB
        upcoming_events = list(mongo.db.events.find({
            'start_date': {'$gt': datetime.utcnow()},
            'is_active': True
        }).sort('start_date', 1).limit(3))

        recent_news = list(mongo.db.news_updates.find({
            'is_published': True
        }).sort('published_at', -1).limit(3))

        # Get statistics
        total_members = mongo.db.users.count_documents({'is_active': True, 'role': {'$ne': 'guest'}})
        active_teams = mongo.db.teams.count_documents({'is_active': True})
        upcoming_events_count = len(upcoming_events)

        stats = {
            'total_members': total_members,
            'active_teams': active_teams,
            'upcoming_events': upcoming_events_count,
            'founded_year': '2025'
        }

        # Convert ObjectIds to strings for JSON serialization
        for event in upcoming_events:
            event['_id'] = str(event['_id'])
            if event.get('created_by'):
                event['created_by'] = str(event['created_by'])

        for news in recent_news:
            news['_id'] = str(news['_id'])
            if news.get('created_by'):
                news['created_by'] = str(news['created_by'])

        return render_template('index.html', 
                             events=upcoming_events, 
                             news=recent_news, 
                             stats=stats)

    # API Routes

    @app.route('/api/stats')
    def get_stats():
        """Get club statistics"""
        try:
            total_members = mongo.db.users.count_documents({'is_active': True, 'role': {'$ne': 'guest'}})
            active_teams = mongo.db.teams.count_documents({'is_active': True})
            departments_count = len(mongo.db.users.distinct('department', {'is_active': True, 'role': {'$ne': 'guest'}}))
            upcoming_events = mongo.db.events.count_documents({
                'start_date': {'$gt': datetime.utcnow()},
                'is_active': True
            })

            stats = {
                'total_members': total_members,
                'active_teams': active_teams,
                'departments_represented': departments_count,
                'upcoming_events': upcoming_events,
                'founded_year': '2025'
            }
            return jsonify(stats)
        except Exception as e:
            return jsonify({'error': str(e)}), 500

    @app.route('/api/teams')
    def get_teams():
        """Get all active teams"""
        try:
            teams = list(mongo.db.teams.find({'is_active': True}))

            # Convert ObjectIds and add member count
            for team in teams:
                team['_id'] = str(team['_id'])
                if team.get('team_lead_id'):
                    team['team_lead_id'] = str(team['team_lead_id'])

                # Count team members
                member_count = mongo.db.team_members.count_documents({
                    'team_id': ObjectId(team['_id']),
                    'is_active': True
                })
                team['member_count'] = member_count

            return jsonify(teams)
        except Exception as e:
            return jsonify({'error': str(e)}), 500

    @app.route('/api/events')
    def get_events():
        """Get upcoming events"""
        try:
            events = list(mongo.db.events.find({
                'start_date': {'$gt': datetime.utcnow()},
                'is_active': True
            }).sort('start_date', 1))

            # Convert ObjectIds and dates
            for event in events:
                event['_id'] = str(event['_id'])
                if event.get('created_by'):
                    event['created_by'] = str(event['created_by'])

                # Convert dates to ISO format
                if event.get('start_date'):
                    event['start_date'] = event['start_date'].isoformat()
                if event.get('end_date'):
                    event['end_date'] = event['end_date'].isoformat()
                if event.get('registration_deadline'):
                    event['registration_deadline'] = event['registration_deadline'].isoformat()

                # Check if event is full
                registration_count = mongo.db.event_registrations.count_documents({
                    'event_id': ObjectId(event['_id']),
                    'is_active': True
                })
                event['registration_count'] = registration_count
                event['is_full'] = event.get('max_participants') and registration_count >= event['max_participants']

            return jsonify(events)
        except Exception as e:
            return jsonify({'error': str(e)}), 500

    @app.route('/api/activities')
    def get_activities():
        """Get all activities"""
        try:
            activities = list(mongo.db.activities.find({'is_active': True}))

            # Convert ObjectIds
            for activity in activities:
                activity['_id'] = str(activity['_id'])

            return jsonify(activities)
        except Exception as e:
            return jsonify({'error': str(e)}), 500

    @app.route('/api/news')
    def get_news():
        """Get published news updates"""
        try:
            news = list(mongo.db.news_updates.find({
                'is_published': True
            }).sort('published_at', -1).limit(10))

            # Convert ObjectIds and dates
            for item in news:
                item['_id'] = str(item['_id'])
                if item.get('created_by'):
                    item['created_by'] = str(item['created_by'])
                if item.get('published_at'):
                    item['published_at'] = item['published_at'].isoformat()
                if item.get('created_at'):
                    item['created_at'] = item['created_at'].isoformat()

            return jsonify(news)
        except Exception as e:
            return jsonify({'error': str(e)}), 500

    # Contact and Registration Routes

    @app.route('/api/contact', methods=['POST'])
    def submit_contact_form():
        """Submit contact form"""
        try:
            data = request.get_json()

            # Validate required fields
            required_fields = ['name', 'email', 'message']
            if not all(field in data for field in required_fields):
                return jsonify({'error': 'Missing required fields'}), 400

            # Create contact form document
            contact = ContactFormDocument(
                name=data['name'],
                email=data['email'],
                phone=data.get('phone'),
                department=data.get('department'),
                year=data.get('year'),
                message=data['message'],
                interest_areas=data.get('interest_areas', [])
            )

            # Insert into MongoDB
            result = mongo.db.contact_forms.insert_one(contact.__dict__)

            # Send notification email
            try:
                email_body = f"""
                <h3>New Contact Form Submission</h3>
                <p><strong>Name:</strong> {data['name']}</p>
                <p><strong>Email:</strong> {data['email']}</p>
                <p><strong>Phone:</strong> {data.get('phone', 'Not provided')}</p>
                <p><strong>Department:</strong> {data.get('department', 'Not provided')}</p>
                <p><strong>Year:</strong> {data.get('year', 'Not provided')}</p>
                <p><strong>Message:</strong></p>
                <p>{data['message']}</p>
                <p><strong>Interest Areas:</strong> {', '.join(data.get('interest_areas', []))}</p>
                """

                msg = Message(
                    subject='New Contact Form Submission - RIT CyberGuard',
                    recipients=[current_app.config['CLUB_EMAIL']],
                    html=email_body
                )
                mail.send(msg)
            except Exception as e:
                print(f"Failed to send email: {e}")

            return jsonify({'message': 'Contact form submitted successfully'}), 200

        except Exception as e:
            return jsonify({'error': str(e)}), 500

    @app.route('/api/join', methods=['POST'])
    def join_club():
        """Join the club"""
        try:
            data = request.get_json()

            # Validate required fields
            required_fields = ['name', 'email', 'department', 'year']
            if not all(field in data for field in required_fields):
                return jsonify({'error': 'Missing required fields'}), 400

            # Check if user already exists
            existing_user = mongo.db.users.find_one({'email': data['email']})
            if existing_user:
                return jsonify({'error': 'Email already registered'}), 400

            # Create new user document
            user = UserDocument(
                name=data['name'],
                email=data['email'],
                phone=data.get('phone'),
                department=data['department'],
                year=data['year'],
                roll_number=data.get('roll_number'),
                role='member'
            )

            # Insert into MongoDB
            result = mongo.db.users.insert_one(user.__dict__)

            # Send welcome email
            try:
                welcome_body = f"""
                <h2>Welcome to RIT CyberGuard, {data['name']}!</h2>
                <p>Thank you for joining our cybersecurity community at Ramco Institute of Technology.</p>

                <h3>Next Steps:</h3>
                <ul>
                    <li>Join our weekly meetups every {current_app.config['MEETING_DAY']} at {current_app.config['MEETING_TIME']}</li>
                    <li>Location: {current_app.config['MEETING_LOCATION']}</li>
                    <li>Follow us on social media for updates</li>
                    <li>Choose a team that matches your interests</li>
                </ul>

                <p>Our mission is <strong>Security Through Innovation</strong>, and we're excited to have you on this journey!</p>

                <p>Best regards,<br>
                RIT CyberGuard Team<br>
                {current_app.config['CLUB_EMAIL']}</p>
                """

                msg = Message(
                    subject='Welcome to RIT CyberGuard!',
                    recipients=[data['email']],
                    html=welcome_body
                )
                mail.send(msg)
            except Exception as e:
                print(f"Failed to send welcome email: {e}")

            return jsonify({
                'message': 'Successfully joined RIT CyberGuard!',
                'user_id': str(result.inserted_id)
            }), 200

        except Exception as e:
            return jsonify({'error': str(e)}), 500

    @app.route('/api/events/<event_id>/register', methods=['POST'])
    def register_for_event(event_id):
        """Register for an event"""
        try:
            data = request.get_json()
            email = data.get('email')

            if not email:
                return jsonify({'error': 'Email is required'}), 400

            # Validate ObjectId
            try:
                event_obj_id = ObjectId(event_id)
            except InvalidId:
                return jsonify({'error': 'Invalid event ID'}), 400

            # Check if event exists
            event = mongo.db.events.find_one({'_id': event_obj_id, 'is_active': True})
            if not event:
                return jsonify({'error': 'Event not found'}), 404

            # Check if event is full
            registration_count = mongo.db.event_registrations.count_documents({
                'event_id': event_obj_id,
                'is_active': True
            })

            if event.get('max_participants') and registration_count >= event['max_participants']:
                return jsonify({'error': 'Event is full'}), 400

            # Check if registration deadline has passed
            if event.get('registration_deadline') and datetime.utcnow() > event['registration_deadline']:
                return jsonify({'error': 'Registration deadline has passed'}), 400

            # Find or create user
            user = mongo.db.users.find_one({'email': email})
            if not user:
                # Create temporary user for event registration
                temp_user = UserDocument(
                    name=data.get('name', ''),
                    email=email,
                    phone=data.get('phone'),
                    department=data.get('department', ''),
                    year=data.get('year', ''),
                    role='guest'
                )
                result = mongo.db.users.insert_one(temp_user.__dict__)
                user_id = result.inserted_id
            else:
                user_id = user['_id']

            # Check if already registered
            existing_registration = mongo.db.event_registrations.find_one({
                'user_id': user_id,
                'event_id': event_obj_id,
                'is_active': True
            })

            if existing_registration:
                return jsonify({'error': 'Already registered for this event'}), 400

            # Create registration
            registration = EventRegistrationDocument(
                user_id=user_id,
                event_id=event_obj_id
            )

            mongo.db.event_registrations.insert_one(registration.__dict__)

            return jsonify({'message': 'Successfully registered for event'}), 200

        except Exception as e:
            return jsonify({'error': str(e)}), 500

    # Admin routes (would normally require authentication)

    @app.route('/api/admin/members')
    def get_members():
        """Get all club members (admin only)"""
        try:
            members = list(mongo.db.users.find({'role': {'$ne': 'guest'}}))

            # Convert ObjectIds and dates
            for member in members:
                member['_id'] = str(member['_id'])
                if member.get('join_date'):
                    member['join_date'] = member['join_date'].isoformat()

            return jsonify(members)
        except Exception as e:
            return jsonify({'error': str(e)}), 500

    @app.route('/api/admin/contact-forms')
    def get_contact_forms():
        """Get all contact form submissions (admin only)"""
        try:
            forms = list(mongo.db.contact_forms.find().sort('submitted_at', -1))

            # Convert ObjectIds and dates
            for form in forms:
                form['_id'] = str(form['_id'])
                if form.get('submitted_at'):
                    form['submitted_at'] = form['submitted_at'].isoformat()

            return jsonify(forms)
        except Exception as e:
            return jsonify({'error': str(e)}), 500
