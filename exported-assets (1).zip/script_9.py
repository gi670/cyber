# Create comprehensive README for MongoDB version
readme_mongodb = '''# RIT CyberGuard - Flask Backend with MongoDB

A comprehensive Flask backend application for the RIT CyberGuard cybersecurity club website at Ramco Institute of Technology, using MongoDB as the database.

## 🎯 Features

- **Complete Cybersecurity Club Website**: Modern, responsive design
- **MongoDB Integration**: NoSQL database for flexible data management
- **RESTful API**: JSON endpoints for all data operations
- **Member Management**: Registration, teams, and role-based access
- **Event System**: Registration, capacity management, automated emails
- **Contact System**: Forms with email notifications
- **Admin Dashboard**: Club management tools
- **Email Integration**: Welcome emails and notifications
- **Mobile Responsive**: Works on all devices

## 🏗️ Project Structure

```
rit_cyberguard_mongodb/
├── app.py                     # Main Flask application
├── config.py                  # Configuration settings
├── models.py                  # MongoDB document schemas
├── routes.py                  # API routes and endpoints
├── database.py                # Database initialization utilities
├── requirements.txt           # Python dependencies
├── .env.example              # Environment variables template
├── README.md                 # This file
├── 
├── static/                   # Static files (CSS, JS, Images)
│   ├── css/
│   │   └── style.css        # Frontend styling
│   ├── js/
│   │   └── app.js          # Frontend JavaScript
│   └── images/             # Image assets
├── 
├── templates/                # Jinja2 HTML templates
│   ├── index.html          # Main homepage template
│   ├── admin/              # Admin-only templates
│   └── partials/           # Reusable components
├── 
├── uploads/                  # File upload directory
└── logs/                    # Application logs
```

## 🚀 Quick Start Guide

### 1. Prerequisites

- Python 3.8 or higher
- MongoDB 4.4 or higher (local installation or MongoDB Atlas)
- pip (Python package installer)
- Git

### 2. MongoDB Setup

#### Option A: Local MongoDB Installation

**Ubuntu/Debian:**
```bash
# Import MongoDB public key
wget -qO - https://www.mongodb.org/static/pgp/server-6.0.asc | sudo apt-key add -

# Create list file
echo "deb [ arch=amd64,arm64 ] https://repo.mongodb.org/apt/ubuntu focal/mongodb-org/6.0 multiverse" | sudo tee /etc/apt/sources.list.d/mongodb-org-6.0.list

# Update and install
sudo apt-get update
sudo apt-get install -y mongodb-org

# Start MongoDB
sudo systemctl start mongod
sudo systemctl enable mongod
```

**Windows:**
- Download MongoDB Community Server from https://www.mongodb.com/try/download/community
- Install and start MongoDB service
- MongoDB will run on `mongodb://localhost:27017` by default

**macOS:**
```bash
# Using Homebrew
brew tap mongodb/brew
brew install mongodb-community
brew services start mongodb/brew/mongodb-community
```

#### Option B: MongoDB Atlas (Cloud)

1. Sign up for free at https://www.mongodb.com/atlas
2. Create a new cluster
3. Create a database user
4. Whitelist your IP address
5. Get connection string (replace in .env file)

### 3. Project Setup

```bash
# Clone or create the project directory
mkdir rit_cyberguard_mongodb
cd rit_cyberguard_mongodb

# Create virtual environment
python -m venv venv

# Activate virtual environment
# On Windows:
venv\\Scripts\\activate
# On macOS/Linux:
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt
```

### 4. Environment Configuration

```bash
# Copy environment template
cp .env.example .env

# Edit .env file with your actual values
# nano .env  # or use your preferred editor
```

#### Key Environment Variables:

```bash
# MongoDB Configuration
MONGO_URI=mongodb://localhost:27017/rit_cyberguard

# For MongoDB Atlas:
# MONGO_URI=mongodb+srv://username:password@cluster.mongodb.net/rit_cyberguard?retryWrites=true&w=majority

# Email Configuration (Gmail example)
MAIL_USERNAME=cyberguard@ritrjpm.ac.in
MAIL_PASSWORD=your-app-password

# Security
SECRET_KEY=your-super-secret-key
```

### 5. Database Initialization

```bash
# Test MongoDB connection
python database.py test

# Initialize database with sample data
python database.py init

# Check database statistics
python database.py stats
```

### 6. Run the Application

```bash
# Development mode
python app.py

# Or using Flask CLI
export FLASK_APP=app.py
export FLASK_ENV=development
flask run
```

The application will be available at `http://localhost:5000`

## 📊 MongoDB Collections

### Users Collection
```javascript
{
  _id: ObjectId,
  uuid: String,
  name: String,
  email: String (unique),
  phone: String,
  department: String,
  year: String,
  roll_number: String,
  role: String, // "member", "team_lead", "admin"
  is_active: Boolean,
  join_date: Date,
  password_hash: String,
  team_memberships: [ObjectId],
  event_registrations: [ObjectId]
}
```

### Teams Collection
```javascript
{
  _id: ObjectId,
  name: String (unique),
  description: String,
  meeting_day: String,
  meeting_time: String,
  meeting_location: String,
  team_lead_id: ObjectId,
  is_active: Boolean,
  created_at: Date,
  members: [{
    user_id: ObjectId,
    role: String,
    joined_at: Date
  }]
}
```

### Events Collection
```javascript
{
  _id: ObjectId,
  title: String,
  description: String,
  event_type: String, // "workshop", "meetup", "competition", "lecture"
  start_date: Date,
  end_date: Date,
  location: String,
  max_participants: Number,
  registration_required: Boolean,
  registration_deadline: Date,
  is_active: Boolean,
  created_at: Date,
  created_by: ObjectId,
  registrations: [{
    user_id: ObjectId,
    registered_at: Date,
    is_active: Boolean
  }]
}
```

### Activities Collection
```javascript
{
  _id: ObjectId,
  name: String,
  description: String,
  category: String, // "lab", "workshop", "competition", "awareness"
  difficulty_level: String, // "beginner", "intermediate", "advanced"
  is_active: Boolean,
  created_at: Date
}
```

## 🔌 API Endpoints

### Public Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/` | Main website homepage |
| GET | `/api/stats` | Club statistics |
| GET | `/api/teams` | List all active teams |
| GET | `/api/events` | List upcoming events |
| GET | `/api/activities` | List all activities |
| GET | `/api/news` | Published news updates |
| POST | `/api/contact` | Submit contact form |
| POST | `/api/join` | Join the club |
| POST | `/api/events/<id>/register` | Register for an event |

### Admin Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/admin/members` | List all club members |
| GET | `/api/admin/contact-forms` | List contact form submissions |

### Example API Usage

```bash
# Get club statistics
curl http://localhost:5000/api/stats

# Join the club
curl -X POST http://localhost:5000/api/join \\
  -H "Content-Type: application/json" \\
  -d '{
    "name": "John Doe",
    "email": "john.doe@ritrjpm.ac.in",
    "department": "Computer Science",
    "year": "2nd Year",
    "phone": "9876543210"
  }'

# Submit contact form
curl -X POST http://localhost:5000/api/contact \\
  -H "Content-Type: application/json" \\
  -d '{
    "name": "Jane Smith",
    "email": "jane.smith@ritrjpm.ac.in",
    "message": "I am interested in joining the cybersecurity club"
  }'
```

## 🗄️ Database Management

### Initialize Database
```bash
python database.py init
```

### Reset Database (⚠️ Destructive)
```bash
python database.py reset
```

### Show Statistics
```bash
python database.py stats
```

### Test Connection
```bash
python database.py test
```

## 📧 Email Configuration

### Gmail Setup
1. Enable 2-Factor Authentication
2. Generate App Password: https://myaccount.google.com/apppasswords
3. Use App Password in `.env` file

```bash
MAIL_SERVER=smtp.gmail.com
MAIL_PORT=587
MAIL_USE_TLS=True
MAIL_USERNAME=cyberguard@ritrjpm.ac.in
MAIL_PASSWORD=your-16-character-app-password
```

### Other Email Providers
```bash
# Yahoo
MAIL_SERVER=smtp.mail.yahoo.com
MAIL_PORT=587

# Outlook
MAIL_SERVER=smtp-mail.outlook.com
MAIL_PORT=587

# Custom SMTP
MAIL_SERVER=mail.yourdomain.com
MAIL_PORT=587
```

## 🚀 Production Deployment

### Using Gunicorn
```bash
# Install gunicorn
pip install gunicorn

# Run with gunicorn
gunicorn -w 4 -b 0.0.0.0:5000 app:app

# With configuration file
gunicorn --config gunicorn.conf.py app:app
```

### Docker Deployment

**Dockerfile:**
```dockerfile
FROM python:3.9-slim

WORKDIR /app

# Install dependencies
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy application
COPY . .

# Expose port
EXPOSE 5000

# Run application
CMD ["gunicorn", "--bind", "0.0.0.0:5000", "app:app"]
```

**docker-compose.yml:**
```yaml
version: '3.8'
services:
  web:
    build: .
    ports:
      - "5000:5000"
    environment:
      - MONGO_URI=mongodb://mongo:27017/rit_cyberguard
    depends_on:
      - mongo
    
  mongo:
    image: mongo:6.0
    ports:
      - "27017:27017"
    volumes:
      - mongodb_data:/data/db

volumes:
  mongodb_data:
```

```bash
# Build and run
docker-compose up -d
```

### Environment Variables for Production
```bash
SECRET_KEY=your-production-secret-key
DEBUG=False
FLASK_ENV=production
MONGO_URI=your-production-mongodb-uri
MAIL_USERNAME=cyberguard@ritrjpm.ac.in
MAIL_PASSWORD=your-production-email-password
```

## 🔧 Development

### Adding New Collections

1. **Create Document Class in `models.py`:**
```python
class NewDocument(BaseDocument):
    def __init__(self, **kwargs):
        super().__init__()
        self._id = kwargs.get('_id', ObjectId())
        self.field1 = kwargs.get('field1', '')
        # Add more fields...
    
    @classmethod
    def create_indexes(cls, mongo):
        mongo.db.new_collection.create_index("field1")
```

2. **Add Routes in `routes.py`:**
```python
@app.route('/api/new_collection')
def get_new_collection():
    items = list(mongo.db.new_collection.find({}))
    # Convert ObjectIds...
    return jsonify(items)
```

3. **Update Database Initialization in `database.py`:**
```python
# Add sample data creation
sample_data = [...]
for item in sample_data:
    doc = NewDocument(**item)
    db.new_collection.insert_one(doc.__dict__)
```

### Running Tests
```bash
# Install test dependencies
pip install pytest pytest-flask

# Run tests
pytest

# Run with coverage
pytest --cov=app
```

## 🔑 Default Login Credentials

After running `python database.py init`:
- **Email**: admin@ritrjpm.ac.in
- **Password**: admin123

⚠️ **Change these credentials immediately in production!**

## 📱 Club Information

- **College**: Ramco Institute of Technology
- **Location**: North Venganallur Village, Rajapalayam, Tamil Nadu - 626117
- **Affiliation**: Anna University, Chennai
- **Approval**: AICTE Approved
- **Founded**: 2013 (College) / 2025 (CyberGuard Club)
- **Mission**: "Security Through Innovation"
- **Meeting**: Wednesdays at 4:00 PM in Computer Science Lab
- **Contact**: cyberguard@ritrjpm.ac.in, +91 9489634752

## 🛠️ Troubleshooting

### Common Issues

1. **MongoDB Connection Error:**
```bash
# Check if MongoDB is running
sudo systemctl status mongod

# Start MongoDB
sudo systemctl start mongod

# Check connection
python database.py test
```

2. **Email Not Sending:**
```bash
# For Gmail, use App Password instead of regular password
# Enable "Less secure app access" if not using 2FA
```

3. **Port Already in Use:**
```bash
# Find process using port 5000
lsof -i :5000

# Kill process
kill -9 <PID>

# Or use different port
PORT=8000 python app.py
```

4. **Module Import Errors:**
```bash
# Ensure virtual environment is activated
source venv/bin/activate  # or venv\\Scripts\\activate on Windows

# Reinstall dependencies
pip install -r requirements.txt
```

## 📈 Performance Optimization

### MongoDB Indexing
```bash
# Check existing indexes
db.users.getIndexes()

# Create custom indexes
db.users.createIndex({"email": 1}, {"unique": true})
db.events.createIndex({"start_date": 1, "is_active": 1})
```

### Query Optimization
```python
# Use projection to limit returned fields
users = mongo.db.users.find({}, {"name": 1, "email": 1, "department": 1})

# Use limit and skip for pagination
events = mongo.db.events.find().sort("start_date", 1).limit(10).skip(0)
```

## 🔒 Security Best Practices

1. **Environment Variables**: Never commit secrets to version control
2. **Password Hashing**: Using bcrypt for password storage
3. **Input Validation**: Validate all user inputs
4. **MongoDB Injection**: Use parameterized queries
5. **CORS**: Configure properly for production
6. **HTTPS**: Use SSL/TLS in production

## 📚 Additional Resources

- **Flask Documentation**: https://flask.palletsprojects.com/
- **PyMongo Documentation**: https://pymongo.readthedocs.io/
- **MongoDB Manual**: https://docs.mongodb.com/manual/
- **Flask-Mail Documentation**: https://flask-mail.readthedocs.io/

## 🤝 Contributing

This project is specifically designed for RIT CyberGuard at Ramco Institute of Technology. For improvements or bug fixes:

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## 📄 License

This project is developed for educational purposes for RIT CyberGuard at Ramco Institute of Technology.

---

**RIT CyberGuard - Security Through Innovation** 🔐

For support: cyberguard@ritrjpm.ac.in
'''

# Write MongoDB README file
with open('rit_cyberguard_mongodb/README.md', 'w') as f:
    f.write(readme_mongodb)

print("✅ Created comprehensive README.md for MongoDB version")