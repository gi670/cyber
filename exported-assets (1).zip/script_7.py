# Create environment variables template for MongoDB
env_example = '''# Flask Configuration
SECRET_KEY=your-super-secret-key-change-this-in-production
FLASK_CONFIG=development
DEBUG=True
PORT=5000

# MongoDB Configuration
MONGO_URI=mongodb://localhost:27017/rit_cyberguard
MONGO_DBNAME=rit_cyberguard
MONGO_HOST=localhost
MONGO_PORT=27017
MONGO_USERNAME=
MONGO_PASSWORD=

# For MongoDB Atlas (Cloud)
# MONGO_URI=mongodb+srv://username:password@cluster.mongodb.net/rit_cyberguard?retryWrites=true&w=majority

# For Production MongoDB with Authentication
# MONGO_URI=mongodb://username:password@localhost:27017/rit_cyberguard_prod
# MONGO_USERNAME=your-mongo-username
# MONGO_PASSWORD=your-mongo-password

# Email Configuration (Gmail example)
MAIL_SERVER=smtp.gmail.com
MAIL_PORT=587
MAIL_USE_TLS=True
MAIL_USERNAME=cyberguard@ritrjpm.ac.in
MAIL_PASSWORD=your-app-password
MAIL_DEFAULT_SENDER=RIT CyberGuard <cyberguard@ritrjpm.ac.in>

# Club Configuration
CLUB_NAME=RIT CyberGuard
CLUB_EMAIL=cyberguard@ritrjpm.ac.in
CLUB_PHONE=9489634752
CLUB_ADDRESS=North Venganallur Village, Rajapalayam, Tamil Nadu - 626117

# Meeting Configuration
MEETING_DAY=Wednesday
MEETING_TIME=4:00 PM
MEETING_LOCATION=Computer Science Lab

# File Upload Configuration
MAX_CONTENT_LENGTH=16777216
ALLOWED_EXTENSIONS=txt,pdf,png,jpg,jpeg,gif,doc,docx

# Security Headers
SEND_FILE_MAX_AGE_DEFAULT=3600
'''

# Write .env.example file
with open('rit_cyberguard_mongodb/.env.example', 'w') as f:
    f.write(env_example)

print("✅ Created .env.example for environment configuration")